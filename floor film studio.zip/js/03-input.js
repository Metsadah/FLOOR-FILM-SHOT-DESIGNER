// FLOOR — 03-input.js
// Extracted from the original single-file build. All files share global scope
// (loaded as classic scripts, in order). True ES modules come with the build step later.
'use strict';
// ---------------------------------------------------------------- toast
function toast(msg){
  let t = document.getElementById('toast');
  if(!t){ t = document.createElement('div'); t.id='toast'; document.body.appendChild(t); }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=>t.classList.remove('show'), 3200);
}

// ---------------------------------------------------------------- history (undo / redo)
let undoStack = [], redoStack = [];
let histBase = null, histPushed = false, histTimer = null;
function snapshotState(){
  return JSON.stringify({scenes:project.scenes, activeSceneId:project.activeSceneId,
    customProps:project.customProps, shootName:project.shootName||'',
    moodboard:project.moodboard||null, prodboard:project.prodboard||null,
    script:project.script||null, production:project.production||null});
}
function updateHistBtns(){
  const u = document.getElementById('undoBtn'), r = document.getElementById('redoBtn');
  if(u) u.disabled = !undoStack.length;
  if(r) r.disabled = !redoStack.length;
}
function histSettle(){
  histBase = snapshotState();
  histPushed = false;
  clearTimeout(histTimer); histTimer = null;
  updateHistBtns();
}
const persistOnly = markDirty; // original save-only version
markDirty = function(){
  if(histBase !== null && !histPushed){
    undoStack.push(histBase);
    if(undoStack.length > 60) undoStack.shift();
    redoStack.length = 0;
    histPushed = true;
    updateHistBtns();
  }
  clearTimeout(histTimer);
  histTimer = setTimeout(histSettle, 750);
  persistOnly();
};
function applyState(s){
  const p = JSON.parse(s);
  project.scenes = p.scenes || p.shots; // tolerate pre-rename snapshots
  project.activeSceneId = p.activeSceneId ?? p.activeShotId;
  if(p.moodboard !== undefined) project.moodboard = p.moodboard;
  if(p.prodboard !== undefined) project.prodboard = p.prodboard;
  if(p.script !== undefined && p.script !== null) project.script = p.script;
  if(p.production !== undefined && p.production !== null) project.production = p.production;
  project.customProps = p.customProps || [];
  project.shootName = p.shootName || '';
  if(!project.scenes.length){ project.scenes = [newShot(1)]; }
  if(!project.scenes.find(x=>x.id===project.activeSceneId)) project.activeSceneId = project.scenes[0].id;
  project.scenes.forEach(migrateShot);
  if(typeof exitAllSubboards === 'function') exitAllSubboards(); // stack may point into replaced arrays
  sel = null; drag = null; hoverWall = null;
  togglePlay(false);
  closeNoteEditor(false);
  buildShotList(); buildLibrary(); syncTitle(); buildStills(); buildInfo(); refreshSelBar(); syncSunBtn();
  ensureShotImages(activeShot(), false).then(render);
  render();
  histSettle();
  persistOnly();
}
function undo(){
  if(!undoStack.length) return;
  redoStack.push(snapshotState());
  applyState(undoStack.pop());
}
function redo(){
  if(!redoStack.length) return;
  undoStack.push(snapshotState());
  applyState(redoStack.pop());
}
document.getElementById('undoBtn').addEventListener('click', undo);
document.getElementById('redoBtn').addEventListener('click', redo);

// ---------------------------------------------------------------- jib / crane articulation & camera mounts
function isCrane(o){ return o && (o.kind === 'jib' || o.kind === 'technocrane'); }
function armLen(o){ return Math.max(60, o.w - 0.72*o.h); }
function trackSamplesWithLen(t){
  const smp = samplePath(t.pts, false, 10);
  const cum = [0];
  for(let i=1;i<smp.length;i++) cum.push(cum[i-1] + dist(smp[i-1].x,smp[i-1].y,smp[i].x,smp[i].y));
  return {smp, cum, total:cum[cum.length-1]};
}
function sampleAtDist(smp, cum, d){
  if(d <= 0) return smp[0];
  if(d >= cum[cum.length-1]) return smp[smp.length-1];
  let i = 1;
  while(cum[i] < d) i++;
  const t = (d - cum[i-1]) / Math.max(1e-6, cum[i] - cum[i-1]);
  return {x: smp[i-1].x + (smp[i].x - smp[i-1].x)*t,
          y: smp[i-1].y + (smp[i].y - smp[i-1].y)*t};
}
// keeps a rail-mounted crane's base on its track at rail.d, recomputes the
// center from the current arm rotation/length, and rebuilds the auto-path
// (remaining travel toward the far end) so ghosts show the planned ride.
function updateJibRail(jib, shot){
  if(!jib.rail) return;
  const t = shot.objects.find(x=>x.id===jib.rail.id && x.kind==='track');
  if(!t || !t.pts || t.pts.length < 2){ jib.rail = null; return; }
  const {smp, cum, total} = trackSamplesWithLen(t);
  jib.rail.d = clamp(jib.rail.d, 0, total);
  const base = sampleAtDist(smp, cum, jib.rail.d);
  const lx = -jib.w/2 + jib.h*.5;
  jib.x = base.x - lx*Math.cos(jib.rot);
  jib.y = base.y - lx*Math.sin(jib.rot);
  // auto movement path along the remaining track
  const dir = jib.rail.dir || 1;
  const target = dir > 0 ? total : 0;
  const path = [];
  const span = Math.abs(target - jib.rail.d);
  if(span > 40){
    const step = 90;
    for(let d = jib.rail.d + dir*step; dir>0 ? d < target : d > target; d += dir*step){
      const p = sampleAtDist(smp, cum, d);
      path.push({x:p.x, y:p.y, rot:jib.rot, len:armLen(jib)});
    }
    const pe = sampleAtDist(smp, cum, target);
    path.push({x:pe.x, y:pe.y, rot:jib.rot, len:armLen(jib)});
  }
  jib.path = path;
  jib.pathStraight = false;
  syncMounts(shot);
}
function updateRails(shot){
  for(const o of shot.objects) if(isCrane(o) && o.rail) updateJibRail(o, shot);
}
function jibBasePos(o){
  const lx = -o.w/2 + o.h*.5, c = Math.cos(o.rot), s = Math.sin(o.rot);
  return {x:o.x + lx*c, y:o.y + lx*s};
}
function jibHeadPos(o){
  const lx = o.w/2 - o.h*.22, c = Math.cos(o.rot), s = Math.sin(o.rot);
  return {x:o.x + lx*c, y:o.y + lx*s};
}
function syncMounts(shot){
  for(const cam of shot.objects){
    if(cam.cat !== 'camera' || !cam.mount) continue;
    const jib = shot.objects.find(j => j.id === cam.mount.id && isCrane(j));
    if(!jib){ cam.mount = null; continue; }
    const hp = jibHeadPos(jib);
    cam.x = hp.x; cam.y = hp.y;
    // camera keeps its aim relative to the arm, so swinging the arm pans the shot
    cam.rot = norm(jib.rot + (cam.mount.relRot || 0));
  }
}

// ---------------------------------------------------------------- hit testing
function hitHandle(wx, wy){
  const r = (H_R+4)/view.scale;
  for(const h of handleList()) if(dist(wx,wy,h.x,h.y) <= r) return h;
  return null;
}
function linePts(o){
  if(!o.mid) return [o.p1, o.p2];
  const cx=2*o.mid.x-(o.p1.x+o.p2.x)/2, cy=2*o.mid.y-(o.p1.y+o.p2.y)/2;
  const pts=[];
  for(let i=0;i<=12;i++){
    const t=i/12, u=1-t;
    pts.push({x:u*u*o.p1.x+2*u*t*cx+t*t*o.p2.x, y:u*u*o.p1.y+2*u*t*cy+t*t*o.p2.y});
  }
  return pts;
}
function hitObject(shot, wx, wy){
  for(let i = shot.objects.length-1; i >= 0; i--){
    const o = shot.objects[i];
    if(o.kind === 'track') continue;
    if(o.cat === 'line'){
      const thr = Math.max(10/view.scale, (o.weight||3)/2 + 6);
      const lp = linePts(o);
      for(let j=0;j<lp.length-1;j++)
        if(ptSeg(wx,wy,lp[j].x,lp[j].y,lp[j+1].x,lp[j+1].y).d <= thr) return o;
      continue;
    }
    const c = Math.cos(-o.rot), s = Math.sin(-o.rot);
    const dx = wx-o.x, dy = wy-o.y;
    const lx = dx*c - dy*s, ly = dx*s + dy*c;
    const pad = 6/view.scale;
    if(Math.abs(lx) <= o.w/2+pad && Math.abs(ly) <= o.h/2+pad) return o;
  }
  return null;
}
function hitTrack(shot, wx, wy){
  const thr = Math.max(16, 12/view.scale);
  for(let i = shot.objects.length-1; i >= 0; i--){
    const o = shot.objects[i];
    if(o.kind !== 'track' || !o.pts || o.pts.length < 2) continue;
    const smp = samplePath(o.pts, false, 18);
    for(let j=1;j<smp.length;j++){
      if(ptSeg(wx,wy, smp[j-1].x,smp[j-1].y, smp[j].x,smp[j].y).d <= thr) return o;
    }
  }
  return null;
}
function hitSun(shot, wx, wy){
  const s = shot.sun;
  return (s && s.on && dist(wx,wy,s.x,s.y) <= Math.max(26, 22/view.scale)) ? s : null;
}
let wallGroupDrag = false; // when true, dragging a wall moves its whole connected structure
function wallComponent(shot, start){
  const EPS = 2;
  const touches = (a,b)=>
    (Math.abs(a.x1-b.x1)<EPS && Math.abs(a.y1-b.y1)<EPS) ||
    (Math.abs(a.x1-b.x2)<EPS && Math.abs(a.y1-b.y2)<EPS) ||
    (Math.abs(a.x2-b.x1)<EPS && Math.abs(a.y2-b.y1)<EPS) ||
    (Math.abs(a.x2-b.x2)<EPS && Math.abs(a.y2-b.y2)<EPS);
  const comp = [start];
  const seen = new Set([start.id]);
  let grew = true;
  while(grew){
    grew = false;
    for(const w of shot.walls){
      if(seen.has(w.id)) continue;
      if(comp.some(c=>touches(w,c))){ comp.push(w); seen.add(w.id); grew = true; }
    }
  }
  return comp;
}
function hitWall(shot, wx, wy){
  const thr = Math.max(9/view.scale, 8);
  let best = null;
  for(const w of shot.walls){
    const {smp, cum, L} = wallGeom(w);
    for(let i=1;i<smp.length;i++){
      const r = ptSeg(wx,wy, smp[i-1].x,smp[i-1].y, smp[i].x,smp[i].y);
      if(r.d <= thr && (!best || r.d < best.d)){
        // t = arc-length fraction along the (possibly curved) wall
        const t = L ? (cum[i-1] + r.t*(cum[i]-cum[i-1]))/L : 0;
        best = {wall:w, d:r.d, t, x:r.x, y:r.y};
      }
    }
  }
  return best;
}
function hitOpening(shot, wx, wy){
  // openings select like walls: a thin band along the wall line, only
  // within the opening's span — no more giant catch-all circle
  const thr = Math.max(9/view.scale, 8);
  for(const w of shot.walls){
    if(!(w.openings||[]).length) continue;
    const {smp, cum, L} = wallGeom(w);
    let bd = Infinity, bdist = 0;
    for(let i=1;i<smp.length;i++){
      const r = ptSeg(wx,wy, smp[i-1].x,smp[i-1].y, smp[i].x,smp[i].y);
      if(r.d < bd){ bd = r.d; bdist = cum[i-1] + r.t*(cum[i]-cum[i-1]); }
    }
    if(bd > thr) continue;
    for(let i=0;i<w.openings.length;i++){
      const op = w.openings[i];
      if(Math.abs(bdist - op.t*L) <= op.w/2) return {wallId:w.id, index:i};
    }
  }
  return null;
}

// ---------------------------------------------------------------- snapping
function snapWallPoint(shot, wx, wy, excludeWallId){
  const thr = 14/view.scale;
  for(const w of shot.walls){
    if(w.id === excludeWallId) continue;
    if(dist(wx,wy,w.x1,w.y1) < thr) return {x:w.x1, y:w.y1};
    if(dist(wx,wy,w.x2,w.y2) < thr) return {x:w.x2, y:w.y2};
  }
  return {x: Math.round(wx/25)*25, y: Math.round(wy/25)*25};
}
function snapWallAngle(x1,y1,x2,y2,free){
  if(free) return {x:x2, y:y2};
  const dx = x2-x1, dy = y2-y1;
  const L = Math.hypot(dx,dy); if(L < 4) return {x:x2,y:y2};
  const a = Math.atan2(dy,dx);
  const q45 = Math.round(a/(Math.PI/4))*(Math.PI/4);
  const q90 = Math.round(a/(Math.PI/2))*(Math.PI/2);
  let target = null;
  if(Math.abs(norm(a - q90)) < rad(14)) target = q90;
  else if(Math.abs(norm(a - q45)) < rad(8)) target = q45;
  if(target === null) return {x:x2, y:y2};
  return {x: x1 + Math.cos(target)*L, y: y1 + Math.sin(target)*L};
}
function hourFromVec(ux, uy, nA){ // vector from sun disc toward the dragged handle = toward the sun
  if(nA === undefined || nA === null) nA = -Math.PI/2;
  const nx = Math.cos(nA), ny = Math.sin(nA);
  // clockwise angle from north to the drag vector
  let az = deg(Math.atan2(nx*uy - ny*ux, nx*ux + ny*uy));
  az = (az + 360) % 360;
  let h = 6 + (az - 90)/15;
  if(h < 0) h += 24;
  h = Math.round(h*4)/4; // 15-min steps
  return clamp(h, 4, 22);
}

// ---------------------------------------------------------------- input
const ptrs = new Map();
let pinch = null, postPinch = false;
function closeDrawers(){
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('rightPanel').classList.remove('open');
}
cv.addEventListener('contextmenu', e => e.preventDefault());
cv.addEventListener('pointercancel', e => {
  ptrs.delete(e.pointerId);
  if(ptrs.size < 2) pinch = null;
  if(ptrs.size === 0) postPinch = false;
  drag = null; cv.classList.remove('panning');
});

cv.addEventListener('wheel', e => {
  e.preventDefault();
  const {sx, sy} = evtPos(e);
  const before = toWorld(sx, sy);
  const f = Math.exp(-e.deltaY * 0.0016);
  view.scale = clamp(view.scale * f, 0.04, 8);
  const after = toWorld(sx, sy);
  view.x += before.x - after.x;
  view.y += before.y - after.y;
  updateZoomPct();
  render();
}, {passive:false});

cv.addEventListener('pointerdown', e => {
  cv.setPointerCapture(e.pointerId);
  hideCustomPop();
  closeDrawers();
  if(typeof hideExportPop === 'function') hideExportPop();
  ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
  if(ptrs.size === 2){
    const [a,b] = [...ptrs.values()];
    const r = cv.getBoundingClientRect();
    const mid = {x:(a.x+b.x)/2 - r.left, y:(a.y+b.y)/2 - r.top};
    pinch = {d0: Math.max(1, Math.hypot(a.x-b.x, a.y-b.y)),
             scale0: view.scale, wm: toWorld(mid.x, mid.y)};
    drag = null; cv.classList.remove('panning');
    closeNoteEditor(true);
    return;
  }
  if(ptrs.size > 2 || postPinch) return;
  const {sx, sy} = evtPos(e);
  const {x:wx, y:wy} = toWorld(sx, sy);
  const shot = activeShot();

  // shared viewer: look, pan, comment — nothing else
  if(window.VIEW_ONLY){
    if(typeof __viewerTap === 'function' && __viewerTap(wx, wy, e.clientX, e.clientY)) return;
    drag = {kind:'pan', sx, sy, vx:view.x, vy:view.y};
    cv.classList.add('panning');
    return;
  }

  if(e.button === 1 || spaceDown){
    drag = {kind:'pan', sx, sy, vx:view.x, vy:view.y};
    cv.classList.add('panning');
    return;
  }
  if(e.button === 2) return;

  if(tool === 'crop'){
    drag = {kind:'crop', x1:wx, y1:wy, x2:wx, y2:wy};
    return;
  }
  if(tool === 'marquee'){
    drag = {kind:'marquee', x1:wx, y1:wy, x2:wx, y2:wy};
    return;
  }
  if(tool === 'draw'){
    drag = {kind:'ink', pts:[{x:wx, y:wy}]};
    return;
  }
  if(tool === 'poly'){
    if(!polyDraw) return;
    polyDraw.pts.push({x:wx, y:wy});
    polyDraw.mouse = {x:wx, y:wy};
    render();
    return;
  }
  if(tool === 'wall'){
    const p = snapWallPoint(shot, wx, wy);
    drag = {kind:'drawWall', x1:p.x, y1:p.y, x2:p.x, y2:p.y};
    return;
  }
  if(tool === 'room'){
    const p = snapWallPoint(shot, wx, wy);
    drag = {kind:'drawRoom', x1:p.x, y1:p.y, x2:p.x, y2:p.y};
    return;
  }
  if(tool === 'door' || tool === 'window' || tool === 'gap'){
    const h = hitWall(shot, wx, wy);
    if(h){
      const L = wallGeom(h.wall).L;
      const w = tool==='door' ? 72 : tool==='gap' ? 90 : 100;
      const t = clamp(h.t, (w/2+6)/L, 1-(w/2+6)/L);
      h.wall.openings = h.wall.openings || [];
      h.wall.openings.push({id:uid(), t, w:Math.min(w, L*.8), type:tool, flip:false});
      sel = {type:'opening', wallId:h.wall.id, index:h.wall.openings.length-1};
      setTool('select');
      markDirty(); render(); refreshSelBar();
    }
    return;
  }

  // ---- select tool ----
  // group move: with a multi selection, grabbing any selected object or wall drags them all
  if(sel && sel.type === 'multi'){
    const hitO = hitObject(shot, wx, wy) || hitTrack(shot, wx, wy);
    const hitW = !hitO && hitWall(shot, wx, wy);
    if((hitO && sel.ids.includes(hitO.id)) ||
       (hitW && (sel.wallIds||[]).includes(hitW.wall.id))){
      drag = {kind:'moveMulti', wx, wy,
        items: sel.ids
          .map(id=>shot.objects.find(x=>x.id===id))
          .filter(ob=>ob && !ob.locked)
          .map(ob=>({o:ob, x:ob.x, y:ob.y,
            p1:ob.p1?{...ob.p1}:null, p2:ob.p2?{...ob.p2}:null, mid:ob.mid?{...ob.mid}:null,
            pts:ob.pts?ob.pts.map(p=>({...p})):null,
            path:(ob.path&&ob.path.length)?ob.path.map(p=>({...p})):null})),
        wallItems: (sel.wallIds||[])
          .map(id=>shot.walls.find(x=>x.id===id))
          .filter(w=>w && !w.locked)
          .map(w=>({w, x1:w.x1, y1:w.y1, x2:w.x2, y2:w.y2, mid:w.mid?{...w.mid}:null}))};
      return;
    }
    sel = null; refreshSelBar(); render(); // clicked outside the group — fall through
  }
  const h = hitHandle(wx, wy);
  if(h && sel){
    if(sel.type === 'sun'){
      if(h.id === 'sunH') drag = {kind:'sunRot', su:shot.sun};
      else if(h.id === 'sunN') drag = {kind:'sunNorth', su:shot.sun};
      return;
    }
    if(sel.type === 'object'){
      const o = shot.objects.find(x=>x.id===sel.id);
      if(h.id === 'rotate') drag = {kind:'rotate', o, craneBase: isCrane(o) ? jibBasePos(o) : null};
      else if(h.id === 'resize') drag = {kind:'resize', o, ratio:o.h/o.w};
      else if(h.id === 'jibHead') drag = {kind:'jibHead', o, B:jibBasePos(o)};
      else if(h.id === 'cardW') drag = {kind:'cardW', o, left:o.x - o.w/2};
      else if(h.id === 'tgrow') drag = {kind:'tgrow', o,
        left:o.x - o.w/2, top:o.y - o.h/2,
        avgW: Math.max(60, o.w / o.cells[0].length)};
      else if(h.id === 'ksink' || h.id === 'khob')
        drag = {kind:'kfix', o, key: h.id === 'ksink' ? 'sink' : 'hob'};
      else if(h.id.startsWith('beam')) drag = {kind:'beamfov', o};
      else if(h.id.startsWith('fov')) drag = {kind:'fov', o};
      else if(h.id === 'l1' || h.id === 'l2') drag = {kind:'lineEnd', o, end:h.id};
      else if(h.id === 'lm') drag = {kind:'lineMid', o};
      else if(h.id.startsWith('tp')) drag = {kind:'trackPt', o, i:+h.id.slice(2)};
      else if(h.id.startsWith('ch')) drag = {kind:'craneKey', o, i:+h.id.slice(2)};
      else if(h.id.startsWith('pf')) drag = {kind:'ptfov', o, i:+h.id.slice(3)};
      else if(h.id.startsWith('pr')) drag = {kind:'ptrot', o, i:+h.id.slice(2)};
      else if(h.id.startsWith('pt')) drag = {kind:'point', o, i:+h.id.slice(2)};
    } else if(sel.type === 'wall'){
      const w = shot.walls.find(x=>x.id===sel.id);
      drag = h.id === 'wm' ? {kind:'wallMid', w} : {kind:'wallEnd', w, end:h.id};
    }
    return;
  }

  // drag a selected object's label chip to reposition it
  if(sel && sel.type === 'object'){
    const so = shot.objects.find(x=>x.id===sel.id);
    if(so && so._labelRect && !so.locked &&
       wx >= so._labelRect.x && wx <= so._labelRect.x + so._labelRect.w &&
       wy >= so._labelRect.y && wy <= so._labelRect.y + so._labelRect.h){
      drag = {kind:'label', o:so, sx:wx, sy:wy, dx0:so.labelDX||0, dy0:so.labelDY||0};
      return;
    }
    if(so && so._frameRect && !so.locked &&
       wx >= so._frameRect.x && wx <= so._frameRect.x + so._frameRect.w &&
       wy >= so._frameRect.y && wy <= so._frameRect.y + so._frameRect.h){
      drag = {kind:'frame', o:so, sx:wx, sy:wy, dx0:so.frameDX ?? 70, dy0:so.frameDY ?? -85};
      return;
    }
    if(so && so.cat === 'sbrow' && !so.locked &&
       so._plusRow && dist(wx, wy, so._plusRow.x, so._plusRow.y) <= so._plusRow.r){
      addSbRowBelow(so); // chain the next shot row, scenes below shift down
      return;
    }
    if(so && so.cat === 'table' && !so.locked){
      // + chips live outside the frame — catch them here so they always respond
      const hp = z => z && dist(wx, wy, z.x, z.y) <= z.r;
      if(hp(so._plusRow)){
        so.cells.push(so.cells[0].map(()=>'' ));
        markDirty(); render();
        if(typeof openTableCell === 'function') openTableCell(so, so.cells.length-1, 0);
        return;
      }
      if(hp(so._plusCol)){
        so.cells.forEach(r=>r.push(''));
        markDirty(); render();
        if(typeof openTableCell === 'function') openTableCell(so, 0, so.cells[0].length-1);
        return;
      }
    }
    if(so && so.cat === 'avscript' && !so.locked){
      if(so._plusRow && dist(wx, wy, so._plusRow.x, so._plusRow.y) <= so._plusRow.r){
        addAvRow(so);
        return;
      }
      const del = (so._rowDels||[]).find(z=>dist(wx, wy, z.x, z.y) <= z.r);
      if(del){
        so.rows = so.rows.filter(r=>r.id !== del.rowId);
        markDirty(); render(); refreshSelBar();
        return;
      }
      const sd = (so._stillDels||[]).find(z=>dist(wx, wy, z.x, z.y) <= z.r);
      if(sd){
        const row = so.rows.find(r=>r.id === sd.rowId);
        if(row){ (row.imgs||[]).splice(sd.idx, 1); row.imgId = null; markDirty(); render(); }
        return;
      }
      const st = (so._stillRects||[]).find(z=> wx >= z.x && wx <= z.x + z.w &&
                                               wy >= z.y && wy <= z.y + z.h);
      if(st){
        const row = so.rows.find(r=>r.id === st.rowId);
        if(row) pickAvStill(row, st.idx === 'add' ? null : st.idx); // add or replace
        return;
      }
      const rr = (so._rowRects||[]).find(r=> wx >= r.x && wx <= r.x + r.w &&
                                             wy >= r.y && wy <= r.y + r.h);
      if(rr){ drag = {kind:'avrow', o:so, rowId:rr.rowId}; return; }
    }
    if(so && so.cat === 'schedule' && !so.locked){
      const del = (so._delRects||[]).find(z=>dist(wx, wy, z.x, z.y) <= z.r);
      if(del){
        so.items = schedItems(so).filter(it=>it.id !== del.itemId);
        markDirty(); render();
        return;
      }
      const rr = (so._rowRects||[]).find(r=> wx >= r.x && wx <= r.x + r.w &&
                                             wy >= r.y && wy <= r.y + r.h);
      if(rr){ drag = {kind:'schrow', o:so, itemId:rr.itemId}; return; }
    }
    if(so && (so.cat === 'proplist' || so.cat === 'gearlist') && !so.locked){
      // × chips live outside the frame: manual rows go, auto rows are dismissed
      const del = (so._plDels||[]).find(z=>dist(wx, wy, z.x, z.y) <= z.r);
      if(del){
        if(del.rowId) so.props[del.sceneId] = (so.props[del.sceneId]||[]).filter(r=>r.id !== del.rowId);
        else so.hide[del.key] = true;
        markDirty(); render();
        return;
      }
    }
    if(so && so.cat === 'listcard' && !so.locked){
      // list-card chips live outside the frame, so catch them here (before hitObject)
      if(so._plusRow && dist(wx, wy, so._plusRow.x, so._plusRow.y) <= so._plusRow.r){
        addListPerson(so);
        return;
      }
      const del = (so._rowDels||[]).find(z=>dist(wx, wy, z.x, z.y) <= z.r);
      if(del){ removeListPerson(del.personId); return; }
      // drag a row's grip to reorder it inside the registry
      const rr = (so._rowRects||[]).find(r=> wx >= r.x && wx <= r.x + r.w &&
                                             wy >= r.y && wy <= r.y + r.h);
      if(rr){ drag = {kind:'listrow', o:so, personId:rr.personId}; return; }
    }
  }
  const su = hitSun(shot, wx, wy);
  if(su){
    sel = {type:'sun'};
    drag = {kind:'sunMove', su, ox:su.x-wx, oy:su.y-wy};
    refreshSelBar(); render();
    return;
  }
  const obj = hitObject(shot, wx, wy);
  if(obj){
    sel = {type:'object', id:obj.id};
    if(obj.locked){ drag = null; refreshSelBar(); render(); return; }
    if(obj.cat === 'camera') obj.mount = null; // picking a camera up releases it from a jib
    // seated / bedded actors stay attached — dragging moves the pair; the
    // selection bar's "Out of the chair/bed" button is the way out
    drag = {kind:'move', o:obj, ox:obj.x-wx, oy:obj.y-wy};
    if(obj.cat === 'line'){ drag.wx=wx; drag.wy=wy; drag.p1o={...obj.p1}; drag.p2o={...obj.p2}; drag.mido=obj.mid?{...obj.mid}:null; }
    if(obj.cat === 'ink'){ drag.wx=wx; drag.wy=wy; drag.ptso=obj.pts.map(p=>({...p})); drag.xc=obj.x; drag.yc=obj.y; }
    if(['link','todo','audio','table','listcard','fieldcard','dayheader','avscript','colcard','schedule','proplist','gearlist'].includes(obj.cat)){ drag.tapX0=obj.x; drag.tapY0=obj.y; }
    if(obj.cat === 'link'){ drag.linkX0=obj.x; drag.linkY0=obj.y; }
    refreshSelBar(); render();
    return;
  }
  const trk = hitTrack(shot, wx, wy);
  if(trk){
    sel = {type:'object', id:trk.id};
    if(trk.locked){ refreshSelBar(); render(); return; }
    drag = {kind:'trackMove', o:trk, wx, wy, orig:trk.pts.map(p=>({...p}))};
    refreshSelBar(); render();
    return;
  }
  const op = hitOpening(shot, wx, wy);
  if(op){
    sel = {type:'opening', wallId:op.wallId, index:op.index};
    const wall = shot.walls.find(w=>w.id===op.wallId);
    drag = {kind:'moveOpening', wall, index:op.index};
    refreshSelBar(); render();
    return;
  }
  const wl = hitWall(shot, wx, wy);
  if(wl){
    sel = {type:'wall', id:wl.wall.id};
    if(wl.wall.locked){ refreshSelBar(); render(); return; }
    drag = {kind:'moveWall', w:wl.wall, wx, wy, x1:wl.wall.x1, y1:wl.wall.y1, x2:wl.wall.x2, y2:wl.wall.y2,
            mido: wl.wall.mid ? {...wl.wall.mid} : null};
    if(wallGroupDrag){
      // whole connected structure moves rigidly
      drag.group = wallComponent(shot, wl.wall).map(w=>({w, x1:w.x1, y1:w.y1, x2:w.x2, y2:w.y2,
        mid: w.mid ? {...w.mid} : null}));
    } else {
      // corners stay glued: endpoints of other walls that touch this wall's ends follow along
      const EPS = 2;
      drag.attach = [];
      for(const w2 of shot.walls){
        if(w2.id === wl.wall.id) continue;
        for(const end of [1,2]){
          const ex = w2['x'+end], ey = w2['y'+end];
          if((Math.abs(ex-wl.wall.x1)<EPS && Math.abs(ey-wl.wall.y1)<EPS) ||
             (Math.abs(ex-wl.wall.x2)<EPS && Math.abs(ey-wl.wall.y2)<EPS)){
            drag.attach.push({w:w2, end, ox:ex, oy:ey});
          }
        }
      }
    }
    refreshSelBar(); render();
    return;
  }
  sel = null; refreshSelBar();
  drag = {kind:'pan', sx, sy, vx:view.x, vy:view.y};
  cv.classList.add('panning');
  render();
});

cv.addEventListener('pointermove', e => {
  if(ptrs.has(e.pointerId)) ptrs.set(e.pointerId, {x:e.clientX, y:e.clientY});
  if(pinch){
    if(ptrs.size >= 2){
      const [a,b] = [...ptrs.values()];
      const r = cv.getBoundingClientRect();
      const mid = {x:(a.x+b.x)/2 - r.left, y:(a.y+b.y)/2 - r.top};
      const d = Math.max(1, Math.hypot(a.x-b.x, a.y-b.y));
      view.scale = clamp(pinch.scale0 * d/pinch.d0, .04, 8);
      view.x = pinch.wm.x - mid.x/view.scale;
      view.y = pinch.wm.y - mid.y/view.scale;
      updateZoomPct(); render();
    }
    return;
  }
  if(postPinch) return;
  const {sx, sy} = evtPos(e);
  const {x:wx, y:wy} = toWorld(sx, sy);
  const shot = activeShot();

  if(tool==='door' || tool==='window' || tool==='gap'){
    const h = hitWall(shot, wx, wy);
    hoverWall = h ? {wall:h.wall, t:h.t} : null;
    render();
  }
  if(tool==='poly' && polyDraw){
    polyDraw.mouse = {x:wx, y:wy};
    render();
  }
  if(!drag) return;

  switch(drag.kind){
    case 'pan':
      view.x = drag.vx - (sx - drag.sx)/view.scale;
      view.y = drag.vy - (sy - drag.sy)/view.scale;
      break;
    case 'crop':
      drag.x2 = wx; drag.y2 = wy;
      break;
    case 'ink': {
      const lp = drag.pts[drag.pts.length-1];
      if(dist(lp.x, lp.y, wx, wy) > 2.5/Math.max(view.scale,.3)) drag.pts.push({x:wx, y:wy});
      break;
    }
    case 'lineEnd': {
      const o = drag.o;
      o[drag.end==='l1' ? 'p1' : 'p2'] = {x:wx, y:wy};
      o.x = (o.p1.x+o.p2.x)/2; o.y = (o.p1.y+o.p2.y)/2;
      o.w = Math.max(14, dist(o.p1.x,o.p1.y,o.p2.x,o.p2.y));
      o.h = Math.max(14, (o.weight||3)*3);
      markDirty();
      break;
    }
    case 'lineMid': {
      const o = drag.o;
      const sm = {x:(o.p1.x+o.p2.x)/2, y:(o.p1.y+o.p2.y)/2};
      o.mid = (dist(wx,wy,sm.x,sm.y) < 8/Math.max(view.scale,.3)) ? null : {x:wx, y:wy};
      markDirty();
      break;
    }
    case 'label':
      drag.o.labelDX = drag.dx0 + (wx - drag.sx);
      drag.o.labelDY = drag.dy0 + (wy - drag.sy);
      markDirty();
      break;
    case 'frame':
      drag.o.frameDX = drag.dx0 + (wx - drag.sx);
      drag.o.frameDY = drag.dy0 + (wy - drag.sy);
      markDirty();
      break;
    case 'marquee':
      drag.x2 = wx; drag.y2 = wy;
      break;
    case 'moveMulti': {
      const dx = wx - drag.wx, dy = wy - drag.wy;
      for(const it of drag.items){
        const ob = it.o;
        ob.x = it.x + dx; ob.y = it.y + dy;
        if(it.p1){ ob.p1 = {x:it.p1.x+dx, y:it.p1.y+dy}; }
        if(it.p2){ ob.p2 = {x:it.p2.x+dx, y:it.p2.y+dy}; }
        if(it.mid){ ob.mid = {x:it.mid.x+dx, y:it.mid.y+dy}; }
        if(it.pts){ ob.pts = it.pts.map(p=>({...p, x:p.x+dx, y:p.y+dy})); }
        if(it.path){ ob.path = it.path.map(p=>({...p, x:p.x+dx, y:p.y+dy})); }
      }
      for(const it of (drag.wallItems || [])){
        it.w.x1 = it.x1 + dx; it.w.y1 = it.y1 + dy;
        it.w.x2 = it.x2 + dx; it.w.y2 = it.y2 + dy;
        if(it.mid) it.w.mid = {x:it.mid.x + dx, y:it.mid.y + dy};
      }
      markDirty();
      break;
    }
    case 'listrow': {
      // rows reorder live in the registry as the grip drags
      const o = drag.o;
      const idx = Math.floor((wy - (o.y - o.h/2) - LIST_GEO.titleH - LIST_GEO.headH) / LIST_GEO.rowH);
      if(moveListRow(o, drag.personId, idx)) markDirty();
      break;
    }
    case 'schrow': {
      // schedule rows reorder live while the grip drags (fixed row height)
      const o = drag.o;
      const rowH = 24, headH = 26 + 10 + 26; // title + pad + calls line
      const idx = clamp(Math.floor((wy - (o.y - o.h/2) - headH) / rowH), 0, o.items.length - 1);
      const from = o.items.findIndex(it=>it.id === drag.itemId);
      if(from > -1 && from !== idx){
        const [row] = o.items.splice(from, 1);
        o.items.splice(idx, 0, row);
        markDirty();
      }
      break;
    }
    case 'avrow': {
      // AV rows reorder live using the per-row heights
      const o = drag.o;
      const hs2 = o._rowHs || [];
      let ly = wy - (o.y - o.h/2) - AVS.titleH - AVS.headH;
      let idx = 0;
      for(let i=0;i<hs2.length;i++){ if(ly > hs2[i]){ ly -= hs2[i]; idx++; } else break; }
      idx = clamp(idx, 0, o.rows.length - 1);
      const from = o.rows.findIndex(r=>r.id === drag.rowId);
      if(from > -1 && from !== idx){
        const [row] = o.rows.splice(from, 1);
        o.rows.splice(idx, 0, row);
        markDirty();
      }
      break;
    }
    case 'drawWall': {
      const p = snapWallPoint(shot, wx, wy);
      const q = snapWallAngle(drag.x1, drag.y1, p.x, p.y, e.shiftKey);
      drag.x2 = q.x; drag.y2 = q.y;
      break;
    }
    case 'drawRoom': {
      const p = snapWallPoint(shot, wx, wy);
      drag.x2 = p.x; drag.y2 = p.y;
      break;
    }
    case 'move': {
      const o = drag.o;
      if(o.cat === 'line' && drag.p1o){
        const dx = wx - drag.wx, dy = wy - drag.wy;
        o.p1 = {x:drag.p1o.x+dx, y:drag.p1o.y+dy};
        o.p2 = {x:drag.p2o.x+dx, y:drag.p2o.y+dy};
        if(drag.mido) o.mid = {x:drag.mido.x+dx, y:drag.mido.y+dy};
        o.x = (o.p1.x+o.p2.x)/2; o.y = (o.p1.y+o.p2.y)/2;
        markDirty(); break;
      }
      if(o.cat === 'ink' && drag.ptso){
        const dx = wx - drag.wx, dy = wy - drag.wy;
        o.pts = drag.ptso.map(p=>({x:p.x+dx, y:p.y+dy}));
        o.x = drag.xc + dx; o.y = drag.yc + dy;
        markDirty(); break;
      }
      if(isCrane(o) && o.rail){
        const t = shot.objects.find(x=>x.id===o.rail.id && x.kind==='track');
        if(t && t.pts && t.pts.length > 1){
          const {smp, cum} = trackSamplesWithLen(t);
          let bi = 0, bd = Infinity;
          for(let i=0;i<smp.length;i++){
            const dd = dist(wx, wy, smp[i].x, smp[i].y);
            if(dd < bd){ bd = dd; bi = i; }
          }
          if(bd > 110){ // pulled well clear of the rails → release
            o.rail = null; o.path = [];
            toast('Crane released from the track');
          } else {
            o.rail.d = cum[bi];
            updateJibRail(o, shot);
            markDirty();
            break;
          }
        } else o.rail = null;
      }
      o.x = wx + drag.ox; o.y = wy + drag.oy;
      if(e.shiftKey){ o.x = Math.round(o.x/25)*25; o.y = Math.round(o.y/25)*25; }
      if(o.kind === 'wheelchair' || o.kind === 'bed_hospital'){
        // the chair / bed carries whoever is in it
        for(const a of shot.objects)
          if(a.cat === 'actor' && a.mount && (a.mount.type === 'seat' || a.mount.type === 'bed') && a.mount.id === o.id){
            a.x = o.x; a.y = o.y;
          }
      }
      if(o.kind === 'dollycart'){
        // the cart carries its camera
        for(const c of shot.objects)
          if(c.cat === 'camera' && c.mount && c.mount.type === 'cart' && c.mount.id === o.id){
            c.x = o.x; c.y = o.y;
          }
      }
      if(o.cat === 'actor' && o.mount && (o.mount.type === 'seat' || o.mount.type === 'bed')){
        // …and vice versa: moving the actor takes the chair / bed along
        const v = shot.objects.find(x=>x.id === o.mount.id);
        if(v && !v.locked){ v.x = o.x; v.y = o.y; }
      }
      markDirty();
      break;
    }
    case 'kfix': {
      // slide the sink / hob along the counter (pointer → object-local → run fraction)
      const o = drag.o;
      const dx = wx - o.x, dy = wy - o.y;
      const kc = Math.cos(-o.rot), ks = Math.sin(-o.rot);
      o[drag.key] = kitchenParamFromLocal(o.kind, o.w, o.h, dx*kc - dy*ks, dx*ks + dy*kc);
      markDirty();
      break;
    }
    case 'rotate': {
      let a;
      if(drag.craneBase){
        // cranes swing around their BASE, not the icon center
        a = Math.atan2(wy - drag.craneBase.y, wx - drag.craneBase.x);
      } else {
        a = Math.atan2(wy - drag.o.y, wx - drag.o.x) + Math.PI/2;
      }
      if(!e.shiftKey){
        const q = Math.round(a/rad(15))*rad(15);
        if(Math.abs(norm(a-q)) < rad(4)) a = q;
      }
      drag.o.rot = norm(a);
      if(drag.craneBase && !drag.o.rail){
        const lx = -drag.o.w/2 + drag.o.h*.5;
        drag.o.x = drag.craneBase.x - lx*Math.cos(drag.o.rot);
        drag.o.y = drag.craneBase.y - lx*Math.sin(drag.o.rot);
      }
      if(drag.o.cat === 'camera' && drag.o.mount){
        const j = shot.objects.find(x=>x.id===drag.o.mount.id);
        if(j) drag.o.mount.relRot = norm(drag.o.rot - j.rot);
      }
      if(isCrane(drag.o) && drag.o.rail) updateJibRail(drag.o, shot); // pivot stays on the rails
      markDirty();
      break;
    }
    case 'resize': {
      const o = drag.o;
      const c = Math.cos(-o.rot), s = Math.sin(-o.rot);
      const lx = (wx-o.x)*c - (wy-o.y)*s, ly = (wx-o.x)*s + (wy-o.y)*c;
      if(o.cat === 'image'){
        o.w = clamp(Math.abs(lx)*2, 24, 4000);
        o.h = o.w * drag.ratio;
      } else {
        o.w = clamp(Math.abs(lx)*2, 10, 6000);
        o.h = clamp(Math.abs(ly)*2, 10, 6000);
        const def = PROPS[o.kind];
        if((o.cat === 'actor' && !o.kind.startsWith('animal')) || (def && def.round)){
          const m = Math.max(o.w, o.h); o.w = m; o.h = m;
        }
      }
      markDirty();
      break;
    }
    case 'fov': {
      const o = drag.o;
      const a = Math.atan2(wy-o.y, wx-o.x);
      o.fov = clamp(Math.abs(deg(norm(a - o.rot)))*2, 4, 175);
      o.range = clamp(dist(wx,wy,o.x,o.y), 40, 8000);
      o.lens = null;
      markDirty();
      break;
    }
    case 'cardW': {
      // widen the card from its right edge; left edge stays anchored
      const o = drag.o;
      o.userW = clamp(wx - drag.left, 344, 900);
      o.x = drag.left + o.w/2;
      markDirty();
      break;
    }
    case 'tgrow': {
      // dragging past the edge adds cells; dragging back removes them
      const o = drag.o;
      const wantC = clamp(Math.round((wx - drag.left) / drag.avgW), 1, 40);
      const wantR = clamp(1 + Math.round((wy - drag.top - 30) / 28), 2, 200);
      let changed = false;
      while(o.cells[0].length < wantC){ o.cells.forEach(r=>r.push('')); changed = true; }
      while(o.cells[0].length > wantC){ o.cells.forEach(r=>r.pop()); changed = true; }
      while(o.cells.length < wantR){ o.cells.push(o.cells[0].map(()=>'')); changed = true; }
      while(o.cells.length > wantR){ o.cells.pop(); changed = true; }
      // keep the top-left corner anchored while the card self-sizes around its center
      o.x = drag.left + o.w/2; o.y = drag.top + o.h/2;
      if(changed) markDirty();
      break;
    }
    case 'beamfov': {
      // light beam edges work like a camera's FOV handles
      const o = drag.o;
      const b = LIGHT_BEAMS[o.kind] || {};
      const ax = o.rot + (b.axis || 0);
      const a = Math.atan2(wy-o.y, wx-o.x);
      o.beamSpread = clamp(Math.abs(deg(norm(a - ax)))*2, 8, 165);
      o.beamRange = clamp(dist(wx,wy,o.x,o.y), 50, 1200);
      markDirty();
      break;
    }
    case 'point':
      drag.o.path[drag.i].x = wx; drag.o.path[drag.i].y = wy; markDirty();
      break;
    case 'craneKey': {
      const o = drag.o, p = o.path[drag.i];
      const maxL = o.kind === 'technocrane' ? 1600 : 900;
      p.len = clamp(dist(wx, wy, p.x, p.y), 120, maxL);
      p.rot = Math.atan2(wy - p.y, wx - p.x);
      markDirty();
      break;
    }
    case 'ptrot': {
      const p = drag.o.path[drag.i];
      let a = Math.atan2(wy - p.y, wx - p.x) + Math.PI/2;
      if(!e.shiftKey){
        const q = Math.round(a/rad(15))*rad(15);
        if(Math.abs(norm(a-q)) < rad(4)) a = q;
      }
      p.rot = norm(a); markDirty();
      break;
    }
    case 'ptfov': {
      const o = drag.o, p = o.path[drag.i];
      const pr = prot(o, drag.i);
      const a = Math.atan2(wy-p.y, wx-p.x);
      p.fov = clamp(Math.abs(deg(norm(a - pr)))*2, 4, 175);
      p.range = clamp(dist(wx,wy,p.x,p.y), 40, 8000);
      markDirty();
      break;
    }
    case 'trackPt':
      drag.o.pts[drag.i].x = wx; drag.o.pts[drag.i].y = wy;
      trackCentroid(drag.o); updateRails(shot); markDirty();
      break;
    case 'trackMove': {
      const dx = wx - drag.wx, dy = wy - drag.wy;
      drag.o.pts.forEach((p,i)=>{ p.x = drag.orig[i].x + dx; p.y = drag.orig[i].y + dy; });
      trackCentroid(drag.o); updateRails(shot); markDirty();
      break;
    }
    case 'sunMove':
      drag.su.x = wx + drag.ox; drag.su.y = wy + drag.oy; markDirty();
      break;
    case 'sunRot':
      drag.su.hour = hourFromVec(wx - drag.su.x, wy - drag.su.y, northAngle(drag.su));
      markDirty(); refreshSelBar();
      break;
    case 'sunNorth':
      drag.su.north = Math.atan2(wy - drag.su.y, wx - drag.su.x);
      markDirty(); refreshSelBar();
      break;
    case 'jibHead': {
      const o = drag.o, B = drag.B;
      const maxL = o.kind === 'technocrane' ? 1600 : 900;
      const L = clamp(dist(wx, wy, B.x, B.y), 120, maxL);
      const rot = Math.atan2(wy - B.y, wx - B.x);
      o.rot = rot;
      o.w = L + 0.72*o.h;
      const lx = -o.w/2 + o.h*.5;
      o.x = B.x - lx*Math.cos(rot);
      o.y = B.y - lx*Math.sin(rot);
      if(o.rail) updateJibRail(o, shot); // arm changed → rebuild the ride path offsets
      markDirty();
      break;
    }
    case 'wallEnd': {
      const p = snapWallPoint(shot, wx, wy, drag.w.id);
      const other = drag.end==='w1' ? {x:drag.w.x2,y:drag.w.y2} : {x:drag.w.x1,y:drag.w.y1};
      const q = snapWallAngle(other.x, other.y, p.x, p.y, e.shiftKey);
      if(drag.end === 'w1'){ drag.w.x1 = q.x; drag.w.y1 = q.y; }
      else { drag.w.x2 = q.x; drag.w.y2 = q.y; }
      markDirty();
      break;
    }
    case 'wallMid': {
      // bow the wall — drop the handle near the chord center to straighten it
      const w = drag.w;
      const cm = {x:(w.x1+w.x2)/2, y:(w.y1+w.y2)/2};
      w.mid = (dist(wx,wy,cm.x,cm.y) < 9/Math.max(view.scale,.3)) ? null : {x:wx, y:wy};
      markDirty();
      break;
    }
    case 'moveWall': {
      const dx0 = wx - drag.wx, dy0 = wy - drag.wy;
      drag.w.x1 = drag.x1+dx0; drag.w.y1 = drag.y1+dy0;
      drag.w.x2 = drag.x2+dx0; drag.w.y2 = drag.y2+dy0;
      if(e.shiftKey){
        const gx = Math.round(drag.w.x1/25)*25 - drag.w.x1, gy = Math.round(drag.w.y1/25)*25 - drag.w.y1;
        drag.w.x1+=gx; drag.w.y1+=gy; drag.w.x2+=gx; drag.w.y2+=gy;
      }
      const dx = drag.w.x1 - drag.x1, dy = drag.w.y1 - drag.y1; // final delta after snap
      if(drag.mido) drag.w.mid = {x:drag.mido.x+dx, y:drag.mido.y+dy};
      if(drag.group){
        for(const g of drag.group){
          if(g.w.id === drag.w.id) continue;
          g.w.x1 = g.x1+dx; g.w.y1 = g.y1+dy;
          g.w.x2 = g.x2+dx; g.w.y2 = g.y2+dy;
          if(g.mid) g.w.mid = {x:g.mid.x+dx, y:g.mid.y+dy};
        }
      } else if(drag.attach){
        for(const a of drag.attach){
          a.w['x'+a.end] = a.ox+dx;
          a.w['y'+a.end] = a.oy+dy;
        }
      }
      markDirty();
      break;
    }
    case 'moveOpening': {
      const w = drag.wall;
      const {smp, cum, L} = wallGeom(w);
      let bd = Infinity, bt = 0;
      for(let i=1;i<smp.length;i++){
        const r = ptSeg(wx,wy, smp[i-1].x,smp[i-1].y, smp[i].x,smp[i].y);
        if(r.d < bd){ bd = r.d; bt = L ? (cum[i-1] + r.t*(cum[i]-cum[i-1]))/L : 0; }
      }
      const op = w.openings[drag.index];
      op.t = clamp(bt, (op.w/2)/L, 1-(op.w/2)/L);
      markDirty();
      break;
    }
  }
  if(drag && drag.o && isCrane(drag.o) &&
     (drag.kind==='move' || drag.kind==='rotate' || drag.kind==='resize' || drag.kind==='jibHead')){
    syncMounts(shot);
  }
  render();
});

cv.addEventListener('pointerup', e => {
  ptrs.delete(e.pointerId);
  if(pinch){
    if(ptrs.size < 2){ pinch = null; postPinch = ptrs.size > 0; }
    drag = null; cv.classList.remove('panning');
    return;
  }
  if(postPinch){
    if(ptrs.size === 0) postPinch = false;
    return;
  }
  if(!drag) return;
  const shot = activeShot();
  if(drag.kind === 'crop'){
    const x1=Math.min(drag.x1,drag.x2), x2=Math.max(drag.x1,drag.x2);
    const y1=Math.min(drag.y1,drag.y2), y2=Math.max(drag.y1,drag.y2);
    const cropB = (x2-x1 > 40 && y2-y1 > 40) ? {minX:x1, minY:y1, maxX:x2, maxY:y2} : null;
    drag = null;
    setTool('select');
    if(cropB) doPNGExport(cropB);
    else toast('Crop area too small — export cancelled');
    render();
    return;
  }
  if(drag.kind === 'marquee'){
    const x1 = Math.min(drag.x1,drag.x2), x2 = Math.max(drag.x1,drag.x2);
    const y1 = Math.min(drag.y1,drag.y2), y2 = Math.max(drag.y1,drag.y2);
    const ids = shot.objects.filter(o=>{
      if(o.locked) return false;
      const hw = (o.w||20)/2, hh = (o.h||20)/2; // bbox test — rotation ignored, fine for grouping
      return o.x+hw >= x1 && o.x-hw <= x2 && o.y+hh >= y1 && o.y-hh <= y2;
    }).map(o=>o.id);
    // walls count as structure: both endpoints inside the box
    const wallIds = shot.walls.filter(w=>!w.locked &&
      w.x1 >= x1 && w.x1 <= x2 && w.y1 >= y1 && w.y1 <= y2 &&
      w.x2 >= x1 && w.x2 <= x2 && w.y2 >= y1 && w.y2 <= y2).map(w=>w.id);
    const total = ids.length + wallIds.length;
    sel = total > 1 ? {type:'multi', ids, wallIds}
        : ids.length === 1 ? {type:'object', id:ids[0]}
        : wallIds.length === 1 ? {type:'wall', id:wallIds[0]} : null;
    setTool('select');
    drag = null;
    if(histPushed) histSettle();
    refreshSelBar(); render();
    if(total > 1) toast(total + ' selected — drag to move all · Cmd/Ctrl+C copies');
    return;
  }
  if(drag.kind === 'ink'){
    if(drag.pts.length > 2){
      let mnx=Infinity,mny=Infinity,mxx=-Infinity,mxy=-Infinity;
      drag.pts.forEach(p=>{mnx=Math.min(mnx,p.x);mny=Math.min(mny,p.y);mxx=Math.max(mxx,p.x);mxy=Math.max(mxy,p.y);});
      const o = {id:uid(), cat:'ink', kind:'ink', pts:drag.pts,
        x:(mnx+mxx)/2, y:(mny+mxy)/2, w:Math.max(20,mxx-mnx), h:Math.max(20,mxy-mny),
        rot:0, color:inkColor, weight:inkWeight, label:'', path:[]};
      shot.objects.push(o);
      sel = {type:'object', id:o.id};
      markDirty(); refreshSelBar();
    }
    drag = null;
    if(histPushed) histSettle();
    render();
    return; // stay in draw tool for the next stroke
  }
  // a clean tap on a link (no real movement) opens it in a new tab
  if(drag.kind === 'move' && drag.o && drag.o.cat === 'link' && drag.linkX0 !== undefined){
    if(dist(drag.o.x, drag.o.y, drag.linkX0, drag.linkY0) < 4/Math.max(view.scale,.3) && drag.o.url){
      window.open(/^https?:\/\//i.test(drag.o.url) ? drag.o.url : 'https://' + drag.o.url, '_blank');
    }
  }
  // clean taps: to-do checkbox, audio play, table + chips
  if(drag.kind === 'move' && drag.o && drag.tapX0 !== undefined &&
     dist(drag.o.x, drag.o.y, drag.tapX0, drag.tapY0) < 4/Math.max(view.scale,.3)){
    const o = drag.o;
    const {sx:usx, sy:usy} = evtPos(e);
    const up = toWorld(usx, usy);
    if(o.cat === 'todo'){
      // only the checkbox zone toggles — the text area is for dblclick editing
      const rowH = 32, top = o.label ? 36 : 8;
      const i = Math.floor((up.y - o.y + o.h/2 - top)/rowH);
      if(o.items && i >= 0 && i < o.items.length && (up.x - o.x + o.w/2) < 34){
        o.items[i].done = !o.items[i].done;
        markDirty(); render();
      }
    } else if(o.cat === 'audio'){
      if(o._playZone && up.x >= o._playZone.x1 && up.x <= o._playZone.x2 &&
         typeof toggleAudio === 'function') toggleAudio(o);
    } else if(o.cat === 'table'){
      const hitPlus = z => z && dist(up.x, up.y, z.x, z.y) <= z.r;
      if(hitPlus(o._plusRow)){
        o.cells.push(o.cells[0].map(()=>'' ));
        markDirty(); render();
        if(typeof openTableCell === 'function') openTableCell(o, o.cells.length-1, 0);
      } else if(hitPlus(o._plusCol)){
        o.cells.forEach(r=>r.push(''));
        markDirty(); render();
        if(typeof openTableCell === 'function') openTableCell(o, 0, o.cells[0].length-1);
      }
    } else if(o.cat === 'listcard'){
      const hitPlus = z => z && dist(up.x, up.y, z.x, z.y) <= z.r;
      const del = (o._rowDels||[]).find(z=>dist(up.x, up.y, z.x, z.y) <= z.r);
      if(hitPlus(o._plusRow)){
        addListPerson(o);
      } else if(del){
        removeListPerson(del.personId);
      } else if(typeof listCellAt === 'function'){
        const cell = listCellAt(o, up.x, up.y); // cells are click-to-edit
        if(cell) openListCell(o, cell.r, cell.c);
      }
    } else if(o.cat === 'fieldcard'){
      if(typeof fieldCellAt === 'function'){
        const row = fieldCellAt(o, up.x, up.y); // values are click-to-edit
        if(row !== null) openFieldCell(o, row);
      }
    } else if(o.cat === 'dayheader'){
      if(typeof dayCellAt === 'function'){
        const key = dayCellAt(o, up.x, up.y);
        if(key) openDayCell(o, key);
      }
    } else if(o.cat === 'avscript'){
      if(typeof avCellAt === 'function'){
        const cell = avCellAt(o, up.x, up.y);
        if(cell && cell.key !== 'still') openAvCell(o, cell.rowId, cell.key);
      }
    } else if(o.cat === 'colcard'){
      if(typeof colCellAt === 'function'){
        const key = colCellAt(o, up.x, up.y);
        if(key) openColCell(o, key);
      }
    } else if(o.cat === 'schedule'){
      const hitZ = zones => (zones||[]).find(z=> up.x >= z.x && up.x <= z.x + z.w &&
                                                 up.y >= z.y && up.y <= z.y + z.h);
      const cr = hitZ(o._checkRects);
      const tr = !cr && hitZ(o._timeRects);
      const lr = !cr && !tr && hitZ(o._labelRects);
      const dr = !cr && !tr && !lr && hitZ(o._durRects);
      if(cr){
        const it = schedItems(o).find(x=>x.id === cr.itemId);
        if(it){ it.on = it.on === false; markDirty(); render(); }
      } else if(tr){ openSchedCell(o, tr.itemId, 'time'); }
      else if(lr){ openSchedCell(o, lr.itemId, 'label'); }
      else if(dr){ openSchedCell(o, dr.itemId, 'dur'); }
    } else if(o.cat === 'proplist' || o.cat === 'gearlist'){
      const hitZ = zones => (zones||[]).find(z=> up.x >= z.x && up.x <= z.x + z.w &&
                                                 up.y >= z.y && up.y <= z.y + z.h);
      const cb = hitZ(o._plChecks);
      const ad = !cb && hitZ(o._plAdds);
      const nm = !cb && !ad && hitZ(o._plNames);
      if(cb){
        if(cb.rowId){
          const r = ((o.props||{})[cb.sceneId]||[]).find(x=>x.id === cb.rowId);
          if(r) r.done = !r.done;
        } else o.done[cb.key] = !o.done[cb.key];
        markDirty(); render();
      } else if(ad){ addPropRow(o, ad.sceneId); }
      else if(nm && nm.rowId){ openPropCell(o, nm.sceneId, nm.rowId); } // auto rows aren't renamed — dismiss + add instead
    }
  }
  if(drag.kind === 'drawWall'){
    if(dist(drag.x1,drag.y1,drag.x2,drag.y2) > 12){
      const w = {id:uid(), x1:drag.x1, y1:drag.y1, x2:drag.x2, y2:drag.y2, openings:[], locked:false};
      shot.walls.push(w);
      sel = {type:'wall', id:w.id};
      markDirty();
    }
  }
  if(drag.kind === 'drawRoom'){
    const x1=Math.min(drag.x1,drag.x2), x2=Math.max(drag.x1,drag.x2);
    const y1=Math.min(drag.y1,drag.y2), y2=Math.max(drag.y1,drag.y2);
    if(x2-x1 > 20 && y2-y1 > 20){
      shot.walls.push(
        {id:uid(), x1, y1, x2, y2:y1, openings:[], locked:false},
        {id:uid(), x1:x2, y1, x2, y2, openings:[], locked:false},
        {id:uid(), x1:x2, y1:y2, x2:x1, y2, openings:[], locked:false},
        {id:uid(), x1, y1:y2, x2:x1, y2:y1, openings:[], locked:false},
      );
      markDirty();
      setTool('select');
    }
  }
  // actor dropped on a wheelchair / hospital bed → attached (they move as one)
  if(drag.kind === 'move' && drag.o.cat === 'actor' && !drag.o.mount){
    const a = drag.o;
    for(const v of shot.objects){
      const isChair = v.kind === 'wheelchair', isBed = v.kind === 'bed_hospital';
      if(!isChair && !isBed) continue;
      if(dist(a.x, a.y, v.x, v.y) < (isBed ? 60 : 46)){
        a.mount = {type: isChair ? 'seat' : 'bed', id: v.id};
        a.x = v.x; a.y = v.y;
        toast((isChair ? 'Seated' : 'In the bed') + ' — ' + (a.label || 'the actor') +
          ' and the ' + (isChair ? 'wheelchair' : 'bed') + ' now move as one · "Out of the ' +
          (isChair ? 'chair' : 'bed') + '" in the selection bar releases');
        markDirty(); refreshSelBar();
        break;
      }
    }
  }
  // camera dropped on a jib head → mount it (it follows the arm)
  let mounted = false;
  if(drag.kind === 'move' && drag.o.cat === 'camera'){
    const cam = drag.o;
    for(const j of shot.objects){
      if(!isCrane(j)) continue;
      const hp = jibHeadPos(j);
      if(dist(cam.x, cam.y, hp.x, hp.y) < 50){
        cam.mount = {type:'jib', id:j.id, relRot: norm(cam.rot - j.rot)};
        cam.x = hp.x; cam.y = hp.y;
        toast('Camera mounted on the ' + (j.kind==='technocrane'?'technocrane':'jib') + ' head — it follows the arm');
        markDirty(); refreshSelBar();
        mounted = true;
        break;
      }
    }
  }
  // crane base dropped on a dolly track → it clips on and stays railed
  if(drag.kind === 'move' && isCrane(drag.o) && !drag.o.rail){
    const jib = drag.o;
    const base = jibBasePos(jib);
    for(const t of shot.objects){
      if(t.kind !== 'track' || !t.pts || t.pts.length < 2) continue;
      const {smp, cum, total} = trackSamplesWithLen(t);
      let bi = 0, bd = Infinity;
      for(let i=0;i<smp.length;i++){
        const dd = dist(base.x, base.y, smp[i].x, smp[i].y);
        if(dd < bd){ bd = dd; bi = i; }
      }
      if(bd < 55){
        jib.rail = {id:t.id, d:cum[bi], dir: cum[bi] < total/2 ? 1 : -1};
        updateJibRail(jib, shot);
        toast((jib.kind==='technocrane'?'Technocrane':'Jib') + ' clipped onto the track — drag it to slide along the rails');
        markDirty(); refreshSelBar();
        break;
      }
    }
  }
  // camera dropped near a dolly track end → snap on and inherit its path
  if(!mounted && drag.kind === 'move' && drag.o.cat === 'camera'){
    const cam = drag.o;
    outer:
    for(const t of shot.objects){
      if(t.kind !== 'track' || !t.pts || t.pts.length < 2) continue;
      const ends = [
        {p:t.pts[0], rest:t.pts.slice(1)},
        {p:t.pts[t.pts.length-1], rest:t.pts.slice(0,-1).reverse()},
      ];
      for(const end of ends){
        if(dist(cam.x, cam.y, end.p.x, end.p.y) < 60){
          cam.x = end.p.x; cam.y = end.p.y;
          cam.path = end.rest.map(p=>({x:p.x, y:p.y}));
          cam.pathStraight = t.pts.length < 3;
          toast('Camera snapped to dolly track — it now rides the full track');
          markDirty(); refreshSelBar();
          break outer;
        }
      }
    }
    // …or dropped ON a dolly cart → it rides the cart (like the jib head)
    if(!cam.mount && !(cam.path && cam.path.length)){
      for(const cart of shot.objects){
        if(cart.kind !== 'dollycart') continue;
        if(dist(cam.x, cam.y, cart.x, cart.y) < 55){
          cam.mount = {type:'cart', id:cart.id};
          cam.x = cart.x; cam.y = cart.y;
          toast('Camera on the dolly cart — moving or animating the cart takes it along; pick the camera up to step off');
          markDirty(); refreshSelBar();
          break;
        }
      }
    }
  }
  cv.classList.remove('panning');
  drag = null;
  if(histPushed) histSettle();
  render(); refreshSelBar();
});

cv.addEventListener('dblclick', e => {
  if(window.VIEW_ONLY) return;
  if(tool === 'poly'){ finishPoly(); return; }
  const {sx,sy} = evtPos(e);
  const {x:wx,y:wy} = toWorld(sx,sy);
  const o = hitObject(activeShot(), wx, wy);
  if(o){
    sel = {type:'object', id:o.id};
    refreshSelBar(); render();
    if(o.cat === 'subboard'){ enterSubboard(o); return; }
    if(o.cat === 'note' || o.cat === 'text'){ openNoteEditor(o); return; }
    if(o.cat === 'todo'){
      const rowH = 32, top = o.label ? 36 : 8;
      const i = Math.floor((wy - o.y + o.h/2 - top)/rowH);
      if(o.items && i >= 0 && i < o.items.length){
        openTodoItem(o, i);
      } else {
        o.items = o.items || [];
        o.items.push({t:'', done:false});
        markDirty(); render();
        openTodoItem(o, o.items.length-1);
      }
      return;
    }
    if(o.cat === 'script'){
      const pad = 18, headH = o.mode==='av' ? 30 : 12;
      const lx = wx - o.x; // local (rot=0 for these blocks)
      if(o.mode === 'av'){
        const half = o.w/2 - pad*1.5;
        if(lx < 0) openNoteEditor(o, 'text', {x:-o.w/2+pad, y:-o.h/2+headH, w:half, h:o.h-headH-pad}, o.fontSize||12.5);
        else openNoteEditor(o, 'textR', {x:pad/2, y:-o.h/2+headH, w:half, h:o.h-headH-pad}, o.fontSize||12.5);
      } else {
        openNoteEditor(o, 'text', {x:-o.w/2+pad, y:-o.h/2+headH, w:o.w-pad*2, h:o.h-headH-pad}, o.fontSize||12.5);
      }
      return;
    }
    if(o.cat === 'sbrow'){
      const lx = wx - o.x;
      const z1 = o.w*.28, z2 = o.w*.30;
      if(lx < -o.w/2 + z1){
        openNoteEditor(o, 'title', {x:-o.w/2+12, y:-o.h/2+8, w:z1-22, h:40}, 13);
      } else if(lx < -o.w/2 + z1 + z2){
        pickSbImage(o);
      } else {
        openNoteEditor(o, 'desc', {x:-o.w/2+z1+z2+10, y:-o.h/2+8, w:o.w-z1-z2-20, h:o.h-16}, 12);
      }
      return;
    }
    if(o.cat === 'table'){
      const nR = o.cells.length, nC = o.cells[0].length;
      const headH = 30, rowH = 28;
      const ws = o._colWs || o.cells[0].map(()=>o.w/nC);
      const lx = wx - o.x + o.w/2, ly = wy - o.y + o.h/2;
      let c = 0, acc = 0;
      for(; c < nC-1; c++){ acc += ws[c]; if(lx < acc) break; }
      const r = ly < headH ? 0 : clamp(1 + Math.floor((ly-headH)/rowH), 0, nR-1);
      openTableCell(o, r, c);
      return;
    }
    if(o.cat === 'listcard'){
      const cell = listCellAt(o, wx, wy);
      if(cell) openListCell(o, cell.r, cell.c);
      else if(!cardPeople(o).length) addListPerson(o); // dblclick an empty card starts the first row
      return;
    }
    if(o.cat === 'fieldcard'){
      const row = fieldCellAt(o, wx, wy);
      if(row !== null) openFieldCell(o, row);
      return;
    }
    if(o.cat === 'dayheader'){
      const key = dayCellAt(o, wx, wy);
      if(key) openDayCell(o, key);
      return;
    }
    if(o.cat === 'avscript'){
      const cell = avCellAt(o, wx, wy);
      if(cell && cell.key !== 'still') openAvCell(o, cell.rowId, cell.key);
      return;
    }
    if(o.cat === 'colcard'){
      const key = colCellAt(o, wx, wy);
      if(key) openColCell(o, key);
      return;
    }
    if(o.cat === 'link'){
      if(o.url){ window.open(/^https?:\/\//i.test(o.url) ? o.url : 'https://'+o.url, '_blank'); }
      else toast('Add a URL in the selection bar first');
      return;
    }
    const inp = document.querySelector('#selBar input.lbl');
    if(inp){ inp.focus(); inp.select(); }
  }
});

// OS drag & drop of image files → pinned to the board
cv.addEventListener('dragover', e => e.preventDefault());
cv.addEventListener('drop', async e => {
  e.preventDefault();
  const files = [...e.dataTransfer.files];
  if(!files.length) return;
  const {sx, sy} = evtPos(e);
  let {x, y} = toWorld(sx, sy);
  for(const f of files){
    if(f.type.startsWith('image/')){
      // dropped ON an AV script row? → it becomes one of that beat's stills
      const shot = activeShot();
      const av = [...shot.objects].reverse().find(ob=>ob.cat === 'avscript' &&
        Math.abs(x - ob.x) <= ob.w/2 && Math.abs(y - ob.y) <= ob.h/2);
      const row = (av && typeof avRowAt === 'function') ? avRowAt(av, y) : null;
      if(av && row){
        try{
          const id = await storeImageFile(f);
          row.imgs = row.imgs || [];
          row.imgs.push(id);
          av.cols.still = true; // dropping a still switches the column on
          markDirty(); render();
          toast('Still added to the AV row');
        }catch(err){ toast('Could not store that image'); }
      } else {
        await addBoardImage(f, x, y);
      }
    } else if(f.type.startsWith('audio/') && typeof addBoardAudioAt === 'function'){
      await addBoardAudioAt(f, x, y);
    } else if((f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) &&
              f.size > 4.5*1024*1024 && typeof pdfFileToSubboard === 'function'){
      // too big to STORE as a file — but its pages can still become a board
      if(confirm('“' + f.name + '” is too large to keep as a file card (~4 MB max).\n\n' +
                 'Turn its PAGES into a board instead? Every page becomes a full-res image.'))
        await pdfFileToSubboard(f, x, y);
    } else if(typeof addBoardFileAt === 'function'){
      await addBoardFileAt(f, x, y); // PDFs get a first-page preview card
    }
    x += 60; y += 60;
  }
});

document.addEventListener('keydown', e => {
  const tag = document.activeElement && document.activeElement.tagName;
  if(tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT'){
    if(e.key === 'Escape') document.activeElement.blur();
    return;
  }
  if(window.VIEW_ONLY){
    if(e.key === 'f' || e.key === 'F') zoomFit();
    return;
  }
  if((e.key === 'z' || e.key === 'Z') && (e.metaKey||e.ctrlKey)){
    e.preventDefault();
    e.shiftKey ? redo() : undo();
    return;
  }
  if((e.key === 'y' || e.key === 'Y') && (e.metaKey||e.ctrlKey)){ e.preventDefault(); redo(); return; }
  if((e.key === 'd' || e.key === 'D') && (e.metaKey||e.ctrlKey)){ e.preventDefault(); duplicateSelection(); return; }
  if((e.key === 'c' || e.key === 'C') && (e.metaKey||e.ctrlKey)){
    if(sel){ e.preventDefault(); copySelection(); }
    return;
  }
  if((e.key === 'v' || e.key === 'V') && (e.metaKey||e.ctrlKey)){
    // only consume when our clipboard has content — OS image paste stays intact
    if(FLOOR_CLIP && (FLOOR_CLIP.objs.length || FLOOR_CLIP.walls.length)){
      e.preventDefault(); pasteClipboard();
    }
    return;
  }
  if(e.key === ' '){ spaceDown = true; e.preventDefault(); }
  if(e.key === 'Enter' && tool === 'poly'){ finishPoly(); return; }
  if(e.key === 'Escape'){
    if(tool === 'poly'){ polyDraw = null; setTool('select'); render(); return; }
    drag = null; cv.classList.remove('panning'); sel = null; setTool('select'); refreshSelBar(); render();
  }
  if(e.key === 'Delete' || e.key === 'Backspace'){ deleteSelection(); }
  if(e.key === 'v' || e.key === 'V') setTool('select');
  if(e.key === 'm' || e.key === 'M') setTool('marquee');
  if(e.key === 'w' || e.key === 'W') setTool('wall');
  if(e.key === 'r' || e.key === 'R') setTool('room');
  if(e.key === 'd' || e.key === 'D') setTool('door');
  if(e.key === 'n' || e.key === 'N') addNoteAtCenter();
  if(e.key === 't' || e.key === 'T') addTextAtCenter();
  if(e.key === 'p' || e.key === 'P') togglePlay();
  if(e.key === 'f' || e.key === 'F') zoomFit();
  if(e.key === '?') toggleHelp(true);
});
document.addEventListener('keyup', e => { if(e.key === ' ') spaceDown = false; });

// ---------------------------------------------------------------- copy / paste
// An internal clipboard: Cmd/Ctrl+C copies the selection (objects AND walls),
// Cmd/Ctrl+V pastes into WHATEVER scene is active — so sets travel between
// scenes. Survives scene switches; separate from the OS image-paste.
let FLOOR_CLIP = null;
function copySelection(){
  if(!sel) return;
  const shot = activeShot();
  const objs = [], walls = [];
  if(sel.type === 'object'){
    const o = shot.objects.find(x=>x.id===sel.id); if(o) objs.push(o);
  } else if(sel.type === 'wall'){
    const w = shot.walls.find(x=>x.id===sel.id); if(w) walls.push(w);
  } else if(sel.type === 'multi'){
    sel.ids.forEach(id=>{ const o = shot.objects.find(x=>x.id===id); if(o) objs.push(o); });
    (sel.wallIds||[]).forEach(id=>{ const w = shot.walls.find(x=>x.id===id); if(w) walls.push(w); });
  }
  if(!objs.length && !walls.length) return;
  FLOOR_CLIP = JSON.parse(JSON.stringify({objs, walls}));
  toast((objs.length + walls.length) + ' copied — Cmd/Ctrl+V pastes here or in another scene');
}
function pasteClipboard(){
  if(!FLOOR_CLIP || (!FLOOR_CLIP.objs.length && !FLOOR_CLIP.walls.length)) return;
  const shot = activeShot();
  const c = JSON.parse(JSON.stringify(FLOOR_CLIP));
  const dx = 40, dy = 40;
  const ids = [], wallIds = [];
  for(const o of c.objs){
    o.id = uid(); o.x += dx; o.y += dy;
    if(o.p1){ o.p1.x += dx; o.p1.y += dy; }
    if(o.p2){ o.p2.x += dx; o.p2.y += dy; }
    if(o.mid){ o.mid.x += dx; o.mid.y += dy; }
    if(o.pts) o.pts.forEach(p=>{ p.x += dx; p.y += dy; });
    if(o.path) o.path.forEach(p=>{ p.x += dx; p.y += dy; });
    o.mount = null; o.rail = null; o.shotId = null;
    shot.objects.push(o); ids.push(o.id);
  }
  for(const w of c.walls){
    w.id = uid(); w.x1 += dx; w.y1 += dy; w.x2 += dx; w.y2 += dy;
    if(w.mid){ w.mid.x += dx; w.mid.y += dy; }
    (w.openings||[]).forEach(op=>op.id = uid());
    shot.walls.push(w); wallIds.push(w.id);
  }
  sel = (ids.length + wallIds.length) > 1 ? {type:'multi', ids, wallIds}
      : ids.length ? {type:'object', id:ids[0]} : {type:'wall', id:wallIds[0]};
  markDirty(); render(); refreshSelBar();
}

function deleteSelection(){
  if(!sel) return;
  const shot = activeShot();
  if(sel.type === 'multi'){
    const gone = new Set(sel.ids.filter(id=>{
      const o = shot.objects.find(x=>x.id===id);
      return o && !o.locked;
    }));
    shot.objects = shot.objects.filter(o=>!gone.has(o.id));
    shot.objects.forEach(c=>{
      if(c.mount && gone.has(c.mount.id)) c.mount = null;
      if(c.rail && gone.has(c.rail.id)){ c.rail = null; c.path = []; }
    });
    const goneW = new Set((sel.wallIds||[]).filter(id=>{
      const w = shot.walls.find(x=>x.id===id);
      return w && !w.locked;
    }));
    shot.walls = shot.walls.filter(w=>!goneW.has(w.id));
    if(noteEditor && gone.has(noteEditor.id)) closeNoteEditor(false);
    sel = null; markDirty(); render(); refreshSelBar();
    return;
  }
  if(sel.type === 'sun'){
    if(shot.sun) shot.sun.on = false;
    sel = null; markDirty(); syncSunBtn(); render(); refreshSelBar();
    return;
  }
  if(sel.type === 'object'){
    const o = shot.objects.find(x=>x.id===sel.id);
    if(o && o.locked){ toast('Locked — unlock it in the selection bar first'); return; }
    if(o && o.cat === 'subboard'){
      const n = (o.board && o.board.objects || []).length + (o.board && o.board.walls || []).length;
      if(n && !confirm('Delete this sub-board AND the ' + n + ' item' + (n===1?'':'s') + ' inside it?')) return;
    }
    shot.objects = shot.objects.filter(x=>x.id!==sel.id);
    if(o) shot.objects.forEach(c=>{
      if(c.mount && c.mount.id===o.id) c.mount=null;
      if(c.rail && c.rail.id===o.id){ c.rail=null; c.path=[]; }
    });
    if(o && noteEditor && noteEditor.id===o.id) closeNoteEditor(false);
    // note: stored images are kept so undo can restore board stills
  }
  else if(sel.type === 'wall'){
    const w = shot.walls.find(w=>w.id===sel.id);
    if(w && w.locked){ toast('Locked — unlock it in the selection bar first'); return; }
    shot.walls = shot.walls.filter(w=>w.id!==sel.id);
  }
  else if(sel.type === 'opening'){
    const w = shot.walls.find(w=>w.id===sel.wallId);
    if(w) w.openings.splice(sel.index,1);
  }
  sel = null; markDirty(); render(); refreshSelBar();
}
function duplicateSelection(){
  if(!sel) return;
  const shot = activeShot();
  const copyOf = o=>{
    const n = JSON.parse(JSON.stringify(o));
    n.id = uid(); n.x += 40; n.y += 40;
    if(n.p1){ n.p1.x += 40; n.p1.y += 40; }
    if(n.p2){ n.p2.x += 40; n.p2.y += 40; }
    if(n.mid){ n.mid.x += 40; n.mid.y += 40; }
    if(n.path) n.path = n.path.map(p=>({...p, x:p.x+40, y:p.y+40}));
    if(n.pts) n.pts = n.pts.map(p=>({...p, x:p.x+40, y:p.y+40}));
    n.rail = null; n.mount = null;
    return n;
  };
  if(sel.type === 'multi'){
    const copies = sel.ids
      .map(id=>shot.objects.find(x=>x.id===id))
      .filter(o=>o && !o.locked)
      .map(copyOf);
    const wallCopies = (sel.wallIds||[])
      .map(id=>shot.walls.find(x=>x.id===id))
      .filter(w=>w && !w.locked)
      .map(w=>{
        const n = JSON.parse(JSON.stringify(w));
        n.id = uid(); n.x1 += 40; n.y1 += 40; n.x2 += 40; n.y2 += 40;
        if(n.mid){ n.mid.x += 40; n.mid.y += 40; }
        (n.openings||[]).forEach(op=>op.id = uid());
        return n;
      });
    if(!copies.length && !wallCopies.length) return;
    shot.objects.push(...copies);
    shot.walls.push(...wallCopies);
    sel = {type:'multi', ids:copies.map(c=>c.id), wallIds:wallCopies.map(w=>w.id)};
    markDirty(); render(); refreshSelBar();
    return;
  }
  if(sel.type !== 'object') return;
  const o = shot.objects.find(x=>x.id===sel.id); if(!o) return;
  const n = copyOf(o);
  shot.objects.push(n);
  sel = {type:'object', id:n.id};
  markDirty(); render(); refreshSelBar();
}
// ---------------------------------------------------------------- pen options
function buildInkBar(){
  const bar = document.getElementById('inkBar');
  bar.innerHTML = '';
  const weights = [2, 3, 5, 8, 12];
  for(const w of weights){
    const b = document.createElement('div');
    b.className = 'ink-w' + (inkWeight === w ? ' on' : '');
    b.title = w + 'px stroke';
    const dot = document.createElement('i');
    const d = Math.min(18, 4 + w*1.15);
    dot.style.width = d + 'px'; dot.style.height = d + 'px';
    b.appendChild(dot);
    b.addEventListener('click', ()=>{ inkWeight = w; buildInkBar(); });
    bar.appendChild(b);
  }
  bar.insertAdjacentHTML('beforeend', '<div class="ink-sep"></div>');
  for(const c of COLORS){
    const s = document.createElement('div');
    s.className = 'ink-c' + (inkColor === c ? ' on' : '');
    s.style.background = c;
    s.addEventListener('click', ()=>{ inkColor = c; buildInkBar(); });
    bar.appendChild(s);
  }
}
function addTextAtCenter(){
  const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
  const o = {id:uid(), cat:'text', kind:'text', x:c.x, y:c.y, rot:0, w:240, h:40,
    fontSize:18, bold:false, italic:false, text:'', color:'#5B6472', label:'', path:[]};
  activeShot().objects.push(o);
  sel = {type:'object', id:o.id};
  setTool('select');
  markDirty(); render(); refreshSelBar();
  openNoteEditor(o);
}
function addNoteAtCenter(){
  const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
  const o = {id:uid(), cat:'note', kind:'note', x:c.x, y:c.y, rot:0, w:170, h:150, color:'#E2A93B', text:'', path:[]};
  activeShot().objects.push(o);
  sel = {type:'object', id:o.id};
  setTool('select');
  markDirty(); render(); refreshSelBar();
  openNoteEditor(o);
}

// ---------------------------------------------------------------- tools UI, zoom
function setTool(t){
  tool = t;
  hoverWall = null;
  if(t !== 'poly') polyDraw = null;
  document.querySelectorAll('#toolbar button[data-tool]').forEach(b => b.classList.toggle('on', b.dataset.tool===t));
  cv.className = 'tool-' + (t==='poly' || t==='draw' || t==='crop' || t==='marquee' ? 'wall' : t);
  const inkBar = document.getElementById('inkBar');
  if(t === 'draw'){ buildInkBar(); inkBar.classList.add('show'); }
  else inkBar.classList.remove('show');
  const hints = {
    select:'Drag objects to move · handles rotate / resize · drag empty space to pan · scroll to zoom · ? for help',
    wall:'Drag to draw a wall — snaps to 90° and wall ends · Shift = free angle · keeps drawing until Esc',
    room:'Drag a rectangle to create four walls at once',
    door:'Click on a wall to place a door · then drag it along the wall',
    window:'Click on a wall to place a window · then drag it along the wall',
    poly:'Click to add outline points · double-click or Enter to close the shape · Esc cancels',
    draw:'Draw freehand — great with a pen / Apple Pencil · strokes become selectable objects · Esc to stop',
    gap:'Click a wall to cut a gap in it — select the gap to widen or remove it',
    crop:'Drag a rectangle around the area you want to export',
  };
  document.getElementById('hint').textContent = hints[t] || '';
  render();
}
document.querySelectorAll('#toolbar button[data-tool]').forEach(b =>
  b.addEventListener('click', () => setTool(b.dataset.tool)));
document.getElementById('fitBtn').addEventListener('click', zoomFit);
document.getElementById('noteBtn').addEventListener('click', addNoteAtCenter);
document.getElementById('textBtn').addEventListener('click', addTextAtCenter);

function syncSunBtn(){
  const s = activeShot().sun;
  document.getElementById('sunBtn').classList.toggle('on', !!(s && s.on));
}
document.getElementById('sunBtn').addEventListener('click', ()=>{
  const shot = activeShot();
  if(shot.sun && shot.sun.on){
    shot.sun.on = false;
    if(sel && sel.type==='sun') sel = null;
  } else {
    const c = toWorld(wrap.clientWidth*.5, wrap.clientHeight*.22);
    shot.sun = {on:true, x:(shot.sun&&shot.sun.x)||c.x, y:(shot.sun&&shot.sun.y)||c.y, hour:(shot.sun&&shot.sun.hour)||14};
    sel = {type:'sun'};
  }
  markDirty(); syncSunBtn(); render(); refreshSelBar();
});

function updateZoomPct(){ document.getElementById('zoomPct').textContent = Math.round(view.scale*100)+'%'; }
function zoomAtCenter(f){
  const cx = wrap.clientWidth/2, cy = wrap.clientHeight/2;
  const before = toWorld(cx,cy);
  view.scale = clamp(view.scale*f, .04, 8);
  const after = toWorld(cx,cy);
  view.x += before.x-after.x; view.y += before.y-after.y;
  updateZoomPct(); render();
}
document.getElementById('zoomIn').addEventListener('click', ()=>zoomAtCenter(1.25));
document.getElementById('zoomOut').addEventListener('click', ()=>zoomAtCenter(1/1.25));
document.getElementById('zoomPct').addEventListener('click', ()=>{ view.scale = 1; updateZoomPct(); render(); });

// ---------------------------------------------------------------- playback
const anim = {playing:false, t0:0, dur:5000};
function togglePlay(force){
  const on = force !== undefined ? force : !anim.playing;
  anim.playing = on;
  const b = document.getElementById('playBtn');
  if(b) b.classList.toggle('on', on);
  if(on){ anim.t0 = performance.now(); requestAnimationFrame(animFrame); }
  else render();
}
function animFrame(){
  if(!anim.playing) return;
  render();
  requestAnimationFrame(animFrame);
}
function animProgress(){
  const cycle = anim.dur + 1000; // hold a beat at the end positions
  const e = (performance.now() - anim.t0) % cycle;
  return clamp(e/anim.dur, 0, 1);
}
const lerp = (a,b,t)=>a+(b-a)*t;
const lerpAng = (a,b,t)=>norm(a + norm(b-a)*t);
let framePoses = {};
function poseOf(o, shot, t){
  if(framePoses[o.id]) return framePoses[o.id];
  let g = o;
  if(o.cat === 'camera' && o.mount && o.mount.type === 'cart'){
    // riding the dolly cart: the cart's move IS the camera move (pan stays free)
    const cart = shot.objects.find(x=>x.id === o.mount.id);
    if(cart){
      const pc = poseOf(cart, shot, t);
      g = {...o, x:pc.x, y:pc.y};
    }
  } else if(o.cat === 'camera' && o.mount){
    const j = shot.objects.find(x=>x.id===o.mount.id && isCrane(x));
    if(j){
      const pj = poseOf(j, shot, t);
      const hp = jibHeadPos(pj);
      g = {...o, x:hp.x, y:hp.y, rot:norm(pj.rot + (o.mount.relRot||0))};
    }
  } else if(o.cat === 'actor' && o.mount && (o.mount.type === 'seat' || o.mount.type === 'bed') &&
            !(o.path && o.path.length)){
    // riding: the chair / bed animates, the actor stays in it
    const v = shot.objects.find(x=>x.id === o.mount.id);
    if(v){
      const pv = poseOf(v, shot, t);
      g = {...o, x:pv.x, y:pv.y};
    }
  } else if(o.cat === 'prop' && (o.kind === 'wheelchair' || o.kind === 'bed_hospital') &&
            !(o.path && o.path.length)){
    // vice versa: the actor animates, the chair / bed rolls along
    const rider = shot.objects.find(a=>a.cat === 'actor' && a.mount && a.mount.id === o.id &&
      a.path && a.path.length);
    if(rider){
      const pr = poseOf(rider, shot, t);
      g = {...o, x:pr.x, y:pr.y, rot:pr.rot};
    }
  } else if(o.path && o.path.length && o.kind !== 'track'){
    if(isCrane(o)){
      const b0 = jibBasePos(o);
      const keys = [{x:b0.x, y:b0.y, rot:o.rot, len:armLen(o)},
        ...o.path.map(p=>({x:p.x, y:p.y, rot:p.rot ?? o.rot, len:p.len ?? armLen(o)}))];
      const n = keys.length - 1;
      const f = clamp(t*n, 0, n - 1e-6);
      const i = Math.floor(f), lt = f - i;
      const a = keys[i], b = keys[i+1];
      const rot = lerpAng(a.rot, b.rot, lt);
      const len = lerp(a.len, b.len, lt);
      const bx = lerp(a.x, b.x, lt), by = lerp(a.y, b.y, lt);
      const w = len + 0.72*o.h, lx = -w/2 + o.h*.5;
      g = {...o, w, rot, x:bx - lx*Math.cos(rot), y:by - lx*Math.sin(rot), path:[], rail:null};
    } else {
      const pts = pathPoints(o);
      const smp = samplePath(pts, o.pathStraight, 10);
      const cum = [0];
      for(let i=1;i<smp.length;i++) cum.push(cum[i-1]+dist(smp[i-1].x,smp[i-1].y,smp[i].x,smp[i].y));
      const total = cum[cum.length-1] || 1;
      const pos = sampleAtDist(smp, cum, t*total);
      // keyframe timing by straight-line spacing; rot / framing interpolate per segment
      const cumK = [0];
      for(let i=1;i<pts.length;i++) cumK.push(cumK[i-1]+Math.max(1,dist(pts[i-1].x,pts[i-1].y,pts[i].x,pts[i].y)));
      const totK = cumK[cumK.length-1] || 1;
      const dK = t*totK;
      let i = 0;
      while(i < pts.length-2 && cumK[i+1] < dK) i++;
      const lt = clamp((dK - cumK[i]) / Math.max(1, cumK[i+1]-cumK[i]), 0, 1);
      const rA = i===0 ? o.rot : prot(o, i-1);
      const rB = prot(o, i);
      g = {...o, x:pos.x, y:pos.y, rot:lerpAng(rA, rB, lt), path:[]};
      if(o.cat === 'camera'){
        const fA = i===0 ? o.fov : (o.path[i-1].fov ?? o.fov);
        const fB = o.path[i].fov ?? o.fov;
        const gA = i===0 ? o.range : (o.path[i-1].range ?? o.range);
        const gB = o.path[i].range ?? o.range;
        g.fov = lerp(fA, fB, lt);
        g.range = lerp(gA, gB, lt);
      }
    }
  }
  framePoses[o.id] = g;
  return g;
}
document.getElementById('playBtn').addEventListener('click', ()=>togglePlay());

function frameExtents(o){
  if(o.cat !== 'camera' || !o.imgId) return null;
  const fx = o.x + (o.frameDX ?? 70), fy = o.y + (o.frameDY ?? -85);
  return {minX:fx-75, minY:fy-48, maxX:fx+75, maxY:fy+48};
}
function contentBounds(shot){
  let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
  const add=(x,y)=>{minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);};
  for(const w of shot.walls){ add(w.x1,w.y1); add(w.x2,w.y2); }
  for(const o of shot.objects){
    if(o.kind === 'track'){
      (o.pts||[]).forEach(p=>{ add(p.x-40,p.y-40); add(p.x+40,p.y+40); });
      continue;
    }
    const r = Math.max(o.w,o.h)/2 + (o.cat==='camera' ? o.range : 0);
    add(o.x-r,o.y-r); add(o.x+r,o.y+r);
    const fe = frameExtents(o);
    if(fe){ add(fe.minX, fe.minY); add(fe.maxX, fe.maxY); }
    if(o.path) for(const p of o.path){
      const pr = (o.cat==='camera' ? (p.range ?? o.range) : 0) + 60;
      add(p.x-pr,p.y-pr); add(p.x+pr,p.y+pr);
    }
  }
  if(shot.sun && shot.sun.on){ add(shot.sun.x-90, shot.sun.y-90); add(shot.sun.x+90, shot.sun.y+90); }
  if(minX===Infinity) return null;
  return {minX,minY,maxX,maxY};
}
function zoomFit(){
  const b = contentBounds(activeShot());
  if(!b){ view.x=-wrap.clientWidth/2; view.y=-wrap.clientHeight/2; view.scale=1; updateZoomPct(); render(); return; }
  const pad = 90;
  const w = b.maxX-b.minX+pad*2, h = b.maxY-b.minY+pad*2;
  view.scale = clamp(Math.min(wrap.clientWidth/w, wrap.clientHeight/h), .04, .9); // never zoom IN past 90% when fitting
  view.x = b.minX-pad - (wrap.clientWidth/view.scale - w)/2;
  view.y = b.minY-pad - (wrap.clientHeight/view.scale - h)/2;
  updateZoomPct(); render();
}
