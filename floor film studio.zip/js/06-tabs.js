// FLOOR — 06-tabs.js
// The app shell: Moodboard · Script · Storyboard · Shot designer · Production.
// Moodboard reuses the whole canvas engine on a project-level board.

// ---------------------------------------------------------------- tab switching
// ---------------------------------------------------------------- floor access (co-editors)
// The owner can hide floors per member (production_members.floors). This is a
// UI boundary: the shared production is still one document, so it keeps the
// budget out of sight and out of the way, not out of reach of a determined
// developer with the API key. A hard boundary needs the budget in its own
// row with its own policy — noted in DEVNOTES as the next step if needed.
function floorAllowed(t){
  const me = window.FLOOR_SHARED && typeof currentProjectId !== 'undefined' && FLOOR_SHARED.get(currentProjectId);
  if(!me || me.role === 'owner' || !Array.isArray(me.floors)) return true;
  return me.floors.includes(t);
}
function applyFloorAccess(){
  let changed = false;
  document.querySelectorAll('#tabbar button[data-tab]').forEach(b=>{
    const ok = floorAllowed(b.dataset.tab);
    if(b.hidden !== !ok){ b.hidden = !ok; changed = true; }
  });
  if(!floorAllowed(activeTab)){
    const first = [...document.querySelectorAll('#tabbar button[data-tab]')].find(b=>!b.hidden);
    if(first) switchTab(first.dataset.tab);
  }
  return changed;
}
function switchTab(t){
  if(!floorAllowed(t)){ toast('This floor is not open to you in this production'); return; }
  if(activeTab === t) return;
  if(typeof exitAllSubboards === 'function') exitAllSubboards();
  closeNoteEditor(true);
  togglePlay(false);
  sel = null; drag = null;
  activeTab = t;
  document.body.className = document.body.className.replace(/\btab-\w+\b/g, '').trim();
  document.body.classList.add('tab-' + t);
  document.querySelectorAll('#tabbar button').forEach(b =>
    b.classList.toggle('on', b.dataset.tab === t));
  if(t === 'mood'){
    ensureMoodboard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  } else if(t === 'write'){
    ensureScriptBoard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  } else if(t === 'design'){
    buildLibrary(); buildShotList(); buildInfo(); buildStills();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(render);
  } else if(t === 'shots'){
    ensureShotBoard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  } else if(t === 'budget'){
    if(typeof buildBudgetPage === 'function') buildBudgetPage();
    refreshSelBar();
  } else if(t === 'org'){
    ensureProdBoard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  }
  if(typeof syncTitle === 'function') syncTitle(); // setup chips follow the tab
  render();
}
let _fitOnceDone = {};
function zoomFitIfEmptyView(){
  if(_fitOnceDone[activeTab]) return;
  _fitOnceDone[activeTab] = true;
  zoomFit();
}
document.querySelectorAll('#tabbar button').forEach(b =>
  b.addEventListener('click', ()=>switchTab(b.dataset.tab)));

// ---------------------------------------------------------------- moodboard
function ensureMoodboard(){
  if(!project.moodboard){
    const m = newShot(0);
    m.name = 'Mood & inspiration';
    project.moodboard = m;
    markDirty();
  }
  migrateShot(project.moodboard);
}
// library section for the Mood & inspiration board — brainstorm cards
function buildMoodLibSection(lib){
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Brainstorm';
  lib.appendChild(h);
  const grid = document.createElement('div');
  grid.className = 'lib-grid';
  const preset = (name, color, title, ph)=>{
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle=color; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle=color; tc.globalAlpha=.28;
      tc.fillRect(-w2/2,-h2*.4,w2,h2*.18); tc.globalAlpha=1;
      tc.globalAlpha=.5;
      for(const y2 of [-h2*.06, h2*.1, h2*.26]) tc.fillRect(-w2*.36, y2, w2*.72, 2.5);
      tc.globalAlpha=1;
    }, 100, 100, color, null, null, 'colcard'));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(name) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'colcard', kind:'colcard', w:220, h:120, cw:220, color, title, text:ph||''}));
    grid.appendChild(el);
  };
  preset('Idea', '#E2A93B', 'Idea');
  preset('Question', '#8B5CF6', 'Question');
  preset('Theme', '#3E9B6E', 'Theme');
  preset('Do / Don’t', PAL.coral, 'Do / don’t');
  lib.appendChild(grid);
  const tip = document.createElement('div');
  tip.style.cssText = 'font-size:10px;color:var(--ink2);padding:4px 14px 10px;line-height:1.5;';
  tip.textContent = 'Column cards for thinking out loud — pose a question, stack ideas under it, group by theme. Paste stills (Cmd+V), drop links for references, use color cards for the palette.';
  lib.appendChild(tip);
}
function ensureScriptBoard(){
  if(!project.scriptboard){
    const b = newShot(0);
    b.name = 'Script & storyboard';
    project.scriptboard = b;
    // starter layout: one film script block, ready to type into
    b.objects.push({id:uid(), cat:'script', kind:'script', x:-260, y:0, rot:0,
      w:430, h:300, mode:'film', text:'', textR:'', fontSize:12.5,
      color:'#5B6472', label:'', path:[]});
    project.scriptboard = b;
    markDirty();
  }
  migrateShot(project.scriptboard);
}
// library section for the Script & Storyboard board
function buildWriteLibSection(lib){
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Script & storyboard';
  lib.appendChild(h);
  const grid = document.createElement('div');
  grid.className = 'lib-grid';
  const tile = (name, drawFn, spec)=>{
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas(drawFn, 100, 100, '#5B6472', null, null, 'script'));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(name) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, spec));
    grid.appendChild(el);
  };
  tile('Film script', (tc,w2,h2,c2)=>{
    tc.strokeStyle=c2; tc.lineWidth=2.5;
    tc.strokeRect(-w2*.34,-h2*.4,w2*.68,h2*.8);
    tc.globalAlpha=.6;
    for(let i=0;i<5;i++){ tc.beginPath(); tc.moveTo(-w2*.24,-h2*.26+i*h2*.13); tc.lineTo(w2*.24,-h2*.26+i*h2*.13); tc.stroke(); }
    tc.globalAlpha=1;
  }, {cat:'script', kind:'script', mode:'film'});
  tile('AV script', (tc,w2,h2,c2)=>{
    tc.beginPath(); tc.roundRect(-w2*.42,-h2*.4,w2*.84,h2*.8,3);
    tc.fillStyle = THEME.card; tc.fill();
    tc.strokeStyle='#8B5CF6'; tc.lineWidth=2.5; tc.stroke();
    tc.fillStyle='#8B5CF6'; tc.globalAlpha=.28;
    tc.fillRect(-w2*.42,-h2*.4,w2*.84,h2*.14); tc.globalAlpha=1;
    tc.globalAlpha=.5; tc.strokeStyle='#8B5CF6'; tc.lineWidth=1.5;
    for(const x2 of [-w2*.18, w2*.1]){
      tc.beginPath(); tc.moveTo(x2,-h2*.26); tc.lineTo(x2,h2*.4); tc.stroke();
    }
    for(const y2 of [-h2*.04, h2*.18]){
      tc.beginPath(); tc.moveTo(-w2*.42,y2); tc.lineTo(w2*.42,y2); tc.stroke();
    }
    tc.globalAlpha=1;
  }, {cat:'avscript', kind:'avscript', w:560, h:150, color:'#8B5CF6'});
  tile('Storyboard row', (tc,w2,h2,c2)=>{
    tc.strokeStyle=c2; tc.lineWidth=2.5;
    tc.strokeRect(-w2*.42,-h2*.18,w2*.84,h2*.36);
    tc.beginPath();
    tc.moveTo(-w2*.16,-h2*.18); tc.lineTo(-w2*.16,h2*.18);
    tc.moveTo(w2*.1,-h2*.18); tc.lineTo(w2*.1,h2*.18);
    tc.stroke();
    tc.globalAlpha=.5; tc.fillStyle=c2;
    tc.fillRect(-w2*.13,-h2*.12,w2*.2,h2*.24);
    tc.globalAlpha=1;
  }, {cat:'sbrow', kind:'sbrow'});
  lib.appendChild(grid);
  const tip = document.createElement('div');
  tip.style.cssText = 'font-size:10px;color:var(--ink2);padding:4px 14px 8px;line-height:1.5;';
  tip.textContent = 'Film script: write, select, hit "Break down" — FLOOR creates a storyboard row and a scene board per detected scene. AV script: a row per beat — time, what you hear, what you see; toggle scene #, stills and director notes columns in its selection bar.';
  lib.appendChild(tip);
}
function ensureProdBoard(){
  if(!project.prodboard){
    const b = newShot(0);
    b.name = 'Production board';
    project.prodboard = b;
    markDirty();
  }
  migrateShot(project.prodboard);
}

// ---- production card library (smart cards — drag onto the board) ----

// ---------------------------------------------------------------- 4th floor: documents
// Every script / AV script card in the production, wherever it lives (script
// board, moodboard, production board, nested boards) — so a producer exports
// all paperwork from one place without hunting through boards.
function collectDocCards(){
  const out = [];
  const seen = new Set();
  const scanObjs = (objs, where)=>(objs||[]).forEach(ob=>{
    if(seen.has(ob.id)) return;
    if((ob.cat === 'script' || ob.cat === 'avscript' || ob.kind === 'script' || ob.kind === 'avscript') && ob.mode !== 'shotlist'){
      seen.add(ob.id); out.push({o:ob, where, av:(ob.cat === 'avscript' || ob.kind === 'avscript')});
    }
    if(ob.cat === 'subboard' && ob.board) scanObjs(ob.board.objects, where);
  });
  scanObjs(project.scriptboard && project.scriptboard.objects, '1st · Script');
  scanObjs(project.shotboard && project.shotboard.objects, '3rd · Shot list');
  scanObjs(project.moodboard && project.moodboard.objects, 'Ground · Mood');
  scanObjs(project.prodboard && project.prodboard.objects, '5th · Production');
  (project.scenes || []).forEach(s=>scanObjs(s.objects, s.name));
  return out;
}
function buildDocsSection(lib){
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Documents';
  h.style.marginTop = '6px';
  const st = document.createElement('button');
  st.textContent = 'STYLE'; st.title = 'Document style — accent colour, logo, footer for every exported PDF';
  st.style.cssText = 'width:auto;padding:0 7px;font-size:9.5px;letter-spacing:.5px;';
  st.addEventListener('click', ()=>docStyleOverlay());
  h.appendChild(st);
  lib.prepend(h); // producers first: documents above the board tiles
  const box = document.createElement('div');
  box.className = 'docs-list';
  const docs = collectDocCards();
  const row = (title, sub, btns)=>{
    const r = document.createElement('div');
    r.className = 'doc-row';
    r.innerHTML = '<div class="doc-t"><b>' + esc(title) + '</b><span>' + esc(sub) + '</span></div>';
    const bb = document.createElement('div'); bb.className = 'doc-b';
    for(const [lab, fn, tip] of btns){
      const b = document.createElement('button'); b.className = 'btn'; b.textContent = lab; b.title = tip || '';
      b.addEventListener('click', e=>{ e.stopPropagation(); fn(); });
      bb.appendChild(b);
    }
    r.appendChild(bb);
    box.appendChild(r);
  };
  if(!docs.length){
    const e = document.createElement('div'); e.className = 'doc-empty';
    e.textContent = 'No script yet. Load or write one on the 1st floor (Script) — it shows up here for export.';
    box.appendChild(e);
  }
  for(const d of docs){
    const title = d.o.title || d.o.name || (d.av ? 'AV script' : 'Script');
    row(title, (d.av ? 'AV script · ' : 'Script · ') + d.where, [
      ['PDF', ()=>d.av ? exportAvPDF(d.o) : exportScriptPDF(d.o), 'Export as PDF'],
      ['.docx', ()=>d.av ? exportAvDocx(d.o) : exportScriptDocx(d.o), 'Export as Word document'],
      ['Open', ()=>{ switchTab('write'); const ob = findOnBoard(d.o.id); if(ob){ sel = ob; if(typeof zoomToSel === 'function') zoomToSel(); render(); refreshSelBar(); } }, 'Go to the card on the 1st floor']
    ]);
  }
  // call sheets, prop & gear lists on the boards
  const cards = [];
  const scanCards = objs=>(objs || []).forEach(ob=>{
    if(ob.cat === 'callsheet' || ob.cat === 'proplist' || ob.cat === 'gearlist') cards.push(ob);
    if(ob.cat === 'subboard' && ob.board) scanCards(ob.board.objects);
  });
  scanCards(project.prodboard && project.prodboard.objects);
  scanCards(project.scriptboard && project.scriptboard.objects);
  scanCards(project.moodboard && project.moodboard.objects);
  for(const c of cards){
    if(c.cat === 'callsheet'){
      const dy = typeof dayFor === 'function' ? dayFor(c) : null;
      row('Call sheet', c.allDays ? 'All days' : (dy ? (dy.date ? new Date(dy.date + 'T12:00:00').toLocaleDateString('nl-NL', {weekday:'short', day:'numeric', month:'short'}) : 'Day ' + dayNumber(dy)) : 'No day yet'), [
        ['PDF', ()=>exportCallSheetDoc(c), 'Export as an A4 document'],
        ['Card', ()=>exportCallSheetPDF(c), 'Export the card as it looks on the board'],
        ['Open', ()=>{ const ob = findOnBoard(c.id); if(ob){ sel = ob; render(); refreshSelBar(); } }, 'Select the card']
      ]);
    } else {
      const n = (c.cat === 'gearlist' ? gearListGroups : propListGroups)(c).reduce((a, g)=>a + g.rows.length, 0);
      row(c.cat === 'gearlist' ? 'Gear list' : 'Prop list', n + ' item' + (n === 1 ? '' : 's'), [
        ['PDF', ()=>exportPropListPDF(c), 'Export as an A4 checklist'],
        ['Open', ()=>{ const ob = findOnBoard(c.id); if(ob){ sel = ob; render(); refreshSelBar(); } }, 'Select the card']
      ]);
    }
  }
  if(typeof slCards === 'function'){
    const cs2 = slCards();
    const n = cs2.reduce((a, c)=>a + (c.rows || []).filter(r=>!r.block).length, 0);
    row('Shot list', cs2.length ? cs2.length + ' day' + (cs2.length === 1 ? '' : 's') + ' · ' + n + ' shots · 3rd floor' : 'No shoot days yet · 3rd floor', [
      ['PDF', ()=>exportShotListPDF(null), 'Shooting order per day, breaks and moves included'],
      ['Open', ()=>switchTab('shots'), 'Go to the 3rd floor']
    ]);
  }
  if(typeof budgetCSV === 'function' && floorAllowed('budget')){
    const tot = typeof budgetTotals === 'function' ? budgetTotals() : null;
    row('Budget', tot ? budgetFmt(tot.total, budgetData().currency) + ' incl. VAT · 4th floor' : '4th floor', [
      ['PDF', ()=>exportBudgetPDF(), 'Quote-style budget'],
      ['CSV', ()=>dlBlob(budgetFileBase() + '-budget.csv', budgetCSV()), 'Export the budget as CSV'],
      ['Open', ()=>switchTab('budget'), 'Go to the 4th floor']
    ]);
  }
  h.after(box);
}
function findOnBoard(id){
  const s = activeScene();
  return (s && s.objects || []).find(o=>o.id === id) || null;
}
function buildProdLibSection(lib){
  buildDocsSection(lib);
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Production cards';
  lib.appendChild(h);
  const grid = document.createElement('div');
  grid.className = 'lib-grid';
  // day header — the call-time block (P3): date, general call, sunrise/sunset
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle = THEME.danger; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle = THEME.danger; tc.globalAlpha=.28;
      tc.fillRect(-w2/2, -h2*.4, w2, h2*.16); tc.globalAlpha=1;
      tc.font='800 '+(h2*.3)+'px -apple-system,Segoe UI,sans-serif';
      tc.textAlign='center'; tc.textBaseline='middle';
      tc.fillStyle = THEME.ink; tc.fillText('07:00', 0, h2*.02);
      tc.textAlign='left'; tc.textBaseline='alphabetic';
      tc.fillStyle='#E8934C'; tc.globalAlpha=.7;
      tc.fillRect(-w2*.36, h2*.24, w2*.3, 2.5); tc.globalAlpha=1;
    }, 100, 100, PAL.coral, null, null, 'dayheader'));
    el.insertAdjacentHTML('beforeend', '<span>Day header</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, {cat:'dayheader', kind:'dayheader', w:320, h:140, color:PAL.coral}));
    grid.appendChild(el);
  }
  // registry cards first — Crew / Cast / Client, live views of one People list
  for(const kind of ['crew','cast','client']){
    const spec = LIST_CARDS[kind];
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.36,w2,h2*.72,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle=spec.color; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle=spec.color; tc.globalAlpha=.28;
      tc.fillRect(-w2/2, -h2*.36, w2, h2*.2); tc.globalAlpha=1;
      tc.globalAlpha=.55;
      for(const y2 of [-h2*.04, h2*.14]) tc.fillRect(-w2*.36, y2, w2*.72, 2.5);
      tc.globalAlpha=1;
    }, 100, 100, spec.color, null, null, kind));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(kind.charAt(0).toUpperCase()+kind.slice(1)) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, {cat:'listcard', kind, w:360, h:74, color:spec.color}));
    grid.appendChild(el);
  }
  // field cards — label:value windows onto the production data
  for(const [kind, name] of [['prodinfo','Production'],['location','Location']]){
    const spec = FIELD_CARDS[kind];
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle=spec.color; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle=spec.color; tc.globalAlpha=.28;
      tc.fillRect(-w2/2, -h2*.4, w2, h2*.18); tc.globalAlpha=1;
      tc.globalAlpha=.5;
      for(const y2 of [-h2*.1, h2*.06, h2*.22]){
        tc.fillRect(-w2*.36, y2, w2*.2, 2.5);
        tc.fillRect(-w2*.08, y2, w2*.44, 2.5);
      }
      tc.globalAlpha=1;
    }, 100, 100, spec.color, null, null, kind));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(name) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, {cat:'fieldcard', kind, w:280, h:130, color:spec.color}));
    grid.appendChild(el);
  }
  // Checklist 2.0 — a real to-do list born from a template
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.strokeStyle='#8B5CF6'; tc.lineWidth=3;
      for(const y2 of [-h2*.26, 0, h2*.26]){
        tc.strokeRect(-w2*.32, y2-6, 12, 12);
        tc.beginPath(); tc.moveTo(-w2*.06, y2); tc.lineTo(w2*.34, y2); tc.stroke();
      }
    }, 100, 100, '#8B5CF6', null, null, 'todo'));
    el.insertAdjacentHTML('beforeend', '<span>Checklist</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'todo', kind:'todo', w:230, h:120, color:'#8B5CF6', checklist:true}));
    grid.appendChild(el);
  }
  // day schedule — live: calls from the day header + scene picker
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle='#E8934C'; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle='#E8934C'; tc.globalAlpha=.28;
      tc.fillRect(-w2/2,-h2*.4,w2,h2*.16); tc.globalAlpha=1;
      tc.globalAlpha=.5;
      for(const y2 of [-h2*.1, h2*.04, h2*.18]){
        tc.strokeRect(-w2*.36, y2-1, 5, 5);
        tc.fillRect(-w2*.24, y2, w2*.6, 2.5);
      }
      tc.globalAlpha=1;
    }, 100, 100, '#E8934C', null, null, 'schedule'));
    el.insertAdjacentHTML('beforeend', '<span>Day schedule</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'schedule', kind:'schedule', w:320, h:200, color:'#E8934C'}));
    grid.appendChild(el);
  }
  // prop list — live: props per scene from the boards + script, plus your own
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle='#7FA05A'; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle='#7FA05A'; tc.globalAlpha=.28;
      tc.fillRect(-w2/2,-h2*.4,w2,h2*.16); tc.globalAlpha=1;
      tc.globalAlpha=.55;
      for(const y2 of [-h2*.1, h2*.04, h2*.18]){
        tc.strokeRect(-w2*.36, y2-1, 6, 6);
        tc.fillRect(-w2*.22, y2+1, w2*.55, 2.5);
      }
      // one ticked box
      tc.globalAlpha=1; tc.lineWidth=1.8;
      tc.beginPath();
      tc.moveTo(-w2*.35, -h2*.09); tc.lineTo(-w2*.33, -h2*.06); tc.lineTo(-w2*.29, -h2*.12);
      tc.stroke();
    }, 100, 100, '#7FA05A', null, null, 'proplist'));
    el.insertAdjacentHTML('beforeend', '<span>Prop list</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'proplist', kind:'proplist', w:280, h:160, color:'#7FA05A'}));
    grid.appendChild(el);
  }
  // gear list — live: cameras & lights per scene, fixture names included
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.4,w2,h2*.8,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle='#4C8AD9'; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle='#4C8AD9'; tc.globalAlpha=.28;
      tc.fillRect(-w2/2,-h2*.4,w2,h2*.16); tc.globalAlpha=1;
      tc.globalAlpha=.55;
      for(const y2 of [-h2*.1, h2*.04, h2*.18]){
        tc.strokeRect(-w2*.36, y2-1, 6, 6);
        tc.fillRect(-w2*.22, y2+1, w2*.55, 2.5);
      }
      tc.globalAlpha=1;
    }, 100, 100, '#4C8AD9', null, null, 'gearlist'));
    el.insertAdjacentHTML('beforeend', '<span>Gear list</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'gearlist', kind:'gearlist', w:280, h:160, color:'#4C8AD9'}));
    grid.appendChild(el);
  }
  // live weather card (Open-Meteo: free GFS/ICON model data, no key)
  const wEl = document.createElement('div');
  wEl.className = 'lib-item';
  wEl.appendChild(tileCanvas((tc,w2,h2)=>{
    tc.strokeStyle='#4CA6E8'; tc.lineWidth=3; tc.fillStyle='#4CA6E8';
    tc.beginPath(); tc.arc(-w2*.1,-h2*.14,h2*.16,0,7); tc.stroke();
    tc.beginPath();
    tc.moveTo(-w2*.3,h2*.12); tc.quadraticCurveTo(-w2*.34,-h2*.06,-w2*.12,0);
    tc.quadraticCurveTo(0,-h2*.2,w2*.14,0);
    tc.quadraticCurveTo(w2*.36,-h2*.02,w2*.28,h2*.12);
    tc.closePath(); tc.globalAlpha=.35; tc.fill(); tc.globalAlpha=1; tc.stroke();
  }, 100, 100, '#4CA6E8', null, null, 'weather'));
  wEl.insertAdjacentHTML('beforeend', '<span>Weather (live)</span>');
  wEl.addEventListener('pointerdown', e => startLibDrag(e, {cat:'weather', kind:'weather', color:'#4CA6E8'}));
  grid.appendChild(wEl);
  // the call sheet comes LAST — it's the sum of everything above
  {
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      tc.beginPath(); tc.roundRect(-w2/2,-h2*.44,w2,h2*.88,4);
      tc.fillStyle = THEME.card; tc.fill();
      tc.strokeStyle = THEME.accent; tc.lineWidth=2.5; tc.stroke();
      tc.fillStyle = THEME.accent; tc.globalAlpha=.28;
      tc.fillRect(-w2/2,-h2*.44,w2,h2*.16); tc.globalAlpha=1;
      tc.globalAlpha=.55;
      for(const y2 of [-h2*.18, -h2*.06, h2*.1, h2*.22, h2*.34])
        tc.fillRect(-w2*.36, y2, w2*(y2===-h2*.18||y2===h2*.1 ? .34 : .72), 2.5);
      tc.globalAlpha=1;
    }, 100, 100, PAL.sky, null, null, 'callsheet'));
    el.insertAdjacentHTML('beforeend', '<span>Call sheet</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e,
      {cat:'callsheet', kind:'callsheet', w:380, h:300, color:PAL.sky}));
    grid.appendChild(el);
  }
  lib.appendChild(grid);
  const tip = document.createElement('div');
  tip.style.cssText = 'font-size:10px;color:var(--ink2);padding:4px 14px 10px;line-height:1.5;';
  tip.textContent = 'Crew, Cast and Client cards are live views of one People registry — add a person on any card and they exist everywhere ("Paste list…" imports a whole contact list at once). Production info and Location cards are windows onto the production data. Drop map screenshots or Cmd+V paste straight onto the board.';
  lib.appendChild(tip);
}

// ---------------------------------------------------------------- live weather (Open-Meteo, GFS-backed, free)
const WMO = {0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',
  51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',
  66:'Freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',
  80:'Light showers',81:'Showers',82:'Heavy showers',85:'Snow showers',86:'Snow showers',
  95:'Thunderstorm',96:'Thunderstorm + hail',99:'Severe thunderstorm'};
async function fetchWeatherFor(o){
  if(!o.place || !o.date){ toast('Set a place and a date first'); return; }
  const days = Math.round((new Date(o.date) - new Date().setHours(0,0,0,0)) / 86400000);
  if(days < 0){ toast('That date is in the past'); return; }
  if(days > 15){ toast('Forecasts reach ~16 days ahead \u2014 fetch again closer to the date'); return; }
  toast('Fetching forecast\u2026');
  try{
    const g = await (await fetch('https://geocoding-api.open-meteo.com/v1/search?count=1&language=nl&name=' +
      encodeURIComponent(o.place))).json();
    const hit = g.results && g.results[0];
    if(!hit){ toast('Place not found \u2014 try a bigger town nearby'); return; }
    const q = 'https://api.open-meteo.com/v1/forecast?latitude=' + hit.latitude +
      '&longitude=' + hit.longitude +
      '&daily=weather_code,temperature_2m_min,temperature_2m_max,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset' +
      '&timezone=auto&start_date=' + o.date + '&end_date=' + o.date;
    const w = await (await fetch(q)).json();
    const d = w.daily;
    if(!d || !d.time || !d.time.length){ toast('No forecast returned for that date'); return; }
    const hhmm = t => (t||'').split('T')[1] || '';
    o.place = hit.name + (hit.admin1 ? ', ' + hit.admin1 : '');
    o.data = [
      ['Forecast', WMO[d.weather_code[0]] || ('code ' + d.weather_code[0])],
      ['Temp', Math.round(d.temperature_2m_min[0]) + '\u2013' + Math.round(d.temperature_2m_max[0]) + ' \u00b0C'],
      ['Rain chance', (d.precipitation_probability_max[0] ?? '\u2014') + ' %'],
      ['Wind', toBft(d.wind_speed_10m_max[0]) + ' Bft'],
      ['Sun', hhmm(d.sunrise[0]) + ' \u2192 ' + hhmm(d.sunset[0])],
    ];
    markDirty(); render(); refreshSelBar();
    toast('Forecast loaded');
  }catch(e){
    console.warn('weather fetch failed', e);
    toast('Could not reach the weather service');
  }
}

// bare forecast for a known lat/lon + date (the call sheet's auto-weather)
async function fetchDailyForecast(lat, lon, dateStr){
  const days = Math.round((new Date(dateStr) - new Date().setHours(0,0,0,0)) / 864e5);
  if(days < 0 || days > 15) return null; // outside the ~16-day forecast window
  try{
    const q = 'https://api.open-meteo.com/v1/forecast?latitude=' + lat + '&longitude=' + lon +
      '&daily=weather_code,temperature_2m_min,temperature_2m_max,precipitation_probability_max,wind_speed_10m_max' +
      '&timezone=auto&start_date=' + dateStr + '&end_date=' + dateStr;
    const w = await (await fetch(q)).json();
    const d = w.daily;
    if(!d || !d.time || !d.time.length) return null;
    return [
      ['Forecast', WMO[d.weather_code[0]] || ('code ' + d.weather_code[0])],
      ['Temp', Math.round(d.temperature_2m_min[0]) + '–' + Math.round(d.temperature_2m_max[0]) + ' °C'],
      ['Rain chance', (d.precipitation_probability_max[0] ?? '—') + ' %'],
      ['Wind', toBft(d.wind_speed_10m_max[0]) + ' Bft'],
    ];
  }catch(e){ return null; }
}
// the call sheet fetches its own weather from the day header's place + date;
// cached on the card under a key so render() can call this freely
async function callsheetWeather(o, day){
  const key = day.date + '@' + (+day.lat).toFixed(2) + ',' + (+day.lon).toFixed(2);
  if(o._wxBusy || (o.wx && o.wx.key === key)) return;
  o._wxBusy = true;
  try{
    const data = await fetchDailyForecast(day.lat, day.lon, day.date);
    o.wx = {key, date:day.date, place:day.place || '', data};
    markDirty(); render();
  } finally { o._wxBusy = false; }
}

// email addresses on the call sheet — all groups, or one tag
function sheetEmails(o, tag){
  normalizeProduction();
  const inc = o.inc || {};
  const tags = tag ? [tag] : ['crew','cast','client'].filter(t=>inc[t] !== false);
  return [...new Set(peopleReg()
    .filter(p=>tags.includes(p.tag) && /\S+@\S+\.\S+/.test(p.email || ''))
    .map(p=>p.email.trim()))];
}
async function copySheetEmails(o){
  const ems = sheetEmails(o);
  if(!ems.length){ toast('No email addresses in the registry yet'); return; }
  try{ await navigator.clipboard.writeText(ems.join(', ')); toast(ems.length + ' addresses copied'); }
  catch(_){ prompt('Email addresses:', ems.join(', ')); }
}
// plain-text call sheet for the mail body (attachments need the PDF export)
function callSheetText(o){
  const b = project.prodboard;
  const allD = boardDays();
  const multi = !!o.allDays && allD.length > 1;
  const dayList = multi ? allD : [dayFor(o)];
  const L = [];
  L.push((project.shootName || 'PRODUCTION').toUpperCase() + ' — CALL SHEET' +
    (multi ? ' — ALL DAYS' : ''));
  const P = project.production || {};
  if(P.company || P.email || P.phone)
    L.push([P.company, P.email, P.phone].filter(Boolean).join(' · '));
  for(const day of dayList){
    if(!day) continue;
    if(multi){
      L.push('');
      L.push('══ SHOOT DAY ' + dayNumber(day) +
        (day.date ? ' — ' + new Date(day.date + 'T12:00:00').toLocaleDateString('nl-NL',
          {weekday:'long', day:'numeric', month:'long'}) : '') + ' ══');
    } else if(day.date){
      L.push(new Date(day.date + 'T12:00:00').toLocaleDateString('nl-NL',
        {weekday:'long', day:'numeric', month:'long', year:'numeric'}));
    }
    L.push('General call ' + (day.call || '–') + ' · shooting call ' + (day.shootCall || '–') +
      ' · est. wrap ' + (day.wrap || '–'));
    const assigned = dayLocs(day);
    const locs = assigned.length ? assigned
      : project.production.locations.filter(l=>l.name || l.street || l.town || l.address);
    if(locs.length){
      L.push('');
      L.push(locs.length > 1 ? (assigned.length > 1 ? 'LOCATIONS (in order):' : 'LOCATIONS:') : 'LOCATION:');
      locs.forEach((loc, li)=>{
        L.push('  ' + (assigned.length > 1 ? (li+1) + '. ' : '') +
          [loc.name, loc.street, loc.town, loc.country].filter(Boolean).join(', '));
        if(loc.parking) L.push('  Parking: ' + loc.parking);
        if(loc.hospital) L.push('  Hospital: ' + loc.hospital);
      });
    }
    const scheds = b ? b.objects.filter(x=>x.cat==='schedule') : [];
    const schd = scheds.find(x=>dayFor(x) === day) || (multi ? null : scheds[0]);
    const cs2 = computeSchedule(schd || {}, day);
    const rows = [];
    if(schd) for(const r of cs2.rows){
      if(r.it.on === false || r.start == null) continue;
      rows.push(minToHHMM(r.start) + '  ' + r.label + (r.it.type !== 'scene' ? ' (' + r.dur + 'm)' : ''));
    }
    if(rows.length){
      L.push(''); L.push('SCHEDULE:'); L.push(...rows);
      L.push('Est. wrap ' + ((day && day.wrap) || cs2.wrap));
    }
  }
  const day = dayList[0]; // props/people/weather below are day-independent
  if(o.inc && o.inc.props){ // props are opt-in on the sheet — the Prop list PDF is the prop master's document
    const plc = b && b.objects.find(x=>x.cat==='proplist');
    const gs = propListGroups(plc || {props:{}, hide:{}, done:{}}).filter(g=>g.rows.length);
    if(gs.length){
      L.push(''); L.push('PROPS:');
      for(const g of gs){
        L.push('  ' + plSceneHead(g.s));
        for(const r of g.rows) L.push('    - ' + r.name + (r.count > 1 ? ' ×' + r.count : ''));
      }
    }
  }
  const ppl = tag => peopleReg().filter(p=>p.tag === tag);
  for(const [tag, name] of [['crew','CREW'],['cast','CAST'],['client','CLIENT']]){
    if(o.inc && o.inc[tag] === false) continue;
    const list = ppl(tag);
    if(!list.length) continue;
    L.push(''); L.push(name + ':');
    for(const p of list)
      L.push('  ' + [p.call, p.role, p.name, p.phone, p.email].filter(Boolean).join(' · '));
  }
  if(o.wx && o.wx.data){
    L.push(''); L.push('WEATHER (' + (o.wx.place || '') + '):');
    for(const [k, v] of o.wx.data) L.push('  ' + k + ': ' + v);
  }
  L.push(''); L.push('— sent from Floorboard');
  return L.join('\n');
}
function mailCallSheet(o, tag){
  const ems = sheetEmails(o, tag);
  const who = tag || 'everyone';
  if(!ems.length){
    toast('No ' + who + ' email addresses yet — add them on the registry cards');
    return;
  }
  // the PDF downloads alongside the draft — newest file, ready to drag in
  // (browsers cannot attach files to mailto:; "Share PDF…" attaches for real)
  try{ exportCallSheetPDF(o); }catch(e){ console.warn('pdf for mail failed', e); }
  const day = dayFor(o);
  const subject = 'Call sheet — ' + (project.shootName || 'production') +
    (day && day.date ? ' — ' + day.date : '');
  let body = callSheetText(o);
  if(body.length > 1600) body = body.slice(0, 1600) + '\n…'; // mailto URL limits
  setTimeout(()=>{
    location.href = 'mailto:?bcc=' + encodeURIComponent(ems.join(',')) +
      '&subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
    toast('Mail to ' + who + ' (' + ems.length + ' BCC) — the PDF just downloaded, drag it into the draft');
  }, 350);
}
// real attachment via the OS share sheet (Mail on macOS/iPadOS) where supported
async function shareCallSheetPDF(o){
  const {bytes, name} = buildCallSheetPDF(o);
  const file = new File([bytes], name, {type:'application/pdf'});
  if(navigator.canShare && navigator.canShare({files:[file]})){
    try{
      await navigator.share({files:[file], title:name});
      return;
    }catch(e){ if(e.name === 'AbortError') return; }
  }
  // no share sheet on this browser — fall back to a download
  exportCallSheetPDF(o);
  toast('Sharing not supported here — PDF downloaded instead');
}

// one-page call-sheet PDF: the card rendered alone, A4 portrait
function buildCallSheetPDF(o){
  render(); // fresh self-sizing
  const scale = 3;
  const c = document.createElement('canvas');
  c.width = Math.ceil(o.w*scale); c.height = Math.ceil(o.h*scale);
  const prevCtx = ctx, prevSel = sel;
  ctx = c.getContext('2d');
  sel = null; // no selection chrome in print
  ctx.fillStyle = THEME.card;
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.setTransform(scale, 0, 0, scale, (o.w/2 - o.x)*scale, (o.h/2 - o.y)*scale);
  try{ drawObject(o); }
  finally { ctx = prevCtx; sel = prevSel; render(); }
  const jpeg = atob(c.toDataURL('image/jpeg', .92).split(',')[1]);
  const PW = 595, PH = 842, M = 36; // A4 portrait
  const maxW = PW - M*2, maxH = PH - M*2;
  const k = Math.min(maxW/c.width, maxH/c.height);
  const iw = c.width*k, ih = c.height*k;
  const ix = (PW - iw)/2, iy = PH - M - ih; // top-aligned under the margin
  const content = 'q ' + iw.toFixed(2) + ' 0 0 ' + ih.toFixed(2) + ' ' + ix.toFixed(2) + ' ' + iy.toFixed(2) +
    ' cm /Im1 Do Q';
  // clickable phone / mail / maps links: the renderer left card-local rects in
  // o._csLinks — map them through the same transform into PDF Link annotations
  const annots = (o._csLinks || []).map(L=>{
    const px = v => ix + ((v + o.w/2) * scale / c.width) * iw;         // card x → pdf x
    const py = v => iy + ih - ((v + o.h/2) * scale / c.height) * ih;   // card y → pdf y (flipped)
    const rect = [px(L.x), py(L.y + L.h), px(L.x + L.w), py(L.y)];
    const uri = String(L.u).replace(/([\\()])/g, '\\$1');
    return '<< /Type /Annot /Subtype /Link /Rect [' + rect.map(v=>v.toFixed(2)).join(' ') +
      '] /Border [0 0 0] /A << /S /URI /URI (' + uri + ') >> >>';
  });
  const annotRefs = annots.map((_, i)=>(6 + i) + ' 0 R').join(' ');
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW + ' ' + PH + '] ' +
      '/Resources << /XObject << /Im1 5 0 R >> >> /Contents 4 0 R' +
      (annots.length ? ' /Annots [' + annotRefs + ']' : '') + ' >>',
    '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream',
    '<< /Type /XObject /Subtype /Image /Width ' + c.width + ' /Height ' + c.height +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpeg.length +
      ' >>\nstream\n' + jpeg + '\nendstream',
    ...annots,
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objs.forEach((obj, i)=>{
    offsets.push(pdf.length);
    pdf += (i+1) + ' 0 obj\n' + obj + '\nendobj\n';
  });
  const xref = pdf.length;
  pdf += 'xref\n0 ' + (objs.length+1) + '\n0000000000 65535 f \n';
  for(let i=1;i<=objs.length;i++) pdf += String(offsets[i]).padStart(10,'0') + ' 00000 n \n';
  pdf += 'trailer\n<< /Size ' + (objs.length+1) + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF';
  const bytes = new Uint8Array(pdf.length);
  for(let i=0;i<pdf.length;i++) bytes[i] = pdf.charCodeAt(i) & 0xFF;
  const csDay = dayFor(o);
  const name = ((project.shootName || 'production').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_') || 'production') +
    '_callsheet' + (o.allDays ? '_all-days' : (csDay && csDay.date ? '_' + csDay.date : '')) + '.pdf';
  return {bytes, name};
}
function exportCallSheetPDF(o){
  const {bytes, name} = buildCallSheetPDF(o);
  const a = document.createElement('a');
  a.download = name;
  a.href = URL.createObjectURL(new Blob([bytes], {type:'application/pdf'}));
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 5000);
  toast('Call sheet PDF exported');
}

// ---------------------------------------------------------------- pdf.js (lazy, self-hosted)
let _pdfjsReady = null;
function loadPdfJs(){
  if(window.pdfjsLib) return Promise.resolve();
  if(_pdfjsReady) return _pdfjsReady;
  _pdfjsReady = new Promise((ok, bad)=>{
    const sc = document.createElement('script');
    sc.src = './js/vendor/pdf.min.js';
    sc.onload = ()=>{
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = './js/vendor/pdf.worker.min.js';
      ok();
    };
    sc.onerror = ()=>bad(new Error('pdf.js failed to load'));
    document.head.appendChild(sc);
  });
  return _pdfjsReady;
}
async function extractPdfText(file){
  await loadPdfJs();
  const buf = await file.arrayBuffer();
  const doc = await window.pdfjsLib.getDocument({data:buf}).promise;
  const out = [];
  for(let p=1; p<=doc.numPages; p++){
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    let lastY = null, line = [];
    for(const it of tc.items){
      const y = Math.round(it.transform[5]);
      if(lastY !== null && Math.abs(y - lastY) > 3){
        out.push(line.join(''));
        line = [];
      }
      line.push(it.str);
      lastY = y;
    }
    out.push(line.join(''));
    out.push('');
  }
  return out.join('\n');
}
async function pdfFirstPageThumb(file){
  await loadPdfJs();
  const buf = await file.arrayBuffer();
  const doc = await window.pdfjsLib.getDocument({data:buf}).promise;
  const page = await doc.getPage(1);
  const vp0 = page.getViewport({scale:1});
  const scale = 420 / vp0.width;
  const vp = page.getViewport({scale});
  const c = document.createElement('canvas');
  c.width = Math.round(vp.width); c.height = Math.round(vp.height);
  await page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
  return c.toDataURL('image/jpeg', .8);
}

// pick one or more stills for an AV row (append), or replace one (idx set)
function pickAvStill(row, idx){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = 'image/*';
  if(idx == null) fi.multiple = true;
  fi.addEventListener('change', async ()=>{
    if(!fi.files || !fi.files.length) return;
    try{
      row.imgs = row.imgs || [];
      if(idx != null) row.imgs[idx] = await storeImageFile(fi.files[0]);
      else for(const f of fi.files) row.imgs.push(await storeImageFile(f));
      markDirty(); render(); refreshSelBar();
    }catch(e){ toast('Could not store that image — try a smaller one'); }
  });
  fi.click();
}

// ---------------------------------------------------------------- PDF → board
// every page rendered full-res (≤1600px wide, JPEG) onto a fresh sub-board
async function pdfPagesToSubboard(buf, name, x, y){
  await loadPdfJs();
  const doc = await window.pdfjsLib.getDocument({data:buf}).promise;
  const sub = {id:uid(), cat:'subboard', kind:'subboard', x, y, rot:0, w:260, h:180,
    color:'#5B6472', label:(name || 'PDF').replace(/\.pdf$/i,''), path:[],
    board:{id:uid(), name:'', objects:[], walls:[], stills:[], shots:[]}};
  let yy = 0;
  for(let p = 1; p <= doc.numPages; p++){
    toast('Rendering page ' + p + ' / ' + doc.numPages + '…');
    const page = await doc.getPage(p);
    const vp0 = page.getViewport({scale:1});
    const scale = Math.min(3, 1600 / vp0.width);
    const vp = page.getViewport({scale});
    const c = document.createElement('canvas');
    c.width = Math.round(vp.width); c.height = Math.round(vp.height);
    await page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
    const dataURL = c.toDataURL('image/jpeg', .85);
    const id = uid();
    await window.storage.set('sd:img:' + id, dataURL);
    const im = new Image(); im.src = dataURL;
    imgCache[id] = im;
    const w = 620, h = Math.round(620 * vp.height / vp.width);
    sub.board.objects.push({id:uid(), cat:'image', kind:'image', imgId:id,
      x:0, y:yy + h/2, rot:0, w, h, color:'#5B6472', label:'p. ' + p, path:[]});
    yy += h + 40;
  }
  activeShot().objects.push(sub);
  sel = {type:'object', id:sub.id};
  markDirty(); render(); refreshSelBar();
  toast(doc.numPages + ' page' + (doc.numPages === 1 ? '' : 's') +
    ' → sub-board “' + sub.label + '” — double-click to open');
  return sub;
}
async function pdfFileToSubboard(f, x, y){
  try{ await pdfPagesToSubboard(await f.arrayBuffer(), f.name, x, y); }
  catch(e){ console.error('pdf → board failed', e); toast('Could not read that PDF'); }
}
async function pdfCardToSubboard(o){
  try{
    toast('Reading PDF…');
    const r = await window.storage.get('sd:file:' + o.fileId);
    if(!r || !r.value){ toast('File data not found'); return; }
    const blob = await (await fetch(r.value)).blob();
    await pdfPagesToSubboard(await blob.arrayBuffer(), o.name, o.x + o.w/2 + 200, o.y);
  }catch(e){ console.error('pdf → board failed', e); toast('Could not read that PDF'); }
}

// import a script file straight into a script block (.txt / .fountain / .fdx / .pdf)
function importIntoScriptBlock(o){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = '.txt,.fountain,.fdx,.pdf';
  fi.addEventListener('change', async ()=>{
    const file = fi.files && fi.files[0];
    if(!file) return;
    let text;
    try{
      if(file.name.toLowerCase().endsWith('.pdf')){
        toast('Reading PDF\u2026');
        text = await extractPdfText(file);
      } else {
        text = await file.text();
        if(file.name.toLowerCase().endsWith('.fdx')){
          const doc = new DOMParser().parseFromString(text, 'text/xml');
          text = [...doc.querySelectorAll('Paragraph')].map(p=>{
            const t = [...p.querySelectorAll('Text')].map(x=>x.textContent).join('');
            return (p.getAttribute('Type') === 'Scene Heading') ? t.toUpperCase() : t;
          }).join('\n');
        }
      }
    }catch(e){
      console.warn('script import failed', e);
      toast('Could not read that file');
      return;
    }
    o.text = text;
    markDirty(); render();
    toast('Script imported \u2014 hit "Break down" when ready');
  });
  fi.click();
}

// ---------------------------------------------------------------- audio on boards
let audioEl = null, audioPlayingId = null;
async function toggleAudio(o){
  if(audioPlayingId === o.id){
    if(audioEl) audioEl.pause();
    audioPlayingId = null;
    render();
    return;
  }
  try{
    const r = await window.storage.get('sd:file:' + o.fileId);
    if(!r || !r.value){ toast('Audio data not found'); return; }
    if(!audioEl){
      audioEl = new Audio();
      audioEl.addEventListener('ended', ()=>{ audioPlayingId = null; render(); });
    }
    audioEl.src = r.value;
    await audioEl.play();
    audioPlayingId = o.id;
    render();
  }catch(e){
    console.warn('audio play failed', e);
    toast('Could not play that file');
  }
}
async function addBoardAudioAt(file, x, y){
  if(file.size > 8*1024*1024){ toast('Audio up to ~8 MB \u2014 this one is too large'); return; }
  try{
    const dataURL = await new Promise((ok, bad)=>{
      const r = new FileReader();
      r.onload = ()=>ok(r.result); r.onerror = ()=>bad(r.error);
      r.readAsDataURL(file);
    });
    const id = uid();
    await window.storage.set('sd:file:' + id, dataURL);
    activeScene().objects.push({id:uid(), cat:'audio', kind:'audio',
      x, y, rot:0, w:280, h:60,
      fileId:id, name:file.name, size:file.size,
      color:'#8B5CF6', label:'', path:[]});
    markDirty(); render();
    toast('Audio added \u2014 tap \u25b8 to play');
  }catch(e){ toast('Could not store that audio file'); }
}
function pickBoardAudio(){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = 'audio/*,.mp3,.aac,.m4a,.wav,.ogg,.flac';
  fi.addEventListener('change', ()=>{
    if(!fi.files || !fi.files[0]) return;
    const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
    addBoardAudioAt(fi.files[0], c.x, c.y);
  });
  fi.click();
}

// --- rule-based screenplay parsing (the AI pass lands in Phase 1) ---
const SCENE_HEADING_RE = /^\s*(?:\d+[.\s]+)?(INT\.?\/EXT\.?|EXT\.?\/INT\.?|I\/E\.?|INT\.?|EXT\.?)\s+(.+?)\s*$/i;
const TRANSITION_RE = /^(CUT TO|FADE (IN|OUT|TO)|DISSOLVE TO|SMASH CUT|MATCH CUT|CONTINUED)\b/i;
function parseScreenplay(text){
  const lines = text.split(/\r?\n/);
  const scenes = [];
  let cur = null;
  for(let i=0;i<lines.length;i++){
    const line = lines[i];
    const m = line.match(SCENE_HEADING_RE);
    if(m){
      if(cur) scenes.push(cur);
      const dn = (line.match(/\b(DAY|NIGHT|DAWN|DUSK|MORNING|EVENING|AFTERNOON)\b/i)||[])[1] || '';
      cur = {heading: line.trim(), intExt: m[1].toUpperCase().replace(/\.+$/,''),
             dayNight: dn.toUpperCase(), body: [], characters: new Set()};
      continue;
    }
    if(!cur) continue;
    cur.body.push(line);
    // character cue: an UPPERCASE line, not a transition, followed by dialogue
    const t = line.trim().replace(/\s*\((?:V\.?O\.?|O\.?S\.?|CONT'?D|O\.?C\.?)\.?\)\s*$/i,'');
    if(t && t === t.toUpperCase() && /^[A-Z][A-Z0-9 .'\-]{0,29}$/.test(t) &&
       !TRANSITION_RE.test(t) && !SCENE_HEADING_RE.test(t)){
      const next = (lines[i+1]||'').trim();
      if(next && !SCENE_HEADING_RE.test(next) && next !== next.toUpperCase()){
        cur.characters.add(t);
      }
    }
  }
  if(cur) scenes.push(cur);
  return scenes.map(s=>({...s, characters:[...s.characters], body:s.body.join('\n').trim()}));
}
function parseAV(text){
  // v1: each blank-line-separated paragraph becomes a scene
  return text.split(/\n\s*\n/).map(p=>p.trim()).filter(Boolean).map((p,i)=>({
    heading: 'Scene ' + (i+1) + ' — ' + p.split('\n')[0].slice(0,60),
    intExt:'', dayNight:'', body:p, characters:[],
  }));
}
function createScenesFromBreakdown(parsed){
  const made = [];
  // every project is born with an empty "Scene 1" — if it's still untouched,
  // the first detected scene takes its place so numbering starts at 1
  const pristine = s => !s.objects.length && !s.walls.length && !s.stills.length &&
    !s.script && !s.scene && !s.sceneDesc && !(s.shots || []).length &&
    /^Scene \d+$/.test(s.name || '');
  const reusable = (project.scenes.length === 1 && pristine(project.scenes[0]))
    ? project.scenes[0] : null;
  const startN = reusable ? 0 : project.scenes.length;
  parsed.forEach((s, i)=>{
    let sc;
    if(i === 0 && reusable){
      sc = reusable;
    } else {
      sc = newShot(startN + i + 1);
      project.scenes.push(sc);
    }
    sc.name = 'Sc ' + (startN + i + 1);
    sc.scene = String(startN + i + 1);
    sc.sceneDesc = s.heading.replace(SCENE_HEADING_RE, (m0,p1,p2)=>p1 + ' ' + p2) || s.heading;
    sc.script = s.body;
    // place detected cast as actor icons, fanned out in the middle
    s.characters.slice(0, 8).forEach((name, ci)=>{
      sc.objects.push({id:uid(), cat:'actor', kind: ci===0 ? 'actor' : 'actor_ant',
        x: -140 + (ci%4)*95, y: -60 + Math.floor(ci/4)*110, rot: 0,
        w:34, h:34, color: COLORS[ci % COLORS.length], label: name, path:[]});
    });
    made.push(sc);
  });
  if(!project.activeSceneId && project.scenes.length) project.activeSceneId = project.scenes[0].id;
  markDirty();
  buildShotList(); buildInfo();
  return made;
}

// breakdown from a script block ON the canvas: scenes + a storyboard column
function breakDownScriptBlock(o){
  const parsed = o.mode === 'av'
    ? parseAV(o.text || '')
    : parseScreenplay(o.text || '');
  if(!parsed.length){
    toast(o.mode === 'av'
      ? 'No scenes found — AV blocks split on blank lines in the VIDEO column'
      : 'No scenes found — use headings like INT. KITCHEN \u2014 DAY');
    return;
  }
  const scenes = createScenesFromBreakdown(parsed);
  // when the block carries a label, its scenes group under that film name
  const film = (o.label || '').trim();
  if(film) scenes.forEach(sc=>{ sc.film = film; sc.filmSrc = o.id; });
  const board = activeScene();
  const x0 = o.x + o.w/2 + 340;
  let y = o.y - o.h/2 + 60;
  scenes.forEach((sc, i)=>{
    board.objects.push({id:uid(), cat:'sbrow', kind:'sbrow',
      x:x0, y:y + i*140, rot:0, w:560, h:120,
      title:(sc.scene ? 'Scene ' + sc.scene : sc.name) + (sc.sceneDesc ? ' \u2014 ' + sc.sceneDesc : ''),
      desc:'', imgId:null, sceneId:sc.id,
      color:COLORS[i % COLORS.length], label:'', path:[]});
  });
  markDirty(); render(); refreshSelBar();
  toast(scenes.length + ' scenes broken down \u2014 storyboard rows added to the right');
}
// ---------------------------------------------------------------- script / AV exports (PDF + Word)
function dlBlob(name, blob){
  const a = document.createElement('a');
  a.download = name;
  a.href = URL.createObjectURL(blob);
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 5000);
}
function exportName(o, fallback){
  return ((o.label || '').trim() || fallback).replace(/[^\w\u00c0-\u024f -]+/g, '').slice(0, 60) || fallback;
}
// minimal A4-portrait text PDF: blocks of {t, bold, dim, size, gap}, auto-paginating
function textPDF(title, blocks){
  const W = 595, H = 842, M = 54;
  const objs = [], kids = [];
  const add = b => { objs.push(b); return objs.length; };
  add(null); add(null);
  const f1 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const f2 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');
  const pagesC = [];
  let c = '', y = H - M;
  const page = ()=>{ if(c) pagesC.push(c); c = ''; y = H - M; };
  c += `BT /F2 15 Tf ${M} ${y - 12} Td 0.2 0.2 0.18 rg (${pdfEsc(title)}) Tj ET\n`;
  y -= 36;
  for(const b of (blocks || [])){
    const size = b.size || 10, lh = size * 1.35;
    for(const l of pdfWrap(b.t || ' ', Math.floor((W - M*2) / (size * .52)))){
      if(y < M + lh) page();
      c += `BT /F${b.bold ? 2 : 1} ${size} Tf ${M} ${(y - size).toFixed(1)} Td ` +
        `${b.dim ? '0.55 0.53 0.5' : '0.27 0.26 0.24'} rg (${pdfEsc(l)}) Tj ET\n`;
      y -= lh;
    }
    y -= b.gap || 0;
  }
  pagesC.push(c);
  pagesC.forEach(cc=>{
    const cn = add({stream:cc, dict:`<< /Length ${cc.length} >>`});
    kids.push(add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] ` +
      `/Resources << /Font << /F1 ${f1} 0 R /F2 ${f2} 0 R >> >> /Contents ${cn} 0 R >>`));
  });
  objs[0] = '<< /Type /Catalog /Pages 2 0 R >>';
  objs[1] = `<< /Type /Pages /Kids [${kids.map(k=>k+' 0 R').join(' ')}] /Count ${kids.length} >>`;
  let out = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n';
  const offs = [];
  objs.forEach((ob, i)=>{
    offs.push(out.length);
    out += `${i+1} 0 obj\n`;
    out += (typeof ob === 'string') ? ob + '\nendobj\n'
      : ob.dict + '\nstream\n' + ob.stream + '\nendstream\nendobj\n';
  });
  const xr = out.length;
  out += `xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
  offs.forEach(of=>{ out += String(of).padStart(10, '0') + ' 00000 n \n'; });
  out += `trailer\n<< /Size ${objs.length+1} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`;
  const bytes = new Uint8Array(out.length);
  for(let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xFF;
  return new Blob([bytes], {type:'application/pdf'});
}
// ---- real .docx (Pages refused the HTML-as-.doc trick) ----
// a .docx is a ZIP of OOXML parts; STORED zip entries need only a CRC32
const CRC_T = (()=>{
  const t = new Uint32Array(256);
  for(let n = 0; n < 256; n++){
    let c = n;
    for(let k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(u8){
  let c = 0xFFFFFFFF;
  for(let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function zipBlob(files){ // [{name, data: string|Uint8Array}] \u2192 stored zip
  const enc = new TextEncoder();
  const parts = [], central = [];
  let off = 0;
  const le16 = v=>[v & 255, (v >> 8) & 255];
  const le32 = v=>[v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
  for(const f of files){
    const data = typeof f.data === 'string' ? enc.encode(f.data) : f.data;
    const name = enc.encode(f.name);
    const crc = crc32(data);
    const head = new Uint8Array([0x50,0x4B,3,4, ...le16(20), 0,0, 0,0, 0,0, 0,0,
      ...le32(crc), ...le32(data.length), ...le32(data.length),
      ...le16(name.length), 0,0]);
    parts.push(head, name, data);
    central.push({name, crc, size:data.length, off});
    off += head.length + name.length + data.length;
  }
  const cd = [];
  for(const c of central)
    cd.push(new Uint8Array([0x50,0x4B,1,2, ...le16(20), ...le16(20), 0,0, 0,0, 0,0, 0,0,
      ...le32(c.crc), ...le32(c.size), ...le32(c.size), ...le16(c.name.length),
      0,0, 0,0, 0,0, 0,0, ...le32(0), ...le32(c.off)]), c.name);
  const cdLen = cd.reduce((a, u)=>a + u.length, 0);
  cd.push(new Uint8Array([0x50,0x4B,5,6, 0,0, 0,0, ...le16(central.length),
    ...le16(central.length), ...le32(cdLen), ...le32(off), 0,0]));
  return new Blob([...parts, ...cd],
    {type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'});
}
function xmlEsc(s){
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'');
}
function dataUrlBytes(src){
  const b64 = src.split(',')[1];
  const bin = atob(b64);
  const u8 = new Uint8Array(bin.length);
  for(let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}
// wrap paragraphs/runs; bodyXml goes inside <w:body>, images as media entries
function docxBlob(bodyXml, media, landscape){
  const rels = media.map((m, i)=>
    `<Relationship Id="rImg${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${m.name}"/>`).join('');
  const sect = landscape
    ? '<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="720" w:right="720" w:bottom="720" w:left="720"/></w:sectPr>'
    : '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr>';
  const doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ' +
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ' +
    'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" ' +
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ' +
    'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">' +
    '<w:body>' + bodyXml + sect + '</w:body></w:document>';
  return zipBlob([
    {name:'[Content_Types].xml', data:'<?xml version="1.0"?>' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Default Extension="jpeg" ContentType="image/jpeg"/>' +
      '<Default Extension="png" ContentType="image/png"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'},
    {name:'_rels/.rels', data:'<?xml version="1.0"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'},
    {name:'word/_rels/document.xml.rels', data:'<?xml version="1.0"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + rels + '</Relationships>'},
    {name:'word/document.xml', data:doc},
    ...media.map(m=>({name:'word/media/' + m.name, data:m.data})),
  ]);
}
function docxP(text, opts){ // paragraph, \n \u2192 separate runs with breaks
  const o = opts || {};
  const rpr = '<w:rPr>' + (o.bold ? '<w:b/>' : '') +
    `<w:sz w:val="${(o.pt || 10) * 2}"/></w:rPr>`;
  const runs = String(text ?? '').split('\n').map((l, i)=>
    (i ? '<w:r><w:br/></w:r>' : '') +
    '<w:r>' + rpr + '<w:t xml:space="preserve">' + xmlEsc(l) + '</w:t></w:r>').join('');
  return '<w:p>' + runs + '</w:p>';
}
function docxImgRun(idx, wPx, hPx){
  const cx = Math.round(wPx * 9525), cy = Math.round(hPx * 9525);
  return '<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">' +
    `<wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${idx}" name="img${idx}"/>` +
    '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">' +
    `<pic:pic><pic:nvPicPr><pic:cNvPr id="${idx}" name="img${idx}"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip r:embed="rImg${idx}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>' +
    '</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
}
function scriptExportBlocks(o){
  const blocks = [];
  if(o.mode === 'av'){
    blocks.push({t:'VIDEO', bold:true, gap:2});
    blocks.push({t:o.text || '\u2014', gap:12});
    blocks.push({t:'AUDIO', bold:true, gap:2});
    blocks.push({t:o.textR || '\u2014'});
  } else {
    blocks.push({t:o.text || '\u2014'});
  }
  return blocks;
}
function exportScriptPDF(o){
  const name = exportName(o, 'script');
  dlBlob(name + '.pdf', textPDF(name, scriptExportBlocks(o)));
}
function exportScriptDocx(o){
  const name = exportName(o, 'script');
  let body = docxP(name, {bold:true, pt:15});
  if(o.mode === 'av'){
    body += docxP('VIDEO', {bold:true, pt:12}) + docxP(o.text || '\u2014') +
            docxP('AUDIO', {bold:true, pt:12}) + docxP(o.textR || '\u2014');
  } else {
    body += docxP(o.text || '\u2014');
  }
  dlBlob(name + '.docx', docxBlob(body, [], false));
}
// the AV table exports row by row: header line (SC \u00b7 time \u00b7 sec), then every
// filled text column \u2014 custom columns included via avCols
// the AV exports mirror the BOARD: every visible column (incl. custom ones),
// in board order, with the stills in their own column
function avExportLayout(o){
  return (o._avCols || avCols(o)).map(([key, label, w])=>({key, label, w}));
}
function exportAvPDF(o){
  // A4 landscape table, exactly the board's columns; stills embedded as JPEGs
  const name = exportName(o, 'AV script');
  const W = 842, H = 595, M = 36, FS = 8, LH = 10.5, PAD = 5;
  const lay = avExportLayout(o);
  const k = (W - M*2) / lay.reduce((a, c)=>a + c.w, 0);
  const colW = lay.map(c=>c.w * k);
  const objs = [], kids = [];
  const add = b => { objs.push(b); return objs.length; };
  add(null); add(null);
  const f1 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
  const f2 = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');
  const pages = [];
  let c = '', xobjs = {}, imgN = 0, y = 0;
  const headRow = ()=>{
    let x = M;
    c += `BT /F2 8 Tf 0.45 0.43 0.4 rg\n`;
    lay.forEach((col, ci)=>{ c += `1 0 0 1 ${(x+PAD).toFixed(1)} ${(y-11).toFixed(1)} Tm (${pdfEsc(col.label)}) Tj\n`; x += colW[ci]; });
    c += 'ET\n';
    y -= 16;
  };
  const page = ()=>{
    if(c) pages.push({c, xobjs});
    c = ''; xobjs = {}; y = H - M;
    c += `BT /F2 13 Tf ${M} ${(y-10).toFixed(1)} Td 0.2 0.2 0.18 rg (${pdfEsc(name)}) Tj ET\n`;
    y -= 26;
    headRow();
  };
  page();
  for(const r of (o.rows || [])){
    // measure the row first: wrapped lines per text column + still height
    const cells = lay.map((col, ci)=>{
      if(col.key === 'still') return null;
      return pdfWrap(r[col.key] || '', Math.max(4, Math.floor((colW[ci] - PAD*2) / (FS * .52))));
    });
    const stills = (o.cols && o.cols.still)
      ? (r.imgs || []).map(id=>imgCache[id])
          .filter(im=>im && im.complete && im.naturalWidth && im.src.startsWith('data:image/jpeg'))
      : [];
    const IH = 44;
    let rh = Math.max(LH + PAD*2,
      Math.max(...cells.map(l=>l ? l.length : 0)) * LH + PAD*2,
      stills.length ? IH + PAD*2 : 0);
    if(y - rh < M){ page(); }
    // grid line above the row
    c += `0.85 0.84 0.82 RG 0.5 w ${M} ${y.toFixed(1)} m ${(W-M).toFixed(1)} ${y.toFixed(1)} l S\n`;
    let x = M;
    lay.forEach((col, ci)=>{
      if(col.key === 'still'){
        let ix = x + PAD;
        for(const im of stills){
          const iw = IH * (im.naturalWidth / im.naturalHeight);
          if(ix + iw > x + colW[ci] - PAD) break;
          const nm = 'I' + (++imgN);
          xobjs[nm] = {data:atob(im.src.split(',')[1]), w:im.naturalWidth, h:im.naturalHeight};
          c += `q ${iw.toFixed(1)} 0 0 ${IH} ${ix.toFixed(1)} ${(y - PAD - IH).toFixed(1)} cm /${nm} Do Q\n`;
          ix += iw + 4;
        }
      } else {
        const bold = col.key === 'no';
        c += `BT /F${bold ? 2 : 1} ${FS} Tf ${bold ? '0.2 0.2 0.18' : '0.27 0.26 0.24'} rg\n`;
        (cells[ci] || []).forEach((l, li)=>{
          c += `1 0 0 1 ${(x+PAD).toFixed(1)} ${(y - PAD - FS - li*LH).toFixed(1)} Tm (${pdfEsc(l)}) Tj\n`;
        });
        c += 'ET\n';
      }
      x += colW[ci];
    });
    y -= rh;
  }
  pages.push({c, xobjs});
  pages.forEach(p=>{
    const xo = Object.entries(p.xobjs).map(([nm, im])=>{
      const n = add({stream:im.data, dict:
        `<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${im.data.length} >>`});
      return `/${nm} ${n} 0 R`;
    }).join(' ');
    const cn = add({stream:p.c, dict:`<< /Length ${p.c.length} >>`});
    kids.push(add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] ` +
      `/Resources << /Font << /F1 ${f1} 0 R /F2 ${f2} 0 R >>${xo ? ' /XObject << ' + xo + ' >>' : ''} >> /Contents ${cn} 0 R >>`));
  });
  objs[0] = '<< /Type /Catalog /Pages 2 0 R >>';
  objs[1] = `<< /Type /Pages /Kids [${kids.map(k2=>k2+' 0 R').join(' ')}] /Count ${kids.length} >>`;
  let out = '%PDF-1.4\n%\xE2\xE3\xCF\xD3\n';
  const offs = [];
  objs.forEach((ob, i)=>{
    offs.push(out.length);
    out += `${i+1} 0 obj\n`;
    out += (typeof ob === 'string') ? ob + '\nendobj\n'
      : ob.dict + '\nstream\n' + ob.stream + '\nendstream\nendobj\n';
  });
  const xr = out.length;
  out += `xref\n0 ${objs.length+1}\n0000000000 65535 f \n`;
  offs.forEach(of=>{ out += String(of).padStart(10, '0') + ' 00000 n \n'; });
  out += `trailer\n<< /Size ${objs.length+1} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`;
  const bytes = new Uint8Array(out.length);
  for(let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xFF;
  dlBlob(name + '.pdf', new Blob([bytes], {type:'application/pdf'}));
}
function exportAvDocx(o){
  const name = exportName(o, 'AV script');
  const lay = avExportLayout(o);
  const total = lay.reduce((a, c)=>a + c.w, 0);
  const gridW = 15400; // landscape A4 minus margins, in twips
  const colTw = lay.map(c=>Math.round(c.w / total * gridW));
  const media = [];
  const borders = '<w:tblBorders>' +
    ['top','left','bottom','right','insideH','insideV']
      .map(s=>`<w:${s} w:val="single" w:sz="4" w:color="CCCCCC"/>`).join('') + '</w:tblBorders>';
  const tc = (inner, tw)=>`<w:tc><w:tcPr><w:tcW w:w="${tw}" w:type="dxa"/></w:tcPr>` +
    (inner || '<w:p/>') + '</w:tc>';
  let body = docxP(name, {bold:true, pt:15}) +
    '<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/>' + borders + '</w:tblPr>' +
    '<w:tblGrid>' + colTw.map(w=>`<w:gridCol w:w="${w}"/>`).join('') + '</w:tblGrid>' +
    '<w:tr>' + lay.map((c2, ci)=>tc(docxP(c2.label, {bold:true, pt:9}), colTw[ci])).join('') + '</w:tr>';
  for(const r of (o.rows || [])){
    body += '<w:tr>' + lay.map((col, ci)=>{
      if(col.key === 'still'){
        const runs = (r.imgs || []).map(id=>imgCache[id])
          .filter(im=>im && im.src && im.src.startsWith('data:image/'))
          .map(im=>{
            const ext = /png/.test(im.src.slice(0, 22)) ? 'png' : 'jpeg';
            media.push({name:'image' + (media.length + 1) + '.' + ext, data:dataUrlBytes(im.src)});
            const h = 70, w = Math.round(h * (im.naturalWidth || 16) / (im.naturalHeight || 9));
            return docxImgRun(media.length, w, h);
          }).join('');
        return tc(runs, colTw[ci]);
      }
      return tc(docxP(r[col.key] || '', {pt:9}), colTw[ci]);
    }).join('') + '</w:tr>';
  }
  body += '</w:tbl>';
  dlBlob(name + '.docx', docxBlob(body, media, true));
}

// screenplay \u2192 editable AV table: one row per scene (SC number + the scene's
// text in VIDEO). From there rows, custom columns, stills and regie notes are
// free, and "Break down \u2192 scenes" keeps the Shot designer in sync.
function avTableFromScript(o){
  const parsed = o.mode === 'av' ? parseAV(o.text || '') : parseScreenplay(o.text || '');
  if(!parsed.length){
    toast(o.mode === 'av'
      ? 'No scenes found \u2014 AV blocks split on blank lines in the VIDEO column'
      : 'No scenes found \u2014 use headings like INT. KITCHEN \u2014 DAY');
    return;
  }
  // if the block was already broken down the old way, reuse THOSE scene
  // numbers (parse order = creation order) so the AV sync updates instead of
  // duplicating; otherwise plain 1..n
  const prev = project.scenes.filter(s=>s.filmSrc === o.id);
  const rows = parsed.map((s, i)=>({id:uid(),
    no: prev[i] ? String(prev[i].scene || (i + 1)) : String(i + 1), time:'', dur:'',
    audio:'', video:(s.heading ? s.heading + '\n' : '') + (s.body || ''),
    notes:'', imgs:[]}));
  const card = {id:uid(), cat:'avscript', kind:'avscript',
    x:o.x + o.w/2 + 460, y:o.y, rot:0, w:900, h:200,
    color:'#8B7BD8', label:(o.label || '').trim(), path:[],
    cols:{no:true, still:false, notes:true}, rows};
  activeScene().objects.push(card);
  sel = {type:'object', id:card.id};
  markDirty(); render(); refreshSelBar();
  toast(parsed.length + ' scenes in an AV table \u2014 add rows & columns, then Break down \u2192 scenes');
}
function pickSbImage(o){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = 'image/*';
  fi.addEventListener('change', async ()=>{
    if(!fi.files || !fi.files[0]) return;
    try{
      o.imgId = await storeImageFile(fi.files[0]);
      await loadStill(o.imgId);
      markDirty(); render(); refreshSelBar();
    }catch(e){ toast('Could not store that image \u2014 try a smaller one'); }
  });
  fi.click();
}
// file objects (docs / pdfs) on any board
async function addBoardFileAt(file, x, y){
  if(file.size > 4.5*1024*1024){ toast('Files up to ~4 MB \u2014 this one is too large'); return; }
  try{
    const dataURL = await new Promise((ok, bad)=>{
      const r = new FileReader();
      r.onload = ()=>ok(r.result); r.onerror = ()=>bad(r.error);
      r.readAsDataURL(file);
    });
    const id = uid();
    await window.storage.set('sd:file:' + id, dataURL);
    const obj = {id:uid(), cat:'file', kind:'file',
      x, y, rot:0, w:230, h:64,
      fileId:id, name:file.name, size:file.size, mime:file.type,
      color:'#5B6472', label:'', path:[]};
    activeScene().objects.push(obj);
    markDirty(); render();
    toast('File added \u2014 select it to download');
    // PDFs get a first-page preview
    if((file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'))){
      try{
        const thumbURL = await pdfFirstPageThumb(file);
        const tid = uid();
        await window.storage.set('sd:img:' + tid, thumbURL);
        const im = new Image();
        im.src = thumbURL;
        imgCache[tid] = im;
        im.onload = ()=>render();
        obj.imgId = tid;
        obj.w = 190; obj.h = 250;
        markDirty(); render();
      }catch(e){ console.warn('pdf thumb failed', e); }
    }
  }catch(e){ toast('Could not store that file'); }
}
function pickBoardFile(){
  const fi = document.createElement('input');
  fi.type = 'file';
  fi.addEventListener('change', ()=>{
    if(!fi.files || !fi.files[0]) return;
    const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
    addBoardFileAt(fi.files[0], c.x, c.y);
  });
  fi.click();
}

// single-board PDF (moodboard / production board) — A4 landscape, image fitted
async function exportBoardPDF(){
  const board = activeScene();
  await ensureShotImages(board, false);
  const plan = renderShotPlan(board, 1800, null, false);
  const jpeg = atob(plan.toDataURL('image/jpeg', .82).split(',')[1]);
  const PW = 842, PH = 595, M = 28;
  const maxW = PW - M*2, maxH = PH - M*2 - 20;
  const k = Math.min(maxW/plan.width, maxH/plan.height);
  const iw = plan.width*k, ih = plan.height*k;
  const ix = (PW - iw)/2, iy = (PH - 20 - ih)/2;
  const title = ((project.shootName ? project.shootName + ' \u2014 ' : '') + board.name)
    .replace(/[()\\]/g, '');
  const content = 'q ' + iw.toFixed(2) + ' 0 0 ' + ih.toFixed(2) + ' ' + ix.toFixed(2) + ' ' + iy.toFixed(2) +
    ' cm /Im1 Do Q\nBT /F1 13 Tf ' + M + ' ' + (PH - M + 6) + ' Td (' + title + ') Tj ET';
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW + ' ' + PH + '] ' +
      '/Resources << /XObject << /Im1 5 0 R >> /Font << /F1 6 0 R >> >> /Contents 4 0 R >>',
    '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream',
    '<< /Type /XObject /Subtype /Image /Width ' + plan.width + ' /Height ' + plan.height +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpeg.length +
      ' >>\nstream\n' + jpeg + '\nendstream',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objs.forEach((o, i)=>{
    offsets.push(pdf.length);
    pdf += (i+1) + ' 0 obj\n' + o + '\nendobj\n';
  });
  const xref = pdf.length;
  pdf += 'xref\n0 ' + (objs.length+1) + '\n0000000000 65535 f \n';
  for(let i=1;i<=objs.length;i++) pdf += String(offsets[i]).padStart(10,'0') + ' 00000 n \n';
  pdf += 'trailer\n<< /Size ' + (objs.length+1) + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF';
  const bytes = new Uint8Array(pdf.length);
  for(let i=0;i<pdf.length;i++) bytes[i] = pdf.charCodeAt(i) & 0xFF;
  const a = document.createElement('a');
  a.download = (board.name.replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_') || 'board') + '.pdf';
  a.href = URL.createObjectURL(new Blob([bytes], {type:'application/pdf'}));
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 5000);
}

// ---------------------------------------------------------------- paste images onto boards
// Copy a still anywhere (ShotDeck, Frameset, a browser tab) and Cmd/Ctrl+V it in.
document.addEventListener('paste', async e=>{
  if(activeTab === 'script' || activeTab === 'story') return;
  const tag = document.activeElement && document.activeElement.tagName;
  if(tag === 'INPUT' || tag === 'TEXTAREA') return;
  const items = [...(e.clipboardData && e.clipboardData.items || [])]
    .filter(i=>i.type.startsWith('image/'));
  if(!items.length) return;
  e.preventDefault();
  const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
  let off = 0;
  for(const it of items){
    const file = it.getAsFile();
    if(!file) continue;
    try{
      await addBoardImage(file, c.x + off, c.y + off);
      off += 34;
    }catch(err){ toast('Could not store that image — try a smaller one'); }
  }
  if(off) toast('Pasted onto the board');
});


// ---------------------------------------------------------------- .floorproj export / import
// One JSON file = the whole production, images and files included. Backup +
// "send a frozen copy" — the cheap rung of the sharing ladder.
function collectAssetIds(){
  const img = new Set(), file = new Set();
  const scanObjs = objs=>(objs||[]).forEach(ob=>{
    if(ob.imgId) img.add(ob.imgId);
    if(ob.fileId) file.add(ob.fileId);
    if(ob.videoId) file.add(ob.videoId);
    if(ob.cat === 'avscript') // AV rows carry their own stills
      (ob.rows||[]).forEach(r=>{
        if(r.imgId) img.add(r.imgId);
        (r.imgs||[]).forEach(id=>img.add(id));
      });
    if(ob.cat === 'subboard' && ob.board){ // boards within boards count too
      scanObjs(ob.board.objects);
      (ob.board.stills||[]).forEach(id=>img.add(id));
    }
  });
  const scan = s=>{
    if(!s) return;
    scanObjs(s.objects);
    (s.setups||[]).forEach(su=>scanObjs(su.objects)); // inactive setups count too
    (s.stills||[]).forEach(id=>img.add(id));
  };
  project.scenes.forEach(scan);
  scan(project.moodboard); scan(project.prodboard); scan(project.scriptboard); scan(project.shotboard);
  if(project.production && project.production.logo) img.add(project.production.logo);
  return {img:[...img], file:[...file]};
}
async function collectAssets(){
  const ids = collectAssetIds();
  const assets = {img:{}, file:{}};
  for(const id of ids.img){
    const r = await window.storage.get('sd:img:' + id).catch(()=>null);
    if(r && r.value) assets.img[id] = r.value;
  }
  for(const id of ids.file){
    const r = await window.storage.get('sd:file:' + id).catch(()=>null);
    if(r && r.value) assets.file[id] = r.value;
  }
  return assets;
}
async function exportFloorproj(){
  toast('Packing production…');
  try{
    await saveProject();
    const assets = await collectAssets();
    const pack = {floorproj:1, exported:new Date().toISOString(),
      name:project.shootName || 'production', project, assets};
    const blob = new Blob([JSON.stringify(pack)], {type:'application/json'});
    // one download path for the whole app (08-native.js turns this into the iOS
    // share sheet inside the iPad build)
    dlBlob((project.shootName || 'production').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_') + '.floorproj', blob);
    toast('Exported — images and files travel inside the file');
  }catch(e){
    console.error('floorproj export failed', e);
    toast('Export failed — see the console');
  }
}
async function importFloorproj(f){
  toast('Reading ' + f.name + '…');
  try{
    const pack = JSON.parse(await f.text());
    if(!pack.floorproj || !pack.project || !pack.project.scenes) throw new Error('not a floorproj');
    for(const [k,v] of Object.entries((pack.assets && pack.assets.img) || {}))
      await window.storage.set('sd:img:' + k, v);
    for(const [k,v] of Object.entries((pack.assets && pack.assets.file) || {}))
      await window.storage.set('sd:file:' + k, v);
    const id = uid();
    await window.storage.set('sd:project:' + id, JSON.stringify(pack.project));
    const idx = (await loadProjectIndex()) || [];
    idx.push({id, name:(pack.project.shootName || pack.name || 'Imported production'), updated:Date.now()});
    await saveProjectIndex(idx);
    await window.storage.set('sd:current', id);
    location.reload();
  }catch(e){
    console.error('floorproj import failed', e);
    toast('Could not import — is that a .floorproj file?');
  }
}

// merge another production INTO the current one: its scenes (fresh ids,
// active setup only), assets, its BOARD content (mood / script&storyboard /
// production — AV cards, sticky notes, storyboard rows, day headers, …,
// offset to the right of what's already there), and any people / locations /
// custom props we don't already have. Cross-references are remapped: sbrows
// and schedule rows point at the MERGED scenes, location cards and day
// headers at the merged locations, schedule/call-sheet day bindings at the
// merged day headers. Production info fields stay untouched.
async function mergeFloorproj(f){
  toast('Reading ' + f.name + '…');
  try{
    const pack = JSON.parse(await f.text());
    if(!pack.floorproj || !pack.project || !pack.project.scenes) throw new Error('not a floorproj');
    for(const [k,v] of Object.entries((pack.assets && pack.assets.img) || {}))
      await window.storage.set('sd:img:' + k, v);
    for(const [k,v] of Object.entries((pack.assets && pack.assets.file) || {}))
      await window.storage.set('sd:file:' + k, v);
    normalizeProduction();
    const sceneMap = {}, locMap = {};
    let nScenes = 0;
    for(const src of pack.project.scenes){
      const s = JSON.parse(JSON.stringify(src));
      migrateShot(s);
      sceneMap[src.id] = s.id = uid();
      s.setups = null; s.setupId = null; // the merge takes each scene's ACTIVE setup
      s.walls.forEach(w=>{ w.id = uid(); (w.openings||[]).forEach(op=>op.id = uid()); });
      const map = {};
      s.objects.forEach(ob=>{ const nid = uid(); map[ob.id] = nid; ob.id = nid; });
      s.objects.forEach(ob=>{
        if(ob.mount && map[ob.mount.id]) ob.mount.id = map[ob.mount.id];
        if(ob.rail && map[ob.rail.id]) ob.rail.id = map[ob.rail.id];
      });
      project.scenes.push(s);
      nScenes++;
    }
    const P = project.production, Q = (pack.project.production || {});
    let nPeople = 0, nLocs = 0;
    for(const p of (Q.people || [])){
      if(!p.name) continue;
      if(P.people.some(x=>x.name.toLowerCase() === p.name.toLowerCase() && x.tag === p.tag)) continue;
      P.people.push({...p, id:uid()});
      nPeople++;
    }
    for(const l of (Q.locations || [])){
      const nm = (l.name || l.street || '').toLowerCase();
      if(!nm) continue;
      const dupe = P.locations.find(x=>(x.name || x.street || '').toLowerCase() === nm);
      if(dupe){ locMap[l.id] = dupe.id; continue; }
      const nid = uid();
      locMap[l.id] = nid;
      P.locations.push({...l, id:nid});
      nLocs++;
    }
    for(const cp of (pack.project.customProps || [])){
      if(!(project.customProps || []).some(x=>x.name === cp.name))
        project.customProps.push({...cp, id:uid()});
    }
    // ---- board content: AV cards, notes, sbrows, day headers, cards, ink… ----
    const remapSceneKeys = m=>{
      const out = {};
      for(const k in m){
        const bar = k.indexOf('|');
        const sid = bar > -1 ? k.slice(0, bar) : k;
        out[(sceneMap[sid] || sid) + (bar > -1 ? k.slice(bar) : '')] = m[k];
      }
      return out;
    };
    const mergeBoard = (src, dst)=>{
      if(!src || (!(src.objects||[]).length && !(src.walls||[]).length)) return 0;
      // land the merged content to the RIGHT of what's already on the board
      let dx = 0;
      if((dst.objects||[]).length && (src.objects||[]).length){
        const maxX = Math.max(...dst.objects.map(o=>o.x + (o.w||0)/2));
        const minX = Math.min(...src.objects.map(o=>o.x - (o.w||0)/2));
        dx = Math.round(maxX + 260 - minX);
      }
      const idMap = {};
      const objs = JSON.parse(JSON.stringify(src.objects || []));
      objs.forEach(ob=>{ const nid = uid(); idMap[ob.id] = nid; ob.id = nid; });
      for(const ob of objs){
        ob.x += dx;
        if(ob.p1){ ob.p1.x += dx; } if(ob.p2){ ob.p2.x += dx; } if(ob.mid){ ob.mid.x += dx; }
        if(Array.isArray(ob.pts)) ob.pts.forEach(p=>{ p.x += dx; });          // ink / track
        if(Array.isArray(ob.path)) ob.path.forEach(p=>{ if(p.x != null) p.x += dx; });
        if(ob.mount && idMap[ob.mount.id]) ob.mount.id = idMap[ob.mount.id];
        if(ob.rail && idMap[ob.rail.id]) ob.rail.id = idMap[ob.rail.id];
        if(ob.sceneId) ob.sceneId = sceneMap[ob.sceneId] || ob.sceneId;       // storyboard rows
        if(ob.locId) ob.locId = locMap[ob.locId] || ob.locId;                 // location field cards
        if(Array.isArray(ob.locIds)) ob.locIds = ob.locIds.map(i=>locMap[i] || i); // day headers
        if(ob.dayId) ob.dayId = idMap[ob.dayId] || ob.dayId;                  // schedule / call-sheet day binding
        if(Array.isArray(ob.items))                                           // schedule rows
          ob.items.forEach(it=>{ if(it.sceneId) it.sceneId = sceneMap[it.sceneId] || it.sceneId; });
        if(ob.props && (ob.cat === 'proplist' || ob.cat === 'gearlist')){     // prop / gear lists
          const np = {};
          for(const k in ob.props) np[sceneMap[k] || k] = ob.props[k];
          ob.props = np;
          if(ob.hide) ob.hide = remapSceneKeys(ob.hide);
          if(ob.done) ob.done = remapSceneKeys(ob.done);
        }
        dst.objects.push(ob);
      }
      for(const w of JSON.parse(JSON.stringify(src.walls || []))){
        w.id = uid(); (w.openings||[]).forEach(op=>op.id = uid());
        w.x1 += dx; w.x2 += dx; if(w.mid) w.mid.x += dx;
        dst.walls.push(w);
      }
      return objs.length;
    };
    let nBoard = 0;
    if(pack.project.moodboard){ ensureMoodboard(); nBoard += mergeBoard(pack.project.moodboard, project.moodboard); }
    if(pack.project.scriptboard){ ensureScriptBoard(); nBoard += mergeBoard(pack.project.scriptboard, project.scriptboard); }
    if(pack.project.prodboard){ ensureProdBoard(); nBoard += mergeBoard(pack.project.prodboard, project.prodboard); }
    markDirty();
    buildShotList(); buildLibrary(); buildInfo(); render();
    toast('Merged ' + nScenes + ' scene' + (nScenes===1?'':'s') +
      (nBoard ? ', ' + nBoard + ' board item' + (nBoard===1?'':'s') : '') +
      (nPeople ? ', ' + nPeople + ' people' : '') +
      (nLocs ? ', ' + nLocs + ' location' + (nLocs===1?'':'s') : '') +
      ' from "' + (pack.project.shootName || pack.name || f.name) + '"');
  }catch(e){
    console.error('floorproj merge failed', e);
    toast('Could not merge — is that a .floorproj file?');
  }
}

// ---------------------------------------------------------------- AV script card: import + breakdown
// paste an AV script copied from Excel / Google Sheets (tab-separated
// columns) or any "VIDEO ⇥ AUDIO" text into the row-based AV card
function avPasteOverlay(o){
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;inset:0;z-index:210;background:rgba(40,38,32,.35);' +
    'display:flex;align-items:center;justify-content:center;font-family:-apple-system,Segoe UI,sans-serif;';
  el.innerHTML = `
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px 28px;
                width:520px;max-width:92vw;box-shadow:0 18px 60px rgba(40,38,32,.2)">
      <div style="font-weight:600;font-size:15px">Paste AV script rows</div>
      <div style="color:var(--ink2);font-size:12px;margin:6px 0 10px;line-height:1.5">
        Copy the rows from Excel / Google Sheets (or tab-separated text) and paste below.
        Columns: <b>VIDEO ⇥ AUDIO</b> — or start with a header row naming the columns,
        and an optional first column with a time like <b>0:30</b>.
      </div>
      <textarea id="avPasteTa" rows="10" spellcheck="false"
        style="width:100%;border:1px solid var(--line);border-radius:8px;padding:10px;
               font:12px ui-monospace,Menlo,monospace;box-sizing:border-box"></textarea>
      <label style="display:flex;gap:7px;align-items:center;font-size:12px;color:var(--body);margin-top:8px;cursor:pointer">
        <input id="avPasteSwap" type="checkbox"> First column is AUDIO (swap the two)
      </label>
      <div id="avPasteMsg" style="color:var(--ink2);font-size:12px;margin-top:8px;min-height:15px"></div>
      <div style="display:flex;gap:8px;margin-top:6px">
        <button id="avPasteGo" style="flex:1;background:var(--accent);color:var(--panel);border:none;border-radius:8px;
          padding:10px;font-size:13px;font-weight:600;cursor:pointer">Import rows</button>
        <button id="avPasteNo" style="flex:0 0 90px;background:var(--panel);border:1px solid var(--line);
          border-radius:8px;padding:10px;font-size:13px;cursor:pointer">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  el.querySelector('#avPasteNo').addEventListener('click', ()=>el.remove());
  el.addEventListener('pointerdown', e=>{ if(e.target === el) el.remove(); });
  el.querySelector('#avPasteTa').focus();
  el.querySelector('#avPasteGo').addEventListener('click', ()=>{
    const txt = el.querySelector('#avPasteTa').value;
    let lines = txt.split(/\r?\n/).map(l=>l.replace(/\s+$/,'')).filter(l=>l.trim());
    if(!lines.length){ el.querySelector('#avPasteMsg').textContent = 'Nothing to import yet.'; return; }
    const isTime = c => /^\d{1,2}[:.]\d{2}$/.test(c.trim()) || /^\d{1,3}\s?s?$/.test(c.trim());
    let vFirst = !el.querySelector('#avPasteSwap').checked;
    // header row names the columns? derive the order from it and skip it
    const head = lines[0].toLowerCase();
    if(/audio/.test(head) && /video|beeld/.test(head)){
      const cells0 = lines[0].toLowerCase().split('\t');
      const vi = cells0.findIndex(c=>/video|beeld/.test(c));
      const ai = cells0.findIndex(c=>/audio/.test(c));
      if(vi > -1 && ai > -1) vFirst = vi < ai;
      lines = lines.slice(1);
    }
    const made = [];
    for(const line of lines){
      let cells = line.includes('\t') ? line.split('\t') : line.split(/\s{2,}|\s\|\s/);
      cells = cells.map(c=>c.trim());
      let dur = '';
      if(cells.length > 1 && isTime(cells[0])) dur = cells.shift();
      const a = cells.length > 1 ? (vFirst ? cells[1] : cells[0]) : '';
      const v = cells.length > 1 ? (vFirst ? cells[0] : cells[1]) : cells[0] || '';
      if(!a && !v) continue;
      made.push({id:uid(), no:'', time:'', dur, audio:a, video:v, notes:'', imgId:null});
    }
    if(!made.length){ el.querySelector('#avPasteMsg').textContent = 'Could not find any rows in that.'; return; }
    // pristine starter rows get replaced; otherwise the import appends
    // NB: r.time is computed (always "0:00"+) — dur is the editable one
    const blank = r=>!((r.no||'')+(r.dur||'')+(r.audio||'')+(r.video||'')+(r.notes||'')).trim();
    if((o.rows||[]).every(blank)) o.rows = made;
    else o.rows = o.rows.concat(made);
    markDirty(); render(); refreshSelBar();
    el.remove();
    toast(made.length + ' AV row' + (made.length===1?'':'s') + ' imported');
  });
}

// break the AV card down into SCENES — every row (beat) becomes a scene board
// in the Shot designer, exactly like the film-script breakdown
function breakDownAvCard(o){
  // v0.58 — the breakdown keys on the SC (scene number) column and SYNCS with
  // the Shot designer: same number = same scene, re-running updates instead of
  // duplicating. Row stills join the scene's stills, notes travel as REGIE
  // lines, and no cards are dropped next to the AV script anymore.
  const rows = (o.rows||[]).filter(r=>(r.audio||'').trim() || (r.video||'').trim() ||
    (r.notes||'').trim() || (r.imgs||[]).length);
  if(!rows.length){ toast('No filled rows on this AV script yet'); return; }
  const durSec = r => avDurSec(r.dur !== undefined ? r.dur : r.time); // SEC column (pre-v0.60: time)
  // ---- which film is this? A production can hold several scripts; scenes
  // group under the card's label in the Shot designer, and numbering/matching
  // stays INSIDE the film — two films can both have a scene 1.
  let film = (o.label || '').trim();
  if(!film){
    const nFilms = new Set(project.scenes.map(s=>s.filmSrc).filter(Boolean)).size;
    const name = prompt('Film / script name for this breakdown (scenes group under it)',
      'Film ' + (nFilms + 1));
    if(name !== null && name.trim()){ film = name.trim(); o.label = film; }
  }
  // the film NAME is the identity: an AV table made from a script block (other
  // filmSrc, same name) must sync the same scenes, not duplicate them
  const mine = s => film ? (s.film === film || s.filmSrc === o.id) : s.filmSrc === o.id;
  const orphan = s => !s.filmSrc; // pre-film scenes: adoptable by number
  // ---- group rows by scene number: same SC = one scene, an empty SC row
  // continues the scene above it. Rows with no number at all get one WRITTEN
  // BACK into the card (and the SC column switched on) so the next breakdown
  // recognises them instead of minting extra scenes.
  const taken = new Set(project.scenes.filter(s=>mine(s) || orphan(s))
    .map(s=>String(s.scene||'').trim()).filter(Boolean));
  rows.forEach(r=>{ const n = String(r.no||'').trim(); if(n) taken.add(n); });
  let nextNo = 1, assigned = false;
  const freshNo = ()=>{
    while(taken.has(String(nextNo))) nextNo++;
    taken.add(String(nextNo));
    return String(nextNo);
  };
  const groups = [], byNo = {};
  let cur = null;
  for(const r of rows){
    let no = String(r.no||'').trim();
    if(!no && cur){ cur.rows.push(r); continue; } // continuation of the scene above
    if(!no){ no = freshNo(); r.no = no; assigned = true; }
    if(byNo[no]){ byNo[no].rows.push(r); cur = byNo[no]; continue; }
    cur = byNo[no] = {no, rows:[r]};
    groups.push(cur);
  }
  if(assigned){ o.cols = o.cols || {}; o.cols.no = true; }
  // ---- create or update the scenes
  const pristine = s => !s.objects.length && !s.walls.length && !s.stills.length &&
    !s.script && !s.scene && !s.sceneDesc && !(s.shots || []).length &&
    /^Scene \d+$/.test(s.name || '');
  let made = 0, updated = 0;
  groups.forEach(g=>{
    let sc = project.scenes.find(s=>mine(s) && String(s.scene||'').trim() === g.no)
          || project.scenes.find(s=>orphan(s) && String(s.scene||'').trim() === g.no);
    const isNew = !sc;
    if(isNew){
      // the untouched newborn "Scene 1" gets replaced instead of joined
      sc = (project.scenes.length === 1 && pristine(project.scenes[0]))
        ? project.scenes[0] : null;
      if(!sc){
        sc = newShot(project.scenes.length + 1);
        // new scenes land right after this film's last scene, not at the end
        let at = -1;
        project.scenes.forEach((s, i)=>{ if(mine(s)) at = i; });
        if(at >= 0) project.scenes.splice(at + 1, 0, sc); else project.scenes.push(sc);
      }
      sc.scene = g.no;
      sc.name = 'Sc ' + g.no;
    }
    sc.filmSrc = o.id;
    sc.film = film;
    const head = ((g.rows[0].video || g.rows[0].audio || '').split('\n')[0] || '').slice(0, 80);
    if(isNew || !sc.sceneDesc) sc.sceneDesc = head;
    sc.script = g.rows.map(r=>[
      r.video && 'VIDEO: ' + r.video,
      r.audio && 'AUDIO: ' + r.audio,
      r.notes && 'REGIE: ' + r.notes,
    ].filter(Boolean).join('\n')).join('\n\n');
    const secs = g.rows.reduce((a, r)=>a + durSec(r), 0);
    if(secs) sc.duration = Math.max(1, Math.ceil(secs/60));
    // references & stills from the rows join the scene's stills (no doubles)
    for(const r of g.rows) for(const id of (r.imgs||[]))
      if(!sc.stills.includes(id)) sc.stills.push(id);
    if(isNew) made++; else updated++;
  });
  // a scene that vanished from the script is NOT deleted — prepared boards,
  // shots and stills are precious. It gets marked "old" instead.
  let retired = 0;
  const liveNos = new Set(groups.map(g=>g.no));
  project.scenes.forEach(s=>{
    if(mine(s) && String(s.scene||'').trim() && !liveNos.has(String(s.scene||'').trim()) &&
       !/\bold$/i.test(s.name || '')){
      s.name = (s.name || ('Sc ' + s.scene)) + ' old';
      retired++;
    }
  });
  if(!project.activeSceneId && project.scenes.length) project.activeSceneId = project.scenes[0].id;
  markDirty();
  buildShotList(); buildInfo(); buildStills();
  render(); refreshSelBar();
  const bits = [];
  if(made) bits.push(made + ' new scene' + (made===1?'':'s'));
  if(updated) bits.push(updated + ' updated');
  if(retired) bits.push(retired + ' no longer in the script — kept as "old"');
  toast(bits.join(', ') + ' — see the Shot designer scene list');
}

// ---------------------------------------------------------------- trash can (drop to delete)
const trashEl = document.createElement('div');
trashEl.id = 'trashCan';
trashEl.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/></svg>';
document.body.appendChild(trashEl);
function overTrash(x, y){
  const r = trashEl.getBoundingClientRect();
  return x >= r.left - 12 && x <= r.right + 12 && y >= r.top - 12 && y <= r.bottom + 12;
}
document.addEventListener('pointermove', e=>{
  if(window.IS_TOUCH) return; // touch: delete via the selection bar only
  const dragging = drag && drag.kind === 'move' && drag.o && !drag.o.locked;
  trashEl.classList.toggle('show', !!dragging);
  if(dragging) trashEl.classList.toggle('hot', overTrash(e.clientX, e.clientY));
});
document.addEventListener('pointerup', e=>{
  if(!window.IS_TOUCH && drag && drag.kind === 'move' && drag.o && !drag.o.locked && overTrash(e.clientX, e.clientY)){
    const o = drag.o;
    const sc = activeScene();
    sc.objects = sc.objects.filter(x=>x.id !== o.id);
    sc.objects.forEach(c=>{
      if(c.mount && c.mount.id === o.id) c.mount = null;
      if(c.rail && c.rail.id === o.id){ c.rail = null; c.path = []; }
    });
    sel = null; drag = null;
    trashEl.classList.remove('show', 'hot');
    markDirty(); if(histPushed) histSettle();
    refreshSelBar(); render();
    toast('Deleted \u2014 Cmd/Ctrl+Z to undo');
    e.stopPropagation();
  } else {
    trashEl.classList.remove('show', 'hot');
  }
}, {capture:true});

// ---------------------------------------------------------------- productions: save / switch / new
async function flushSave(){ dirty = true; await saveProject(); }
async function openProjectPop(){
  const pop = document.getElementById('projPop');
  if(pop.classList.contains('show')){ pop.classList.remove('show'); return; }
  const idx = (await loadProjectIndex()) || [];
  idx.sort((a,b)=>(b.updated||0)-(a.updated||0));
  pop.innerHTML = '<div class="xp-title">This production</div>';
  const nameIn = document.createElement('input');
  nameIn.className = 'proj-name';
  nameIn.placeholder = 'Name this production\u2026';
  nameIn.value = project.shootName || '';
  nameIn.addEventListener('input', ()=>{
    project.shootName = nameIn.value;
    markDirty(); syncProjBtn();
    const el0 = document.getElementById('iShoot');
    if(el0) el0.value = nameIn.value;
  });
  nameIn.addEventListener('keydown', e=>{ if(e.key==='Enter') nameIn.blur(); e.stopPropagation(); });
  pop.appendChild(nameIn);
  const st = document.createElement('div');
  st.style.cssText = 'font-size:10px;color:var(--ink2);margin:4px 2px 10px;';
  st.textContent = 'Autosaves as you work \u2014 switch below at any time.';
  pop.appendChild(st);
  pop.insertAdjacentHTML('beforeend', '<div class="xp-title">All productions</div>');
  idx.forEach(p=>{
    const row = document.createElement('button');
    row.className = 'proj-row' + (p.id === currentProjectId ? ' on' : '');
    const isShared = p.shared || (window.FLOOR_SHARED && window.FLOOR_SHARED.has(p.id));
    row.textContent = (p.name || 'Untitled production') + (isShared ? '  ⇄' : '');
    if(isShared) row.title = 'Shared production — co-editors work on the same data';
    row.addEventListener('click', async ()=>{
      if(p.id === currentProjectId){ pop.classList.remove('show'); return; }
      await flushSave();
      await window.storage.set('sd:current', p.id);
      location.reload();
    });
    pop.appendChild(row);
  });
  // ---- .floorproj: backup / "send a frozen copy" ----
  const exRow = document.createElement('div');
  exRow.style.cssText = 'display:flex;gap:6px;margin-top:10px;';
  const exB = document.createElement('button');
  exB.className = 'btn'; exB.style.flex = '1';
  exB.textContent = 'Export .floorproj';
  exB.addEventListener('click', ()=>exportFloorproj());
  const imB = document.createElement('button');
  imB.className = 'btn'; imB.style.flex = '1';
  imB.textContent = 'Import…';
  imB.addEventListener('click', ()=>{
    const fi = document.createElement('input');
    fi.type = 'file'; fi.accept = '.floorproj,application/json';
    fi.addEventListener('change', ()=>{ if(fi.files && fi.files[0]) importFloorproj(fi.files[0]); });
    fi.click();
  });
  exRow.appendChild(exB); exRow.appendChild(imB);
  pop.appendChild(exRow);
  const mgB = document.createElement('button');
  mgB.className = 'btn';
  mgB.style.cssText = 'width:100%;margin-top:6px;';
  mgB.textContent = 'Merge .floorproj into current…';
  mgB.title = 'Append another production’s scenes, people and locations to THIS one';
  mgB.addEventListener('click', ()=>{
    pop.classList.remove('show');
    const fi = document.createElement('input');
    fi.type = 'file'; fi.accept = '.floorproj,application/json';
    fi.addEventListener('change', ()=>{ if(fi.files && fi.files[0]) mergeFloorproj(fi.files[0]); });
    fi.click();
  });
  pop.appendChild(mgB);

  const nw = document.createElement('button');
  nw.className = 'btn primary';
  nw.style.cssText = 'width:100%;margin-top:8px;';
  nw.textContent = '+ New production';
  nw.addEventListener('click', async ()=>{
    // hosted free plan: one cloud production (billing off = unlimited)
    if(window.FLOOR_BILLING && window.FLOOR_BILLING.enabled && idx.length >= 1 &&
       !window.FLOOR_BILLING.gate('productions')) return;
    pop.classList.remove('show');
    newProductionOverlay(); // name + template (or the example production) — 14-templates.js
  });
  pop.appendChild(nw);
  if(idx.length > 1){
    const del = document.createElement('button');
    del.className = 'btn';
    del.style.cssText = 'width:100%;margin-top:6px;color:var(--danger);';
    const curShared = window.FLOOR_SHARED && window.FLOOR_SHARED.has(currentProjectId);
    const curRole = curShared ? window.FLOOR_SHARED.get(currentProjectId).role : null;
    del.textContent = curShared && curRole !== 'owner'
      ? 'Leave this shared production\u2026'
      : 'Delete current production\u2026';
    del.addEventListener('click', async ()=>{
      if(curShared && curRole !== 'owner'){
        // editor: leave \u2014 the production keeps existing for everyone else
        if(!confirm('Leave "' + (project.shootName || 'this production') + '"? You can rejoin with a new invite.')) return;
        await window.FLOOR_SB.from('production_members').delete()
          .eq('production_id', currentProjectId).eq('user_id', window.FLOOR_USER.id);
      } else {
        const warn = curShared
          ? 'Delete "' + (project.shootName || 'Untitled production') + '" permanently FOR ALL CO-EDITORS? This cannot be undone.'
          : 'Delete "' + (project.shootName || 'Untitled production') + '" permanently? This cannot be undone.';
        if(!confirm(warn)) return;
        if(curShared) await window.FLOOR_SB.from('productions').delete().eq('id', currentProjectId);
        await window.storage.delete('sd:project:' + currentProjectId).catch(()=>{});
      }
      const idx2 = ((await loadProjectIndex()) || []).filter(p=>p.id !== currentProjectId);
      await saveProjectIndex(idx2);
      await window.storage.set('sd:current', idx2[0].id);
      location.reload();
    });
    pop.appendChild(del);
  }
  // account & privacy moved to the top-right account icon (v0.52)
  pop.classList.add('show');
}
document.getElementById('projBtn').addEventListener('click', openProjectPop);
document.addEventListener('pointerdown', e=>{
  const pop = document.getElementById('projPop');
  if(pop.classList.contains('show') && !pop.contains(e.target) &&
     e.target.id !== 'projBtn' && !document.getElementById('projBtn').contains(e.target)){
    pop.classList.remove('show');
  }
});
function syncProjBtn(){
  const b = document.getElementById('projBtn');
  if(b && project) b.textContent = (project.shootName || 'Untitled production') + ' \u25be';
}
setInterval(syncProjBtn, 1500);
setTimeout(syncProjBtn, 400);

// ---------------------------------------------------------------- Load script (LITE mode)
// The Shot-designer-only build has no Script tab, so scripts come in through
// this sheet: paste text, or pick a .txt / .fountain / .pdf. Scene headings
// (INT./EXT.) become scenes via the classic breakdown; the film name groups them.
function loadScriptOverlay(){
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;inset:0;z-index:210;background:rgba(40,38,32,.35);' +
    'display:flex;align-items:center;justify-content:center;font-family:-apple-system,Segoe UI,sans-serif;';
  el.innerHTML = `
    <div style="background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px 28px;
                width:560px;max-width:94vw;max-height:90vh;overflow:auto;box-shadow:0 18px 60px rgba(40,38,32,.2)">
      <div style="font-weight:600;font-size:15px">Load a script</div>
      <div style="color:var(--ink2);font-size:12px;margin:6px 0 10px;line-height:1.5">
        Every scene heading (<b>INT. KITCHEN — DAY</b>, <b>EXT. …</b>) becomes a scene in the list on
        the left, with its text in Scene info. Paste below, or pick a file.
      </div>
      <input id="lsName" placeholder="Film / script name (groups the scenes)"
        style="width:100%;border:1px solid var(--line);border-radius:8px;padding:9px 11px;font-size:13px;box-sizing:border-box;margin-bottom:8px">
      <textarea id="lsText" rows="10" spellcheck="false" placeholder="INT. KITCHEN — DAY&#10;&#10;Anna is cooking…"
        style="width:100%;border:1px solid var(--line);border-radius:8px;padding:10px;
               font:12.5px ui-monospace,Menlo,monospace;box-sizing:border-box"></textarea>
      <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap">
        <button id="lsFile" style="background:var(--panel);border:1px solid var(--line);border-radius:8px;
          padding:9px 12px;font-size:12.5px;cursor:pointer">Choose file… (.txt / .fountain / .pdf)</button>
        <span id="lsMsg" style="color:var(--ink2);font-size:12px"></span>
      </div>
      <div style="display:flex;gap:8px;margin-top:12px">
        <button id="lsGo" style="flex:1;background:var(--accent);color:var(--panel);border:none;border-radius:8px;
          padding:11px;font-size:13px;font-weight:600;cursor:pointer">Make scenes</button>
        <button id="lsNo" style="flex:0 0 90px;background:var(--panel);border:1px solid var(--line);
          border-radius:8px;padding:11px;font-size:13px;cursor:pointer">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  const msg = el.querySelector('#lsMsg');
  const ta = el.querySelector('#lsText');
  const nameIn = el.querySelector('#lsName');
  el.querySelector('#lsNo').addEventListener('click', ()=>el.remove());
  el.addEventListener('pointerdown', e=>{ if(e.target === el) el.remove(); });
  ta.addEventListener('keydown', e=>e.stopPropagation());
  nameIn.addEventListener('keydown', e=>e.stopPropagation());
  el.querySelector('#lsFile').addEventListener('click', ()=>{
    const fi = document.createElement('input');
    fi.type = 'file'; fi.accept = '.txt,.fountain,.fdx,.pdf,text/plain,application/pdf';
    fi.addEventListener('change', async ()=>{
      const f = fi.files && fi.files[0]; if(!f) return;
      msg.textContent = 'Reading ' + f.name + '…';
      try{
        const text = /\.pdf$/i.test(f.name) ? await extractPdfText(f) : await f.text();
        ta.value = text || '';
        if(!nameIn.value) nameIn.value = f.name.replace(/\.[^.]+$/, '');
        msg.textContent = text ? (text.split('\n').length + ' lines loaded') : 'No text found in that file';
      }catch(e){ msg.textContent = 'Could not read that file: ' + (e.message || e); }
    });
    fi.click();
  });
  el.querySelector('#lsGo').addEventListener('click', ()=>{
    const parsed = parseScreenplay(ta.value || '');
    if(!parsed.length){
      msg.textContent = 'No scene headings found — lines like INT. KITCHEN — DAY start a scene.';
      return;
    }
    const scenes = createScenesFromBreakdown(parsed);
    const film = nameIn.value.trim();
    if(film) scenes.forEach(sc=>{ sc.film = film; sc.filmSrc = 'script:' + film; });
    markDirty(); buildShotList(); buildInfo();
    if(scenes[0]) switchShot(scenes[0].id);
    el.remove();
    toast(scenes.length + ' scene' + (scenes.length === 1 ? '' : 's') + ' ready — pick one on the left and start designing');
  });
  ta.focus();
}
