// FLOOR — 06-tabs.js
// The app shell: Moodboard · Script · Storyboard · Shot designer · Production.
// Moodboard reuses the whole canvas engine on a project-level board.

// ---------------------------------------------------------------- tab switching
function switchTab(t){
  if(activeTab === t) return;
  closeNoteEditor(true);
  togglePlay(false);
  sel = null; drag = null;
  activeTab = t;
  document.body.className = document.body.className.replace(/\btab-\w+\b/g, '').trim();
  document.body.classList.add('tab-' + t);
  document.querySelectorAll('#tabbar button').forEach(b =>
    b.classList.toggle('on', b.dataset.tab === t));
  if(t === 'mood'){
    ensureMoodboard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  } else if(t === 'write'){
    ensureScriptBoard();
    buildLibrary();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  } else if(t === 'design'){
    buildLibrary(); buildShotList(); buildInfo(); buildStills();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(render);
  } else if(t === 'org'){
    ensureProdBoard();
    buildLibrary();
    buildOrgPanel();
    refreshSelBar();
    ensureShotImages(activeScene(), false).then(()=>{ zoomFitIfEmptyView(); render(); });
  }
  render();
}
let _fitOnceDone = {};
function zoomFitIfEmptyView(){
  if(_fitOnceDone[activeTab]) return;
  _fitOnceDone[activeTab] = true;
  zoomFit();
}
document.querySelectorAll('#tabbar button').forEach(b =>
  b.addEventListener('click', ()=>switchTab(b.dataset.tab)));

// ---------------------------------------------------------------- moodboard
function ensureMoodboard(){
  if(!project.moodboard){
    const m = newShot(0);
    m.name = 'Moodboard';
    project.moodboard = m;
    markDirty();
  }
  migrateShot(project.moodboard);
}
function ensureScriptBoard(){
  if(!project.scriptboard){
    const b = newShot(0);
    b.name = 'Script & storyboard';
    project.scriptboard = b;
    // starter layout: one film script block, ready to type into
    b.objects.push({id:uid(), cat:'script', kind:'script', x:-260, y:0, rot:0,
      w:430, h:300, mode:'film', text:'', textR:'', fontSize:12.5,
      color:'#5B6472', label:'', path:[]});
    project.scriptboard = b;
    markDirty();
  }
  migrateShot(project.scriptboard);
}
// library section for the Script & Storyboard board
function buildWriteLibSection(lib){
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Script & storyboard';
  lib.appendChild(h);
  const grid = document.createElement('div');
  grid.className = 'lib-grid';
  const tile = (name, drawFn, spec)=>{
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas(drawFn, 100, 100, '#5B6472'));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(name) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, spec));
    grid.appendChild(el);
  };
  tile('Film script', (tc,w2,h2,c2)=>{
    tc.strokeStyle=c2; tc.lineWidth=2.5;
    tc.strokeRect(-w2*.34,-h2*.4,w2*.68,h2*.8);
    tc.globalAlpha=.6;
    for(let i=0;i<5;i++){ tc.beginPath(); tc.moveTo(-w2*.24,-h2*.26+i*h2*.13); tc.lineTo(w2*.24,-h2*.26+i*h2*.13); tc.stroke(); }
    tc.globalAlpha=1;
  }, {cat:'script', kind:'script', mode:'film'});
  tile('AV script', (tc,w2,h2,c2)=>{
    tc.strokeStyle=c2; tc.lineWidth=2.5;
    tc.strokeRect(-w2*.38,-h2*.4,w2*.76,h2*.8);
    tc.beginPath(); tc.moveTo(0,-h2*.4); tc.lineTo(0,h2*.4); tc.stroke();
    tc.globalAlpha=.6;
    for(let i=0;i<4;i++){
      tc.beginPath(); tc.moveTo(-w2*.3,-h2*.24+i*h2*.14); tc.lineTo(-w2*.08,-h2*.24+i*h2*.14);
      tc.moveTo(w2*.08,-h2*.24+i*h2*.14); tc.lineTo(w2*.3,-h2*.24+i*h2*.14); tc.stroke();
    }
    tc.globalAlpha=1;
  }, {cat:'script', kind:'script', mode:'av'});
  tile('Storyboard row', (tc,w2,h2,c2)=>{
    tc.strokeStyle=c2; tc.lineWidth=2.5;
    tc.strokeRect(-w2*.42,-h2*.18,w2*.84,h2*.36);
    tc.beginPath();
    tc.moveTo(-w2*.16,-h2*.18); tc.lineTo(-w2*.16,h2*.18);
    tc.moveTo(w2*.1,-h2*.18); tc.lineTo(w2*.1,h2*.18);
    tc.stroke();
    tc.globalAlpha=.5; tc.fillStyle=c2;
    tc.fillRect(-w2*.13,-h2*.12,w2*.2,h2*.24);
    tc.globalAlpha=1;
  }, {cat:'sbrow', kind:'sbrow'});
  lib.appendChild(grid);
  const tip = document.createElement('div');
  tip.style.cssText = 'font-size:10px;color:var(--ink2);padding:4px 14px 8px;line-height:1.5;';
  tip.textContent = 'Write in a script block, then select it and hit "Break down" — FLOOR creates a storyboard row and a scene board per detected scene, with every camera on that board mapping to a shot.';
  lib.appendChild(tip);
}
function ensureProdBoard(){
  if(!project.prodboard){
    const b = newShot(0);
    b.name = 'Production board';
    project.prodboard = b;
    markDirty();
  }
  migrateShot(project.prodboard);
}

// ---- production card library (templated notes — drag onto the board) ----
const PROD_CARDS = [
  ['Call sheet', '#4B6BFB', 280, 360, 'CALL SHEET',
   'Production: \nDate: \nCrew call: \nOn set: \nLunch: \nWrap: \n\nLocation: \nAddress: \nParking: \nNearest hospital: \n\nWeather: \nSunrise / sunset: \n\nNotes: '],
  ['Day schedule', '#E8934C', 250, 300, 'SCHEDULE',
   '07:00  Crew call\n07:30  Build & light\n09:00  Shot 1\n11:00  Shot 2\n13:00  Lunch\n14:00  Shot 3\n17:30  Last looks\n18:00  Wrap'],
  ['Contact card', '#5B6472', 230, 170, 'CONTACT',
   'Role: \nName: \nPhone: \nEmail: \nCall time: '],
  ['Location card', '#3E9B6E', 250, 250, 'LOCATION',
   'Name: \nAddress: \nParking: \nPower: \nToilets: \nAccess / keys: \nNotes: '],
  ['Checklist', '#8B5CF6', 230, 260, 'CHECKLIST',
   '\u2610 Camera batteries\n\u2610 Media cards\n\u2610 Release forms\n\u2610 Catering confirmed\n\u2610 Parking arranged\n\u2610 Backup drive'],
];
function buildProdLibSection(lib){
  const h = document.createElement('div');
  h.className = 'side-head';
  h.style.marginTop = '10px';
  h.textContent = 'Production cards';
  lib.appendChild(h);
  const grid = document.createElement('div');
  grid.className = 'lib-grid';
  for(const [name, color, w, hh, label, text] of PROD_CARDS){
    const el = document.createElement('div');
    el.className = 'lib-item';
    el.appendChild(tileCanvas((tc,w2,h2)=>{
      drawNoteShape(tc, {w:w2, h:h2, color, text:''}, true);
      tc.fillStyle = color;
      tc.fillRect(-w2*.32, -h2*.3, w2*.64, 4);
      tc.globalAlpha = .5;
      for(const y2 of [-h2*.08, h2*.1, h2*.28]) tc.fillRect(-w2*.32, y2, w2*.64, 2.5);
      tc.globalAlpha = 1;
    }, 100, 100, color));
    el.insertAdjacentHTML('beforeend', '<span>' + esc(name) + '</span>');
    el.addEventListener('pointerdown', e => startLibDrag(e, {cat:'note', kind:'note', color,
      props:{label, text, w, h:hh, color}}));
    grid.appendChild(el);
  }
  // live weather card (Open-Meteo: free GFS/ICON model data, no key)
  const wEl = document.createElement('div');
  wEl.className = 'lib-item';
  wEl.appendChild(tileCanvas((tc,w2,h2)=>{
    tc.strokeStyle='#4CA6E8'; tc.lineWidth=3; tc.fillStyle='#4CA6E8';
    tc.beginPath(); tc.arc(-w2*.1,-h2*.14,h2*.16,0,7); tc.stroke();
    tc.beginPath();
    tc.moveTo(-w2*.3,h2*.12); tc.quadraticCurveTo(-w2*.34,-h2*.06,-w2*.12,0);
    tc.quadraticCurveTo(0,-h2*.2,w2*.14,0);
    tc.quadraticCurveTo(w2*.36,-h2*.02,w2*.28,h2*.12);
    tc.closePath(); tc.globalAlpha=.35; tc.fill(); tc.globalAlpha=1; tc.stroke();
  }, 100, 100, '#4CA6E8'));
  wEl.insertAdjacentHTML('beforeend', '<span>Weather (live)</span>');
  wEl.addEventListener('pointerdown', e => startLibDrag(e, {cat:'weather', kind:'weather', color:'#4CA6E8'}));
  grid.appendChild(wEl);
  lib.appendChild(grid);
  const tip = document.createElement('div');
  tip.style.cssText = 'font-size:10px;color:var(--ink2);padding:4px 14px 10px;line-height:1.5;';
  tip.textContent = 'Tip: drop a map screenshot, location photo or Cmd+V paste straight onto the board. The weather card fetches a real forecast for its place + date.';
  lib.appendChild(tip);
}

// ---------------------------------------------------------------- live weather (Open-Meteo, GFS-backed, free)
const WMO = {0:'Clear',1:'Mostly clear',2:'Partly cloudy',3:'Overcast',45:'Fog',48:'Rime fog',
  51:'Light drizzle',53:'Drizzle',55:'Heavy drizzle',61:'Light rain',63:'Rain',65:'Heavy rain',
  66:'Freezing rain',71:'Light snow',73:'Snow',75:'Heavy snow',77:'Snow grains',
  80:'Light showers',81:'Showers',82:'Heavy showers',85:'Snow showers',86:'Snow showers',
  95:'Thunderstorm',96:'Thunderstorm + hail',99:'Severe thunderstorm'};
async function fetchWeatherFor(o){
  if(!o.place || !o.date){ toast('Set a place and a date first'); return; }
  const days = Math.round((new Date(o.date) - new Date().setHours(0,0,0,0)) / 86400000);
  if(days < 0){ toast('That date is in the past'); return; }
  if(days > 15){ toast('Forecasts reach ~16 days ahead \u2014 fetch again closer to the date'); return; }
  toast('Fetching forecast\u2026');
  try{
    const g = await (await fetch('https://geocoding-api.open-meteo.com/v1/search?count=1&language=nl&name=' +
      encodeURIComponent(o.place))).json();
    const hit = g.results && g.results[0];
    if(!hit){ toast('Place not found \u2014 try a bigger town nearby'); return; }
    const q = 'https://api.open-meteo.com/v1/forecast?latitude=' + hit.latitude +
      '&longitude=' + hit.longitude +
      '&daily=weather_code,temperature_2m_min,temperature_2m_max,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset' +
      '&timezone=auto&start_date=' + o.date + '&end_date=' + o.date;
    const w = await (await fetch(q)).json();
    const d = w.daily;
    if(!d || !d.time || !d.time.length){ toast('No forecast returned for that date'); return; }
    const hhmm = t => (t||'').split('T')[1] || '';
    o.place = hit.name + (hit.admin1 ? ', ' + hit.admin1 : '');
    o.data = [
      ['Forecast', WMO[d.weather_code[0]] || ('code ' + d.weather_code[0])],
      ['Temp', Math.round(d.temperature_2m_min[0]) + '\u2013' + Math.round(d.temperature_2m_max[0]) + ' \u00b0C'],
      ['Rain chance', (d.precipitation_probability_max[0] ?? '\u2014') + ' %'],
      ['Wind', Math.round(d.wind_speed_10m_max[0]) + ' km/h'],
      ['Sun', hhmm(d.sunrise[0]) + ' \u2192 ' + hhmm(d.sunset[0])],
    ];
    markDirty(); render(); refreshSelBar();
    toast('Forecast loaded');
  }catch(e){
    console.warn('weather fetch failed', e);
    toast('Could not reach the weather service');
  }
}

// ---------------------------------------------------------------- pdf.js (lazy, self-hosted)
let _pdfjsReady = null;
function loadPdfJs(){
  if(window.pdfjsLib) return Promise.resolve();
  if(_pdfjsReady) return _pdfjsReady;
  _pdfjsReady = new Promise((ok, bad)=>{
    const sc = document.createElement('script');
    sc.src = './js/vendor/pdf.min.js';
    sc.onload = ()=>{
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = './js/vendor/pdf.worker.min.js';
      ok();
    };
    sc.onerror = ()=>bad(new Error('pdf.js failed to load'));
    document.head.appendChild(sc);
  });
  return _pdfjsReady;
}
async function extractPdfText(file){
  await loadPdfJs();
  const buf = await file.arrayBuffer();
  const doc = await window.pdfjsLib.getDocument({data:buf}).promise;
  const out = [];
  for(let p=1; p<=doc.numPages; p++){
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    let lastY = null, line = [];
    for(const it of tc.items){
      const y = Math.round(it.transform[5]);
      if(lastY !== null && Math.abs(y - lastY) > 3){
        out.push(line.join(''));
        line = [];
      }
      line.push(it.str);
      lastY = y;
    }
    out.push(line.join(''));
    out.push('');
  }
  return out.join('\n');
}
async function pdfFirstPageThumb(file){
  await loadPdfJs();
  const buf = await file.arrayBuffer();
  const doc = await window.pdfjsLib.getDocument({data:buf}).promise;
  const page = await doc.getPage(1);
  const vp0 = page.getViewport({scale:1});
  const scale = 420 / vp0.width;
  const vp = page.getViewport({scale});
  const c = document.createElement('canvas');
  c.width = Math.round(vp.width); c.height = Math.round(vp.height);
  await page.render({canvasContext:c.getContext('2d'), viewport:vp}).promise;
  return c.toDataURL('image/jpeg', .8);
}

// import a script file straight into a script block (.txt / .fountain / .fdx / .pdf)
function importIntoScriptBlock(o){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = '.txt,.fountain,.fdx,.pdf';
  fi.addEventListener('change', async ()=>{
    const file = fi.files && fi.files[0];
    if(!file) return;
    let text;
    try{
      if(file.name.toLowerCase().endsWith('.pdf')){
        toast('Reading PDF\u2026');
        text = await extractPdfText(file);
      } else {
        text = await file.text();
        if(file.name.toLowerCase().endsWith('.fdx')){
          const doc = new DOMParser().parseFromString(text, 'text/xml');
          text = [...doc.querySelectorAll('Paragraph')].map(p=>{
            const t = [...p.querySelectorAll('Text')].map(x=>x.textContent).join('');
            return (p.getAttribute('Type') === 'Scene Heading') ? t.toUpperCase() : t;
          }).join('\n');
        }
      }
    }catch(e){
      console.warn('script import failed', e);
      toast('Could not read that file');
      return;
    }
    o.text = text;
    markDirty(); render();
    toast('Script imported \u2014 hit "Break down" when ready');
  });
  fi.click();
}

// ---------------------------------------------------------------- audio on boards
let audioEl = null, audioPlayingId = null;
async function toggleAudio(o){
  if(audioPlayingId === o.id){
    if(audioEl) audioEl.pause();
    audioPlayingId = null;
    render();
    return;
  }
  try{
    const r = await window.storage.get('sd:file:' + o.fileId);
    if(!r || !r.value){ toast('Audio data not found'); return; }
    if(!audioEl){
      audioEl = new Audio();
      audioEl.addEventListener('ended', ()=>{ audioPlayingId = null; render(); });
    }
    audioEl.src = r.value;
    await audioEl.play();
    audioPlayingId = o.id;
    render();
  }catch(e){
    console.warn('audio play failed', e);
    toast('Could not play that file');
  }
}
async function addBoardAudioAt(file, x, y){
  if(file.size > 8*1024*1024){ toast('Audio up to ~8 MB \u2014 this one is too large'); return; }
  try{
    const dataURL = await new Promise((ok, bad)=>{
      const r = new FileReader();
      r.onload = ()=>ok(r.result); r.onerror = ()=>bad(r.error);
      r.readAsDataURL(file);
    });
    const id = uid();
    await window.storage.set('sd:file:' + id, dataURL);
    activeScene().objects.push({id:uid(), cat:'audio', kind:'audio',
      x, y, rot:0, w:280, h:60,
      fileId:id, name:file.name, size:file.size,
      color:'#8B5CF6', label:'', path:[]});
    markDirty(); render();
    toast('Audio added \u2014 tap \u25b8 to play');
  }catch(e){ toast('Could not store that audio file'); }
}
function pickBoardAudio(){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = 'audio/*,.mp3,.aac,.m4a,.wav,.ogg,.flac';
  fi.addEventListener('change', ()=>{
    if(!fi.files || !fi.files[0]) return;
    const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
    addBoardAudioAt(fi.files[0], c.x, c.y);
  });
  fi.click();
}

// --- rule-based screenplay parsing (the AI pass lands in Phase 1) ---
const SCENE_HEADING_RE = /^\s*(?:\d+[.\s]+)?(INT\.?\/EXT\.?|EXT\.?\/INT\.?|I\/E\.?|INT\.?|EXT\.?)\s+(.+?)\s*$/i;
const TRANSITION_RE = /^(CUT TO|FADE (IN|OUT|TO)|DISSOLVE TO|SMASH CUT|MATCH CUT|CONTINUED)\b/i;
function parseScreenplay(text){
  const lines = text.split(/\r?\n/);
  const scenes = [];
  let cur = null;
  for(let i=0;i<lines.length;i++){
    const line = lines[i];
    const m = line.match(SCENE_HEADING_RE);
    if(m){
      if(cur) scenes.push(cur);
      const dn = (line.match(/\b(DAY|NIGHT|DAWN|DUSK|MORNING|EVENING|AFTERNOON)\b/i)||[])[1] || '';
      cur = {heading: line.trim(), intExt: m[1].toUpperCase().replace(/\.+$/,''),
             dayNight: dn.toUpperCase(), body: [], characters: new Set()};
      continue;
    }
    if(!cur) continue;
    cur.body.push(line);
    // character cue: an UPPERCASE line, not a transition, followed by dialogue
    const t = line.trim().replace(/\s*\((?:V\.?O\.?|O\.?S\.?|CONT'?D|O\.?C\.?)\.?\)\s*$/i,'');
    if(t && t === t.toUpperCase() && /^[A-Z][A-Z0-9 .'\-]{0,29}$/.test(t) &&
       !TRANSITION_RE.test(t) && !SCENE_HEADING_RE.test(t)){
      const next = (lines[i+1]||'').trim();
      if(next && !SCENE_HEADING_RE.test(next) && next !== next.toUpperCase()){
        cur.characters.add(t);
      }
    }
  }
  if(cur) scenes.push(cur);
  return scenes.map(s=>({...s, characters:[...s.characters], body:s.body.join('\n').trim()}));
}
function parseAV(text){
  // v1: each blank-line-separated paragraph becomes a scene
  return text.split(/\n\s*\n/).map(p=>p.trim()).filter(Boolean).map((p,i)=>({
    heading: 'Scene ' + (i+1) + ' — ' + p.split('\n')[0].slice(0,60),
    intExt:'', dayNight:'', body:p, characters:[],
  }));
}
function createScenesFromBreakdown(parsed){
  const made = [];
  const startN = project.scenes.length;
  parsed.forEach((s, i)=>{
    const sc = newShot(startN + i + 1);
    sc.name = 'Sc ' + (startN + i + 1);
    sc.scene = String(startN + i + 1);
    sc.sceneDesc = s.heading.replace(SCENE_HEADING_RE, (m0,p1,p2)=>p1 + ' ' + p2) || s.heading;
    sc.script = s.body;
    // place detected cast as actor icons, fanned out in the middle
    s.characters.slice(0, 8).forEach((name, ci)=>{
      sc.objects.push({id:uid(), cat:'actor', kind: ci===0 ? 'actor' : 'actor_ant',
        x: -140 + (ci%4)*95, y: -60 + Math.floor(ci/4)*110, rot: 0,
        w:34, h:34, color: COLORS[ci % COLORS.length], label: name, path:[]});
    });
    project.scenes.push(sc);
    made.push(sc);
  });
  if(!project.activeSceneId && project.scenes.length) project.activeSceneId = project.scenes[0].id;
  markDirty();
  buildShotList(); buildInfo();
  return made;
}

// breakdown from a script block ON the canvas: scenes + a storyboard column
function breakDownScriptBlock(o){
  const parsed = o.mode === 'av'
    ? parseAV(o.text || '')
    : parseScreenplay(o.text || '');
  if(!parsed.length){
    toast(o.mode === 'av'
      ? 'No scenes found — AV blocks split on blank lines in the VIDEO column'
      : 'No scenes found — use headings like INT. KITCHEN \u2014 DAY');
    return;
  }
  const scenes = createScenesFromBreakdown(parsed);
  const board = activeScene();
  const x0 = o.x + o.w/2 + 340;
  let y = o.y - o.h/2 + 60;
  scenes.forEach((sc, i)=>{
    board.objects.push({id:uid(), cat:'sbrow', kind:'sbrow',
      x:x0, y:y + i*140, rot:0, w:560, h:120,
      title:(sc.scene ? 'Scene ' + sc.scene : sc.name) + (sc.sceneDesc ? ' \u2014 ' + sc.sceneDesc : ''),
      desc:'', imgId:null, sceneId:sc.id,
      color:COLORS[i % COLORS.length], label:'', path:[]});
  });
  markDirty(); render(); refreshSelBar();
  toast(scenes.length + ' scenes broken down \u2014 storyboard rows added to the right');
}
function pickSbImage(o){
  const fi = document.createElement('input');
  fi.type = 'file'; fi.accept = 'image/*';
  fi.addEventListener('change', async ()=>{
    if(!fi.files || !fi.files[0]) return;
    try{
      o.imgId = await storeImageFile(fi.files[0]);
      await loadStill(o.imgId);
      markDirty(); render(); refreshSelBar();
    }catch(e){ toast('Could not store that image \u2014 try a smaller one'); }
  });
  fi.click();
}
// file objects (docs / pdfs) on any board
async function addBoardFileAt(file, x, y){
  if(file.size > 4.5*1024*1024){ toast('Files up to ~4 MB \u2014 this one is too large'); return; }
  try{
    const dataURL = await new Promise((ok, bad)=>{
      const r = new FileReader();
      r.onload = ()=>ok(r.result); r.onerror = ()=>bad(r.error);
      r.readAsDataURL(file);
    });
    const id = uid();
    await window.storage.set('sd:file:' + id, dataURL);
    const obj = {id:uid(), cat:'file', kind:'file',
      x, y, rot:0, w:230, h:64,
      fileId:id, name:file.name, size:file.size, mime:file.type,
      color:'#5B6472', label:'', path:[]};
    activeScene().objects.push(obj);
    markDirty(); render();
    toast('File added \u2014 select it to download');
    // PDFs get a first-page preview
    if((file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'))){
      try{
        const thumbURL = await pdfFirstPageThumb(file);
        const tid = uid();
        await window.storage.set('sd:img:' + tid, thumbURL);
        const im = new Image();
        im.src = thumbURL;
        imgCache[tid] = im;
        im.onload = ()=>render();
        obj.imgId = tid;
        obj.w = 190; obj.h = 250;
        markDirty(); render();
      }catch(e){ console.warn('pdf thumb failed', e); }
    }
  }catch(e){ toast('Could not store that file'); }
}
function pickBoardFile(){
  const fi = document.createElement('input');
  fi.type = 'file';
  fi.addEventListener('change', ()=>{
    if(!fi.files || !fi.files[0]) return;
    const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
    addBoardFileAt(fi.files[0], c.x, c.y);
  });
  fi.click();
}

// ---------------------------------------------------------------- production panel (right side of the board)
function buildOrgPanel(){
  project.production = project.production || {company:'', lead:'', notes:'', contacts:[], locations:[]};
  const p = project.production;
  const host = document.getElementById('orgContent');
  host.innerHTML = '';
  const grid = document.createElement('div');
  grid.className = 'org-grid';
  grid.style.gridTemplateColumns = '1fr'; // single column inside the panel
  grid.style.padding = '12px';
  host.appendChild(grid);

  const card = title=>{
    const c = document.createElement('div');
    c.className = 'org-card';
    c.innerHTML = '<h3>' + title + '</h3>';
    grid.appendChild(c);
    return c;
  };
  const field = (parent, label, get, set, textarea)=>{
    const l = document.createElement('label'); l.textContent = label; parent.appendChild(l);
    const i = document.createElement(textarea ? 'textarea' : 'input');
    if(textarea) i.rows = 3;
    i.value = get() || '';
    i.addEventListener('input', ()=>{ set(i.value); markDirty(); });
    parent.appendChild(i);
  };

  const c1 = card('Production info');
  field(c1, 'Company', ()=>p.company, v=>p.company=v);
  field(c1, 'Production lead', ()=>p.lead, v=>p.lead=v);
  field(c1, 'Notes (parking, power, catering…)', ()=>p.notes, v=>p.notes=v, true);

  const c2 = card('Crew & cast contacts');
  const contactsHost = document.createElement('div'); c2.appendChild(contactsHost);
  const renderContacts = ()=>{
    contactsHost.innerHTML = '';
    p.contacts.forEach((ct, i)=>{
      const row = document.createElement('div'); row.className = 'org-row';
      for(const [k, ph] of [['role','Role'],['name','Name'],['phone','Phone'],['email','Email']]){
        const inp = document.createElement('input');
        inp.placeholder = ph; inp.value = ct[k] || '';
        inp.addEventListener('input', ()=>{ ct[k] = inp.value; markDirty(); });
        row.appendChild(inp);
      }
      const rm = document.createElement('button'); rm.className = 'rm'; rm.textContent = '×';
      rm.addEventListener('click', ()=>{ p.contacts.splice(i,1); markDirty(); renderContacts(); });
      row.appendChild(rm);
      contactsHost.appendChild(row);
    });
  };
  renderContacts();
  const addC = document.createElement('button');
  addC.className = 'btn org-add'; addC.textContent = '+ Add contact';
  addC.addEventListener('click', ()=>{ p.contacts.push({role:'',name:'',phone:'',email:''}); markDirty(); renderContacts(); });
  c2.appendChild(addC);

  const c3 = card('Locations');
  const locHost = document.createElement('div'); c3.appendChild(locHost);
  const renderLocs = ()=>{
    locHost.innerHTML = '';
    p.locations.forEach((lc, i)=>{
      const row = document.createElement('div'); row.className = 'org-row';
      for(const [k, ph] of [['name','Name'],['address','Address'],['parking','Parking'],['notes','Notes']]){
        const inp = document.createElement('input');
        inp.placeholder = ph; inp.value = lc[k] || '';
        inp.addEventListener('input', ()=>{ lc[k] = inp.value; markDirty(); });
        row.appendChild(inp);
      }
      const rm = document.createElement('button'); rm.className = 'rm'; rm.textContent = '×';
      rm.addEventListener('click', ()=>{ p.locations.splice(i,1); markDirty(); renderLocs(); });
      row.appendChild(rm);
      locHost.appendChild(row);
    });
  };
  renderLocs();
  const addL = document.createElement('button');
  addL.className = 'btn org-add'; addL.textContent = '+ Add location';
  addL.addEventListener('click', ()=>{ p.locations.push({name:'',address:'',parking:'',notes:''}); markDirty(); renderLocs(); });
  c3.appendChild(addL);
}


// single-board PDF (moodboard / production board) — A4 landscape, image fitted
async function exportBoardPDF(){
  const board = activeScene();
  await ensureShotImages(board, false);
  const plan = renderShotPlan(board, 1800, null, false);
  const jpeg = atob(plan.toDataURL('image/jpeg', .82).split(',')[1]);
  const PW = 842, PH = 595, M = 28;
  const maxW = PW - M*2, maxH = PH - M*2 - 20;
  const k = Math.min(maxW/plan.width, maxH/plan.height);
  const iw = plan.width*k, ih = plan.height*k;
  const ix = (PW - iw)/2, iy = (PH - 20 - ih)/2;
  const title = ((project.shootName ? project.shootName + ' \u2014 ' : '') + board.name)
    .replace(/[()\\]/g, '');
  const content = 'q ' + iw.toFixed(2) + ' 0 0 ' + ih.toFixed(2) + ' ' + ix.toFixed(2) + ' ' + iy.toFixed(2) +
    ' cm /Im1 Do Q\nBT /F1 13 Tf ' + M + ' ' + (PH - M + 6) + ' Td (' + title + ') Tj ET';
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + PW + ' ' + PH + '] ' +
      '/Resources << /XObject << /Im1 5 0 R >> /Font << /F1 6 0 R >> >> /Contents 4 0 R >>',
    '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream',
    '<< /Type /XObject /Subtype /Image /Width ' + plan.width + ' /Height ' + plan.height +
      ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + jpeg.length +
      ' >>\nstream\n' + jpeg + '\nendstream',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  objs.forEach((o, i)=>{
    offsets.push(pdf.length);
    pdf += (i+1) + ' 0 obj\n' + o + '\nendobj\n';
  });
  const xref = pdf.length;
  pdf += 'xref\n0 ' + (objs.length+1) + '\n0000000000 65535 f \n';
  for(let i=1;i<=objs.length;i++) pdf += String(offsets[i]).padStart(10,'0') + ' 00000 n \n';
  pdf += 'trailer\n<< /Size ' + (objs.length+1) + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF';
  const bytes = new Uint8Array(pdf.length);
  for(let i=0;i<pdf.length;i++) bytes[i] = pdf.charCodeAt(i) & 0xFF;
  const a = document.createElement('a');
  a.download = (board.name.replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_') || 'board') + '.pdf';
  a.href = URL.createObjectURL(new Blob([bytes], {type:'application/pdf'}));
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href), 5000);
}

// ---------------------------------------------------------------- paste images onto boards
// Copy a still anywhere (ShotDeck, Frameset, a browser tab) and Cmd/Ctrl+V it in.
document.addEventListener('paste', async e=>{
  if(activeTab === 'script' || activeTab === 'story') return;
  const tag = document.activeElement && document.activeElement.tagName;
  if(tag === 'INPUT' || tag === 'TEXTAREA') return;
  const items = [...(e.clipboardData && e.clipboardData.items || [])]
    .filter(i=>i.type.startsWith('image/'));
  if(!items.length) return;
  e.preventDefault();
  const c = toWorld(wrap.clientWidth/2, wrap.clientHeight/2);
  let off = 0;
  for(const it of items){
    const file = it.getAsFile();
    if(!file) continue;
    try{
      await addBoardImage(file, c.x + off, c.y + off);
      off += 34;
    }catch(err){ toast('Could not store that image — try a smaller one'); }
  }
  if(off) toast('Pasted onto the board');
});


// ---------------------------------------------------------------- trash can (drop to delete)
const trashEl = document.createElement('div');
trashEl.id = 'trashCan';
trashEl.innerHTML = '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/></svg>';
document.body.appendChild(trashEl);
function overTrash(x, y){
  const r = trashEl.getBoundingClientRect();
  return x >= r.left - 12 && x <= r.right + 12 && y >= r.top - 12 && y <= r.bottom + 12;
}
document.addEventListener('pointermove', e=>{
  const dragging = drag && drag.kind === 'move' && drag.o && !drag.o.locked;
  trashEl.classList.toggle('show', !!dragging);
  if(dragging) trashEl.classList.toggle('hot', overTrash(e.clientX, e.clientY));
});
document.addEventListener('pointerup', e=>{
  if(drag && drag.kind === 'move' && drag.o && !drag.o.locked && overTrash(e.clientX, e.clientY)){
    const o = drag.o;
    const sc = activeScene();
    sc.objects = sc.objects.filter(x=>x.id !== o.id);
    sc.objects.forEach(c=>{
      if(c.mount && c.mount.id === o.id) c.mount = null;
      if(c.rail && c.rail.id === o.id){ c.rail = null; c.path = []; }
    });
    sel = null; drag = null;
    trashEl.classList.remove('show', 'hot');
    markDirty(); if(histPushed) histSettle();
    refreshSelBar(); render();
    toast('Deleted \u2014 Cmd/Ctrl+Z to undo');
    e.stopPropagation();
  } else {
    trashEl.classList.remove('show', 'hot');
  }
}, {capture:true});

// ---------------------------------------------------------------- productions: save / switch / new
async function flushSave(){ dirty = true; await saveProject(); }
async function openProjectPop(){
  const pop = document.getElementById('projPop');
  if(pop.classList.contains('show')){ pop.classList.remove('show'); return; }
  const idx = (await loadProjectIndex()) || [];
  idx.sort((a,b)=>(b.updated||0)-(a.updated||0));
  pop.innerHTML = '<div class="xp-title">This production</div>';
  const nameIn = document.createElement('input');
  nameIn.className = 'proj-name';
  nameIn.placeholder = 'Name this production\u2026';
  nameIn.value = project.shootName || '';
  nameIn.addEventListener('input', ()=>{
    project.shootName = nameIn.value;
    markDirty(); syncProjBtn();
    const el0 = document.getElementById('iShoot');
    if(el0) el0.value = nameIn.value;
  });
  nameIn.addEventListener('keydown', e=>{ if(e.key==='Enter') nameIn.blur(); e.stopPropagation(); });
  pop.appendChild(nameIn);
  const st = document.createElement('div');
  st.style.cssText = 'font-size:10px;color:var(--ink2);margin:4px 2px 10px;';
  st.textContent = 'Autosaves as you work \u2014 switch below at any time.';
  pop.appendChild(st);
  pop.insertAdjacentHTML('beforeend', '<div class="xp-title">All productions</div>');
  idx.forEach(p=>{
    const row = document.createElement('button');
    row.className = 'proj-row' + (p.id === currentProjectId ? ' on' : '');
    row.textContent = p.name || 'Untitled production';
    row.addEventListener('click', async ()=>{
      if(p.id === currentProjectId){ pop.classList.remove('show'); return; }
      await flushSave();
      await window.storage.set('sd:current', p.id);
      location.reload();
    });
    pop.appendChild(row);
  });
  const nw = document.createElement('button');
  nw.className = 'btn primary';
  nw.style.cssText = 'width:100%;margin-top:8px;';
  nw.textContent = '+ New production';
  nw.addEventListener('click', async ()=>{
    await flushSave();
    const id = uid();
    const fresh = {v:4, scenes:[newShot(1)], activeSceneId:null, customProps:[], shootName:''};
    fresh.activeSceneId = fresh.scenes[0].id;
    await window.storage.set('sd:project:' + id, JSON.stringify(fresh));
    const idx2 = (await loadProjectIndex()) || [];
    idx2.push({id, name:'Untitled production', updated:Date.now()});
    await saveProjectIndex(idx2);
    await window.storage.set('sd:current', id);
    location.reload();
  });
  pop.appendChild(nw);
  if(idx.length > 1){
    const del = document.createElement('button');
    del.className = 'btn';
    del.style.cssText = 'width:100%;margin-top:6px;color:#C0392B;';
    del.textContent = 'Delete current production\u2026';
    del.addEventListener('click', async ()=>{
      if(!confirm('Delete "' + (project.shootName || 'Untitled production') + '" permanently? This cannot be undone.')) return;
      const idx2 = ((await loadProjectIndex()) || []).filter(p=>p.id !== currentProjectId);
      await saveProjectIndex(idx2);
      await window.storage.delete('sd:project:' + currentProjectId).catch(()=>{});
      await window.storage.set('sd:current', idx2[0].id);
      location.reload();
    });
    pop.appendChild(del);
  }
  pop.classList.add('show');
}
document.getElementById('projBtn').addEventListener('click', openProjectPop);
document.addEventListener('pointerdown', e=>{
  const pop = document.getElementById('projPop');
  if(pop.classList.contains('show') && !pop.contains(e.target) &&
     e.target.id !== 'projBtn' && !document.getElementById('projBtn').contains(e.target)){
    pop.classList.remove('show');
  }
});
function syncProjBtn(){
  const b = document.getElementById('projBtn');
  if(b && project) b.textContent = (project.shootName || 'Untitled production') + ' \u25be';
}
setInterval(syncProjBtn, 1500);
setTimeout(syncProjBtn, 400);
