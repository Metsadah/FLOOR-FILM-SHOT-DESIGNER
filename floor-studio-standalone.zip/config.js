// FLOOR Studio — deployment configuration. See SELFHOST.md.
// Empty = LOCAL MODE (no accounts, projects saved in this browser).
// Fill in your own Supabase project for cloud mode (run setup/schema.sql first).
window.FLOOR_CONFIG = {
  supabaseUrl: '',
  supabaseKey: '',
};
