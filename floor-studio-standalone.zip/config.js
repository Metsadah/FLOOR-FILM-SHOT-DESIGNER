// FLOOR Studio — deployment config
// Fill in your own Supabase project to enable cloud sync, sharing and login.
// Leave both empty to run fully local (IndexedDB, no accounts).
window.FLOOR_CONFIG = {
  supabaseUrl: "",
  supabaseKey: ""
};
