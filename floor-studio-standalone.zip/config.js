// Floorboard — deployment config
// Fill in your own Supabase project to enable cloud sync, sharing and login.
// Leave both empty to run fully local (IndexedDB, no accounts).
window.FLOOR_CONFIG = {
  supabaseUrl: "",
  supabaseKey: "",
  // mode: "shot" = Shot designer only (the iPad flavour, see IPAD.md); "" = full app
  mode: "",
  // Optional hosted plans — see BILLING.md. Empty provider = no plans, all features on.
  billing: { provider: "", priceLabel: "", plan: "pro", token: "", priceId: "",
             environment: "production", checkoutUrl: "", portalUrl: "" },
};
